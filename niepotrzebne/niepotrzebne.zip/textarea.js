function textCounter(theField,maxChars,maxLines,maxPerLine)

{

	var strTemp = "";

	var strLineCounter = 0;

	var strCharCounter = 0;

	

	for (var i = 0; i < theField.value.length; i++)

	{

		var strChar = theField.value.substring(i, i + 1);

		

		if (strChar == '\n')

		{

			strTemp += strChar;

			strCharCounter = 1;

			strLineCounter += 1;

		}

		else if (strCharCounter == maxPerLine)

		{

			strTemp += '\n' + strChar;

			strCharCounter = 1;

			strLineCounter += 1;

		}

		else

		{

			strTemp += strChar;

			strCharCounter ++;

		}

	}

	if (strCharCounter>=maxChars) 
	{ 
		alert("Za du�o znak�w w linii");
		return false;
	} else {
				if (strLineCounter>=maxLines) 
				{ 
					alert("Za du�o linii w polu");
					return false;
				} else 
					return true;	
	}
	
	

	//theCharCounter.value = maxChars - strTemp.length;
	//theLineCounter.value = maxLines - strLineCounter;

}