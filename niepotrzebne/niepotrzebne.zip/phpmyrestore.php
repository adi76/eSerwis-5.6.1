<?php

$host = 'localhost';      // MySQL hostname
$dbname ='dbname';        // MySQL basename
$uname = 'user';          // MySQL user
$upass ='password';       // MySQL password

set_time_limit(600);      // Number of seconds before timeout (does not work in safe mode!)

//////////////////////////////////////////////////
//
//  phpMyRestore v1.0
//
//  Restores MySQL dump files
//
//  do not change anything below this line
//
//////////////////////////////////////////////////

define ('CR', "\n");
$msg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

  if (!$_FILES['backup']['tmp_name']) {

    $msg .= '<b>Ooops, no file!</b><br />'.CR;

  } else {

    if (is_uploaded_file($_FILES['backup']['tmp_name'])) {

      // check for any errors
      switch ($_FILES['backup']['error']) {

        case 0:
          break;
        case 1:
          $msg .= '<b>The uploaded file is too big to process</b><br />'.CR;
          break;
        case 2:
          $msg .= '<b>The uploaded file is too big to process</b><br />'.CR;
          break;
        case 3:
          $msg .= '<b>The uploaded file was only partially received</b><br />'.CR;
          break;
        case 4:
          $msg .= '<b>No file was uploaded</b><br />'.CR;
          break;
        case 5:
          $msg .= '<b>The uploaded file is empty</b><br />'.CR;
          break;

      }

      if (!$msg) {

        // open file for reading
        $fp = @fopen($_FILES['backup']['tmp_name'], 'r');

        if (!$fp) {

          $msg .= '<b>Could not open uploaded file</b><br />'.CR;

        } else if (!$con = @mysql_connect($host, $uid, $pwd)) {

          $msg .= '<b>Could not connect</b><br />'.CR;  

        } else if (!@mysql_select_db($dbname, $con)) {

          $msg .= '<b>Could not select db</b><br />'.CR;

        } else {

          $sql = '';
          while (!feof($fp)) {

            $read = fgets($fp, 4096);

            if (!preg_match('/^[#-]/', $read)) {

              $sql .= $read;

              if (preg_match('/;[\r\n]$/', $sql)) {

                $sql = preg_replace('/;[\r\n]$/', '', $sql);

                if (!@mysql_query($sql, $con)) $msg .= '<b>Query failed:</b> '.htmlspecialchars($sql).'<br /><br />'.CR;
                $sql = '';

              }

            }

          }

        }

      }

    } else {

      $msg = '<b>Possible file upload attack; restore aborted!</b><br />'.CR;

    }

  }

  if (!$msg) $msg = '<b>Restore completed successfully!</b><br />'.CR;

}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>phpMyRestore</title>
</head>
<body>
<?php

if ($msg) {

  echo $msg;

} else {

  echo '<form action="phpmyrestore.php" method="post" enctype="multipart/form-data">'.CR.
       'Select a previously saved backup and press the button below to restore it<br /><br />'.CR.
       '<input type="file" name="backup" size="40" style="width: 294px; height:22px" /><br /><br />'.CR.
       '<input type="submit" value="Restore Backup" />'.CR.
       '</form>';

}

?>
</body>
</html>