<?php /* new CSS */ ?>
<?php include_once('header.php'); ?>

<body OnLoad="document.addewid.ts.focus();">

<?php 
if ($submit) { 

	$sql44="SELECT * FROM serwis_slownik_rola WHERE (rola_id=$_POST[ts])";
	$result44 = mysql_query($sql44, $conn) or die(mysql_error());

	while ($newArray44 = mysql_fetch_array($result44)) 
	{
		$rola_typ_nazwa				= $newArray44['rola_nazwa'];		
	}

	$sql55="SELECT * FROM serwis_komorki WHERE (up_id=$_POST[ls])";
	$result55 = mysql_query($sql55, $conn) or die(mysql_error());

	while ($newArray55 = mysql_fetch_array($result55)) 
	{
		$lok_up_nazwa				= $newArray55['up_nazwa'];		
	}
	if (($_POST['ts']!='') && ($_POST['ls']!='')) {
	$dddd = Date('Y-m-d H:i:s');
	$endpoint1 = $_POST['ne'];
	if ($_POST['ipend']=='on') { $endpoint1 = $_POST['nazwak'];}
	
	$konf_opis='';
	//echo "----|$rolatypnazwa|-----";
	
if (($rola_typ_nazwa=='Komputer') || ($rola_typ_nazwa=='Serwer') || ($rola_typ_nazwa=='Notebook')) {

	if ($_POST[wpis]=='auto'){ 
		$sql444="SELECT * FROM serwis_slownik_konfiguracja WHERE (konfiguracja_id=$_POST[sk]) LIMIT 1";
		echo "<br>!$sql444";
		
		$result444 = mysql_query($sql444, $conn) or die(mysql_error());
		//$count_rows = mysql_num_rows($result44);
		$i = 0;
				
		$newArray444 = mysql_fetch_array($result444);
		 
			$temp_id  				= $newArray444['konfiguracja_id'];
			$temp_nazwa				= $newArray444['konfiguracja_nazwa'];
			$temp_opis				= $newArray444['konfiguracja_opis'];
			$temp_procesor			= $newArray444['procesor'];
			$temp_pamiec			= $newArray444['pamiec'];
			$temp_dysk				= $newArray444['dysk'];
			
			$k__procesor=$temp_procesor;
			$k__pamiec=$temp_pamiec;
			$k__dysk=$temp_dysk;			

			$k__procesor = str_replace(',','.',$k__procesor);
			$k__pamiec = str_replace(',','.',$k__pamiec);		
			$k__dysk = str_replace(',','.',$k__dysk);
		
		$konf_opis='Procesor '.$k__procesor.'GHz, '.$k__pamiec.'MB RAM, '.$k__dysk.'GB HDD';	
		
	} else  { 
		 
		$k__procesor=$_POST[konf_proc];
		$k__pamiec=$_POST[konf_ram];
		$k__dysk=$_POST[konf_hdd];
		
		$k__procesor = str_replace(',','.',$k__procesor);
		$k__pamiec = str_replace(',','.',$k__pamiec);		
		$k__dysk = str_replace(',','.',$k__dysk);
		
		$konf_opis='Procesor '.$k__procesor.'GHz, '.$k__pamiec.'MB RAM, '.$k__dysk.'GB HDD';
		//echo "$k__procesor&nbsp;$k__pamiec&nbsp;$k__dysk";
	}	
}

	$sql_t = "INSERT INTO serwis_ewidencja values ('', '$_POST[ts]','$rola_typ_nazwa','$_POST[ls]','$lok_up_nazwa','$_POST[us]','$_POST[nrp]','$_POST[niz]','$_POST[nazwak]','$_POST[os]','$_POST[nrsk]','$_POST[aip]','$endpoint1','$_POST[m]','$_POST[nrsm]','$_POST[d]','$_POST[nrsd]','$_POST[nid]','$_POST[uwagi]',$_POST[ubelongs_to],$_POST[status],$_POST[oprogramowanie],'$dddd','$currentuser','$konf_opis','$k__procesor','$k__pamiec','$k__dysk','$_POST[gwarancja]','$_POST[firmaserwisowa]',0)";

//echo "$sql_t";
	
//	$sql_t = "SELECT * FROM serwis_ewidencja";
	
	if (mysql_query($sql_t, $conn))
	{ 
			$lastid = mysql_insert_id();
			
			?><script>opener.location.reload(true);  
			<?php if ($rola_typ_nazwa=='Drukarka') { ?>
			
			if (confirm("Czy chcesz przypisa� nowo dodan� drukark� do komputera ?")) {
				window.location.href='z_ewidencja_przypisz_drukarke.php?eid=<?php echo $lastid;?>&upid=<?php echo $_POST[ls];?>';
			} else self.close();
			<?php } else { ?>
			self.close();
			<?php } ?>
			</script><?php
	} else 
		{
		  ?><script> info('Wyst�pi� b��d podczas zapisywania zmian do bazy'); window.close(); </script><?php
		}
	} else {	
			?><script> info('Nie wype�ni�e� wymaganych p�l'); window.close(); </script><?php
	}

} else { ?>
		
<?php

	echo "<h4>Dodawanie nowego sprz�tu do bazy ewidencji</h4>";
	echo "<form name=addewid action=$PHP_SELF method=POST>";

	echo "<div class=showr>";
	echo "<input class=buttons type=submit name=submit value='Zapisz'><input class=buttons_ok type=button name=anuluj value='Anuluj' onClick='window.close();'>";
	echo "</div>";
	
	echo "<table cellspacing=1 align=center>";
	echo "<tr><td>&nbsp;</td></tr>";		
	echo "<tr><td colspan=2></td></tr>";
	echo "<tr><td class=center colspan=2>&nbsp;<b>Typ sprz�tu&nbsp;</b>";
	
		$sql44="SELECT * FROM serwis_slownik_rola WHERE (rola_do_ewidencji=1) ORDER BY rola_nazwa";
		$result44 = mysql_query($sql44, $conn) or die(mysql_error());
		$count_rows = mysql_num_rows($result44);
		$i = 0;
		
		echo "<select class=wymagane name=ts onchange='ewid(this.value); clearForm(this.form);'>\n"; 					 				
		echo "<option value=''>Wybierz z listy..."; 
		while ($newArray44 = mysql_fetch_array($result44)) 
		 {
			$temp_id  				= $newArray44['rola_id'];
			$temp_nazwa				= $newArray44['rola_nazwa'];
			
			if ($temp_nazwa!='Monitor') echo "<option value='$temp_id'>$temp_nazwa</option>\n"; 
		
		}
		
		echo "</select>\n"; 
		echo "<br><br></td>";
	echo "</tr>";
	

	echo "<tr id=lokalizacja1 style=display:none ><td colspan=2><hr></td></tr>";
	echo "<tr id=lokalizacja2 style=display:none ><td class=center colspan=2><b>Informacje o lokalizacji sprz�tu</b></td></tr>";
	echo "<tr id=lokalizacja3 style=display:none ><td colspan=2><hr></td></tr>";

//	echo "<div id=lokalizacja style='display:none'>";

	echo "<tr id=lokalizacja4 style=display:none class=titlebar_add>";
		echo "<td width=160 class=right>&nbsp;Lokalizacja sprz�tu&nbsp;</td>";
		$sql44="SELECT * FROM serwis_komorki WHERE belongs_to='$es_filia' ORDER BY up_nazwa";
		$result44 = mysql_query($sql44, $conn) or die(mysql_error());
		$count_rows = mysql_num_rows($result44);
		$i = 0;
		
		echo "<td>&nbsp;";		
		echo "<select class=wymagane name=ls onkeypress='return handleEnter(this, event)'>\n"; 					 				
		echo "<option value=''>Wybierz z listy...";
				
		while ($newArray44 = mysql_fetch_array($result44)) 
		 {
			$temp_id  				= $newArray44['up_id'];
			$temp_nazwa				= $newArray44['up_nazwa'];
			

			echo "<option value='$temp_id'>$temp_nazwa</option>\n"; 
		
		}
		
		echo "</select>\n"; 
		echo "</td>";
	echo "</tr>";

	echo "<tr id=lokalizacja5 style=display:none class=titlebar_add>";
	echo "<td width=160 class=right>&nbsp;U�ytkownik sprz�tu&nbsp;</td>";
	echo "<td class=left>&nbsp;<input size=20 maxlength=30 type=text name=us onkeypress='return handleEnter(this, event)'>&nbsp;</td>";
	echo "</tr>";

	echo "<tr id=lokalizacja6 style=display:none class=titlebar_add>";
	echo "<td width=160 class=right>&nbsp;Nr pokoju&nbsp;</td>";
	echo "<td class=left>&nbsp;<input size=5 maxlength=5 type=text name=nrp onkeypress='return handleEnter(this, event)'>&nbsp;</td>";
	echo "</tr>";
	
	echo "<tr id=zestaw1 style=display:none><td colspan=2><hr></td></tr>";
	echo "<tr id=zestaw2 style=display:none><td class=center colspan=2><b>Informacje o zestawie komputerowym</b></td></tr>";
	echo "<tr id=zestaw3 style=display:none><td colspan=2><hr></td></tr>";

	echo "<tr id=zestaw4 style=display:none class=titlebar_add>";
	echo "<td width=160 class=right>&nbsp;</td>";
	echo "<td class=left>Nr inwentarzowy zestawu&nbsp;&nbsp;<input size=20 maxlength=20 type=text name=niz onkeypress='return handleEnter(this, event)'>&nbsp;</td>";
	echo "</tr>";	


	echo "<tr id=zestaw5 style=display:none><td class=center><b>Komputer/Serwer<hr></td><td>&nbsp;</td></tr>";
	
	echo "<tr id=zestaw6 style=display:none class=titlebar_add>";
		echo "<td width=160 class=right>&nbsp;Nazwa komputera&nbsp;</td>";
		echo "<td class=left>&nbsp;<input size=30 maxlength=30 type=text name=nazwak onkeypress='return handleEnter(this, event)'>&nbsp; np. p21xxxxxxx</td>";
	echo "</tr>";

	echo "<tr id=zestaw7 style=display:none class=titlebar_add>";
	echo "<td width=160 class=right>&nbsp;Opis komputera&nbsp;</td>";
//	echo "<td class=left>&nbsp;<input size=50 type=text name=os>&nbsp; np. IMB PC300</td>";
	echo "<td>";
		//echo "<input size=50 type=text name=os>";
		
		$sql44="SELECT * FROM serwis_slownik_konfiguracja ORDER BY konfiguracja_opis";
		$result44 = mysql_query($sql44, $conn) or die(mysql_error());
		$count_rows = mysql_num_rows($result44);
		$i = 0;
		
		echo "&nbsp;";		
		echo "<select name=os onkeypress='return handleEnter(this, event)'>\n"; 					 				
		echo "<option value=''>Wybierz z listy...";
				
		while ($newArray44 = mysql_fetch_array($result44)) 
		 {
			$temp_id  				= $newArray44['konfiguracja_id'];
			$temp_nazwa				= $newArray44['konfiguracja_nazwa'];
			$temp_opis				= $newArray44['konfiguracja_opis'];
			echo "<option value='$temp_opis'>$temp_opis</option>\n"; 
		}
		echo "</select>\n"; 

	echo "</td>";
	
	echo "</tr>";
	
	echo "<tr id=zestaw8 style=display:none class=titlebar_add>";
	echo "<td width=160 class=right>&nbsp;Nr seryjny komputera&nbsp;</td>";
	echo "<td class=left>&nbsp;<input size=30 maxlength=30 type=text name=nrsk onkeypress='return handleEnter(this, event)'>&nbsp;</td>";
	echo "</tr>";

	echo "<tr id=zestaw9 style=display:none class=titlebar_add>";
		echo "<td width=160 class=right>&nbsp;Adres IP&nbsp;</td>";
		echo "<td class=left>&nbsp;<input size=15 type=text maxlength=15 name=aip onkeypress='return handleEnter(this, event)'>&nbsp;";
		echo "Endpoint";
		echo "<input size=15 maxlenght=30 type=text name=ne>&nbsp;&nbsp;<input type=checkbox name=ipend onkeypress='return handleEnter(this, event)'>endpoint = nazwa komputera";
	echo "</tr>";

	echo "<tr id=zestaw10 style=display:none class=titlebar_add>";
		echo "<td width=160 class=right>&nbsp;Konfiguracja sprz�tu&nbsp;</td>";	
		echo "<td>";
		echo "<input type=radio name=wpis checked=checked value='auto' onclick='wlacz_slownik(); document.addewid.sk.focus();'>ze s�ownika";
		echo "<input type=radio name=wpis value='manual' onclick='wlacz_manual(); document.addewid.konf_proc.focus(); '>wpisz r�cznie";
		echo "</td>";
	echo "</tr>";
	
//	echo "<div id=slownik style=display:none>";
//	echo "<tr id=slownik class=titlebar_add>";
	echo "<tr id=zestaw11 style=display:none class=titlebar_add>";
//	echo "<tr id=slownik style=display:none class=titlebar_add>";
	echo "<div id=slownik>";
		echo "<td width=160 class=right>&nbsp;</td>";
		$sql44="SELECT * FROM serwis_slownik_konfiguracja ORDER BY konfiguracja_nazwa";
		$result44 = mysql_query($sql44, $conn) or die(mysql_error());
		$count_rows = mysql_num_rows($result44);
		$i = 0;
		
		echo "<td id=slownik>&nbsp;";		
		echo "<select name=sk>\n"; 					 				
		echo "<option value=0>Wybierz z listy...";
				
		while ($newArray44 = mysql_fetch_array($result44)) 
		 {
			$temp_id  				= $newArray44['konfiguracja_id'];
			$temp_nazwa				= $newArray44['konfiguracja_nazwa'];
			$temp_opis				= $newArray44['konfiguracja_opis'];
			
			echo "<option value='$temp_id'>$temp_nazwa | $temp_opis</option>\n"; 
		
		}
		
		echo "</select>\n"; 
		echo "</td>";
	echo "</div>";
	echo "</tr>";
//	echo "</div>";
// r�cznie wpisana konfiguracja 

	//echo "<div id=wpiszsam style=display:none>";
//	echo "<tr id=wpiszsam class=titlebar_add>";
	echo "<tr id=zestaw12 style=display:none class=titlebar_add>";
	echo "<div id=wpiszsam style=display:none>";
	echo "<td width=160 class=right>&nbsp;</td>";
	echo "<td class=left>";
		echo "&nbsp;Procesor (GHz) <input size=5 maxlength=5 type=text name=konf_proc onkeypress='return handleEnter(this, event)'>&nbsp;";
		echo "&nbsp;Pami�� (MB) <input size=5 maxlength=5 type=text name=konf_ram onkeypress='return handleEnter(this, event)'>&nbsp;";
		echo "&nbsp;Dysk (GB) <input size=5 maxlength=5 type=text name=konf_hdd onkeypress='return handleEnter(this, event)'>&nbsp;";
	echo "</td>";
	echo "</div>";
	echo "</tr>";
//	echo "</div>";
	
	echo "<tr id=zestaw13 style=display:none><td class=center><br><b>Monitor<hr></td><td>&nbsp;</td></tr>";

	echo "<tr id=zestaw14 style=display:none class=titlebar_add>";
	echo "<td width=160 class=right>&nbsp;Nazwa monitora&nbsp;</td>";
	echo "<td class=left>&nbsp;";

		$sql444="SELECT * FROM serwis_slownik_monitor ORDER BY monitor_nazwa";
		$result444 = mysql_query($sql444, $conn) or die(mysql_error());
		$count_rows = mysql_num_rows($result444);
		$i = 0;
		
		echo "&nbsp;";		
		echo "<select name=m onkeypress='return handleEnter(this, event)'>\n"; 					 				
		echo "<option value=''>Wybierz z listy...";
				
		while ($newArray444 = mysql_fetch_array($result444)) 
		 {
			$temp_id  				= $newArray444['monitor_id'];
			$temp_nazwa				= $newArray444['monitor_nazwa'];
			$temp_opis				= $newArray444['monitor_opis'];
			$temp_typ				= $newArray444['monitor_typ'];
			$temp_cale				= $newArray444['monitor_cale'];
			
			echo "<option value='$temp_nazwa'>$temp_nazwa - $temp_cale\" $temp_typ ($temp_opis)</option>\n"; 
		
		}
		
		echo "</select>\n"; 	
		echo "</td>";
	echo "</tr>";

	echo "<tr id=zestaw15 style=display:none class=titlebar_add>";
		echo "<td width=160 class=right>Nr seryjny monitora&nbsp;</td>";
		echo "<td>&nbsp;&nbsp;<input size=30 maxlength=30 type=text name=nrsm onkeypress='return handleEnter(this, event)'></td>";
	echo "</tr>";
	
			
	echo "<tr id=druk1 style=display:none><td colspan=2><br><hr></td></tr>";
	echo "<tr id=druk2 style=display:none><td class=center colspan=2><b>Informacje o urz�dzeniach peryferyjnych</b></td></tr>";
	echo "<tr id=druk3 style=display:none><td colspan=2><hr></td></tr>";
	
	echo "<tr id=druk4 style=display:none class=titlebar_add>";
	echo "<td width=160 class=right>&nbsp;Model drukarki&nbsp;</td>";
	echo "<td class=left>&nbsp;";
	
	
		$sql4444="SELECT * FROM serwis_slownik_drukarka ORDER BY drukarka_nazwa";
		$result4444 = mysql_query($sql4444, $conn) or die(mysql_error());
		$count_rows = mysql_num_rows($result4444);
		$i = 0;
		
		echo "&nbsp;";		
		echo "<select name=d onkeypress='return handleEnter(this, event)'>\n"; 					 				
		echo "<option value=''>Wybierz z listy...";
				
		while ($newArray4444 = mysql_fetch_array($result4444)) 
		 {
			$temp_id  				= $newArray4444['drukarka_id'];
			$temp_nazwa				= $newArray4444['drukarka_nazwa'];
			$temp_opis				= $newArray4444['drukarka_opis'];
			
			echo "<option value='$temp_nazwa'>$temp_nazwa</option>\n"; 
		
		}
		
		echo "</select>\n"; 
	echo "</td>";
	echo "</td>";
	echo "</tr>";
	
	echo "<tr id=druk5 style=display:none class=titlebar_add>";
		echo "<td class=right>&nbsp;&nbsp;Nr seryjny drukarki&nbsp;</td>";
		echo "<td>&nbsp;&nbsp;<input size=30 maxlength=30 type=text name=nrsd onkeypress='return handleEnter(this, event)'></td>";
	echo "</tr>";	

	echo "<tr id=druk6 style=display:none class=titlebar_add>";
	echo "<td width=160 class=right>&nbsp;Nr inwentarzowy drukarki&nbsp;</td>";
	echo "<td class=left>&nbsp;&nbsp;<input size=20 maxlength=20 type=text name=nid onkeypress='return handleEnter(this, event)'>&nbsp;</td>";
	echo "</tr>";

	echo "<tr id=lokalizacja7 style=display:none><td colspan=2><hr></td></tr>";
	echo "<tr id=lokalizacja8 style=display:none><td class=center colspan=2><b>Informacje dodatkowe</b></td></tr>";
	echo "<tr id=lokalizacja9 style=display:none><td colspan=2><hr></td></tr>";			
	
	echo "<tr id=lokalizacja10 style=display:none class=titlebar_add>";
		echo "<td width=160 class=right valign=top>&nbsp;Uwagi&nbsp;</td>";
		echo "<td class=left>&nbsp;<textarea name=uwagi cols=46 rows=3></textarea>&nbsp;</td>";
	echo "</tr>";	

	echo "<tr id=lokalizacja11 style=display:none class=titlebar_add>";
	echo "<td width=160 class=right>&nbsp;Gwarancja do dnia&nbsp;</td>";
	echo "<td class=left>&nbsp;<input size=10 maxlength=10 type=text name=gwarancja onkeypress='return handleEnter(this, event)'>&nbsp;";
	echo "<a href=javascript:cal1.popup(); title=' Kliknij, aby wybra� dat� '><img src=img/cal.gif width=16 height=16 border=0></a>";
	
	echo "&nbsp;format RRRR-MM-DD</td>";
	echo "</tr>";
		
// ===================

	echo "<tr id=lokalizacja12 style=display:none class=titlebar_add>";
	echo "<td width=160 class=right>&nbsp;Sprz�t serwisowany przez&nbsp;</td>";
	echo "<td class=left>";
	
	// <input size=20 type=text name=d>
		$sql5="SELECT fs_id, fs_nazwa, fs_adres FROM serwis_firmy_serwisowe ORDER BY fs_nazwa";
		$result5 = mysql_query($sql5, $conn) or die(mysql_error());
		$count_rows = mysql_num_rows($result5);
		$i = 0;
			
		echo "&nbsp;<select ";

		echo "name=firmaserwisowa onkeypress='return handleEnter(this, event)'>\n"; 

		echo "<option value=0>Wybierz firm� serwisow�...</option>\n";
		
		while ($newArray5 = mysql_fetch_array($result5)) 
		 {
			$temp_id1			= $newArray5['fs_id'];
			$temp_1				= $newArray5['fs_nazwa'];
			$temp_2				= $newArray5['fs_adres'];
			
			echo "<option ";			
			echo "value='$temp_id1'>$temp_1</option>\n"; 
		
		}
		
		echo "</select>\n"; 

		echo "</td>";
	echo "</td>";
	echo "</tr>";


// ===================


	echo "<tr id=lokalizacja13 style=display:none class=titlebar_add>";
		echo "<td width=160 class=right>&nbsp;Obs�ugiwany przez&nbsp;</td>";
		echo "<td class=left>&nbsp;";
		
		$query = "SELECT * FROM serwis_filie WHERE filia_id='$es_filia'"; 
		
		if ($result = mysql_query($query,$conn)) 
			{ 
		 		if($success = mysql_num_rows($result) > 0) 
		 			{ 

					  echo "<select name=ubelongs_to  onkeypress='return handleEnter(this, event)'>\n"; 
//  					  echo "<option></option>";		
					  //Now fill the table with data 
					  while ($row = mysql_fetch_array($result)) 
					  { 
						
						$fnazwa = $row['filia_nazwa']; 
						$fid = $row['filia_id']; 
						
						echo "<option value='$fid'>$fnazwa</option>\n"; 
					  } 
					  
		  				echo "</select>\n"; 
					}
			}

		echo "</td>";
	echo "</tr>";
	echo "<tr><td>&nbsp;</td></tr>";	
	echo "<input type=hidden name=status value='9'>";
	echo "<input type=hidden name=oprogramowanie value='0'>";
	echo "</table>";

	echo "<div class=showr>";
	echo "<input class=buttons type=submit name=submit value='Zapisz'><input class=buttons_ok type=button name=anuluj value='Anuluj' onClick='window.close();'>";
	echo "</div>";
	
	echo "</form>";

?>

<script language="JavaScript">
var cal1 = new calendar1(document.forms['addewid'].elements['gwarancja']);
	cal1.year_scroll = true;
	cal1.time_comp = false;
</script>

<script language="JavaScript" type="text/javascript">
  var frmvalidator  = new Validator("addewid");
 
  frmvalidator.addValidation("ts","dontselect=0","Nie wybra�e� typu sprz�tu");
  frmvalidator.addValidation("ls","dontselect=0","Nie wybra�e� lokalizacji sprz�tu");
  frmvalidator.addValidation("gwarancja","numerichyphen","U�y�e� niedozwolonych znak�w w polu \"Gwarancja\"");
 
</script>
<?php } ?>

</body>
</html>