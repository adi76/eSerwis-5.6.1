<?php include_once('header.php'); ?>
<body>
<?php

$sql = "SELECT * FROM serwis_magazyn WHERE magazyn_status='0' and belongs_to='$es_filia'";
$result = mysql_query($sql, $conn) or die(mysql_error());
	
// paging
// ============================================================================================================
$totalrows = mysql_num_rows($result);
if(empty($page)){ $page = 1; }
$limitvalue = $page * $rowpersite - ($rowpersite);
$sql="SELECT * FROM serwis_magazyn WHERE magazyn_status='0' and belongs_to='$es_filia' LIMIT $limitvalue, $rowpersite";
$result = mysql_query($sql, $conn) or die(mysql_error());
// ============================================================================================================
// koniec - paging

if (mysql_num_rows($result)!=0) {

	echo "<h4><center>Pobranie sprz�tu z magazynu</center></h4>";
	echo "<table cellspacing=1 align=center class=titlebar_add width=95%>";

	echo "<tr class=titlebar_add_n>";
	echo "<td><center>LP</center></td>";
	echo "<td>&nbsp;Nazwa</td>";
	echo "<td>&nbsp;Model</td>";
	echo "<td>&nbsp;Numer seryjny</td>";
	echo "<td>&nbsp;Numer inwentarzowy</td>";
	echo "<td><center>Uwagi</center></td>";
	echo "<td><center>Czynno�ci</center></td>";
	echo "</tr>";

$i = $page*$rowpersite-$rowpersite;

while ($dane = mysql_fetch_array($result)) {


	
  $mid 		= $dane['magazyn_id'];
  $mnazwa 	= $dane['magazyn_nazwa'];
  $mmodel	= $dane['magazyn_model'];
  $msn	 	= $dane['magazyn_sn'];
  $mni		= $dane['magazyn_ni'];
  $muwagi	= $dane['magazyn_uwagi_sa'];

 	if ($i % 2 != 0 ) echo "<tr id=$i class=nieparzyste onmouseover=rowOver('$i',1); this.style.cursor=arrow onmouseout=rowOver('$i',0) onclick=selectRow('$i') ondblclick=deSelectRow('$i')>";
	if ($i % 2 == 0 ) echo "<tr id=$i class=parzyste onmouseover=rowOver('$i',1); this.style.cursor=arrow onmouseout=rowOver('$i',0) onclick=selectRow('$i') ondblclick=deSelectRow('$i')>";

$i++;
echo "<td width=20 align=center>$i</td>";						

	echo "<td>&nbsp;$mnazwa</td>";
	echo "<td>&nbsp;$mmodel</td>";
	echo "<td>&nbsp;$msn</td>";
	echo "<td>&nbsp;$mni</td>";

if ($muwagi=='1') {
  echo "<td width=40 align=center><input type=image src=img/comment.gif title=' Czytaj uwagi ' onclick=\"newWindow(450,360,'p_magazyn_uwagi.php?id=$mid')\"></td>";
} else echo "<td>&nbsp;</td>";

echo "<td align=center width=50>";
	//							echo "<a class=opt href=generatem.php?id=$mid&h=0&type=2 target=_blank>&nbsp;protok�&nbsp;</a><br>";				
	
	
	
echo "<input type=image src=img/pobierz.gif title=' Pobierz sprz�t z magazynu ' onclick=\"newWindow(590,360,'pobierz.php?id=$mid&part=$mnazwa')\"></td>";

//echo "<td align=center width=50><a href=pobierz.php?id=$mid&part=$mnazwa target=_blank title='Pobierz sprz�t z magazynu'>P</a> | <a href=magazyn_zarezerwuj.php?id=$mid target=_blank title='Zarezerwuj sprz�t'>Z</a> | <a href=e_magazyn_ukryj.php?id=$mid target=_blank title='Ukryj sprz�t'>U</a></td>";


echo "</tr>";
	
}

echo "</table>";

// paging 
// ==================================================================================
echo "<br><center>";
//$phpfile = $linkdostrony."main.php?action=bu";
$phpfile = $PHP_SELF;

if($page != 1){  
        //$pageprev = $page--; 
        $pageprev = $page - 1;
		 
        echo("<a class=nav_normal href=\"$phpfile?submit=$submit&page=$pageprev\">Poprzednia strona</a> ");  
    }else{ 
        echo("<a class=nav_current_first>Poprzednia strona</a>"); 
    } 

    $numofpages = $totalrows / $rowpersite;  
     
    for($i = 1; $i <= $numofpages; $i++){ 
        if($i == $page){ 
            echo("<a class=nav_current>$i</a>"); 
        }else{ 
            echo("<a class=nav_normal href=\"$phpfile?submit=$submit&page=$i\">$i</a> "); 
        } 
    } 


    if(($totalrows % $rowpersite) != 0){ 
        if($i == $page){ 
            echo("<a class=nav_current>$i</a>"); 
        }else{ 
            echo("<a class=nav_normal href=\"$phpfile?submit=$submit&page=$i\">$i</a> "); 
        } 
    } 

    if(($totalrows - ($rowpersite * $page)) > 0){ 
//        $pagenext = $page++; 
          $pagenext = $page + 1;        
		  
        echo("<a class=nav_normal href=\"$phpfile?submit=$submit&page=$pagenext\">Nast�pna strona</a>");  
    }else{ 
        echo("<a class=nav_current_last>Nast�pna strona</a>");  
    } 

echo "</center><br>";
// ==================================================================================
// koniec paging



} else
  echo "<h2><center>Brak sprz�tu na magazynie</center></h2>";


	echo "<p align=right><input class=buttons type=button onClick=window.close() value='Zamknij'>&nbsp;&nbsp;&nbsp;&nbsp;</p>";
?>

</body>
</html>