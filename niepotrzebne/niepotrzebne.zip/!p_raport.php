<?php /* new CSS */ ?>
<?php include_once('header.php'); ?>
<body>
<?php

// ilosc otwartych zg�osze� awarii
$sql = "SELECT awaria_id FROM serwis_awarie WHERE awaria_status='0' and belongs_to='$es_filia'";
$result = mysql_query($sql, $conn) or die(mysql_error());
$awarie_otwarte_ilosc = mysql_num_rows($result);

// Czynno�ci do wykonania
$accessLevels = array("9"); 
if(array_search($es_prawa, $accessLevels)>-1)
{
	$sql = "SELECT todo_id FROM serwis_komorka_todo WHERE belongs_to=$es_filia and todo_status=1";
} else 
{
	$sql = "SELECT todo_id FROM serwis_komorka_todo WHERE ((belongs_to=$es_filia) and (todo_status=1) and (todo_przypisane_osobie='$currentuser') or (todo_przypisane_osobie=''))";
}

$result = mysql_query($sql, $conn) or die(mysql_error());
$czynnosci_do_wykonania_ilosc = mysql_num_rows($result);

// Czynno�ci do wykonania dla osoby
$accessLevels = array("9"); 
if(array_search($es_prawa, $accessLevels)>-1)
{
	$sql = "SELECT todo_id FROM serwis_komorka_todo WHERE belongs_to=$es_filia and todo_status=1";
} else 
{
	$sql = "SELECT todo_id FROM serwis_komorka_todo WHERE ((belongs_to=$es_filia) and (todo_status=1) and (todo_przypisane_osobie='$currentuser'))";
}

$result = mysql_query($sql, $conn) or die(mysql_error());
$czynnosci_do_wykonania_osoba_ilosc = mysql_num_rows($result);

// Ilo�� otwartych zada�
$sql = "SELECT zadanie_id FROM serwis_zadania WHERE zadanie_status=1 and belongs_to='$es_filia'";
$result = mysql_query($sql, $conn) or die(mysql_error());
$zadania_otwarte_ilosc = mysql_num_rows($result);

if (($awarie_otwarte_ilosc>0) || ($czynnosci_do_wykonania_ilosc>0) || ($zadania_otwarte_ilosc>0)) 
{
echo "<br>";
echo "<h4>Informacje zbiorcze z bazy eSerwis</h4>";
echo "<div id=praport class=center>";
echo "<table cellspacing=1 align=center>";

if ($awarie_otwarte_ilosc>0) {
	echo "<tr><th colspan=2><center>Awarie</center></th></tr>";
	echo "<tr><td align=left>&nbsp;<a title=' Ilo�� otwartych zg�osze� awarii '  class=normalfont href=z_awarie.php>Ilo�� otwartych zg�osze� awarii&nbsp;<img src=img/goto.gif border=0 align=bottom></td><td class=center>";
	if ($awarie_otwarte_ilosc>0)  echo "<b>";  
	echo "$awarie_otwarte_ilosc";
	if ($awarie_otwarte_ilosc>0)  echo "</b>";  
	echo "</td></tr>";
}

if ($czynnosci_do_wykonania_ilosc>0) {

if ($czynnosci_do_wykonania_osoba_ilosc>0) 
{
$accessLevels = array("9"); 
if(array_search($es_prawa, $accessLevels)>-1)
{
	echo "<tr><th colspan=2><center>Czynno�ci do wykonania w filii/oddziale</center></th></tr>";
} else
{
	echo "<tr><th colspan=2><center>$currentuser : czynno�ci do wykonania</center></th></tr>";
}

$accessLevels = array("9"); 
if(array_search($es_prawa, $accessLevels)>-1)
{
	$sql = "SELECT DISTINCT todo_up_id FROM serwis_komorka_todo WHERE (todo_status=1) and (belongs_to=$es_filia)";
} else 
{
	$sql = "SELECT DISTINCT todo_up_id FROM serwis_komorka_todo WHERE ((todo_status=1) and (belongs_to=$es_filia) and (todo_przypisane_osobie='$currentuser'))";
}

$result = mysql_query($sql, $conn) or die(mysql_error());
while ($dane1 = mysql_fetch_array($result)) {

	$temp_id = $dane1['todo_up_id'];
	$temp_termin = $dane1['todo_termin_koncowy'];
	
	$accessLevels = array("9"); 
	if(array_search($es_prawa, $accessLevels)>-1)
	{
		$sql3 = "SELECT todo_up_id FROM serwis_komorka_todo WHERE (todo_status=1) and (belongs_to=$es_filia) and (todo_up_id=$temp_id)";
	} else 
	{
		$sql3 = "SELECT todo_up_id FROM serwis_komorka_todo WHERE ((todo_status=1) and (belongs_to=$es_filia) and (todo_przypisane_osobie='$currentuser') and (todo_up_id=$temp_id))";
	}	

	$result3 = mysql_query($sql3, $conn) or die(mysql_error());
	$ilosc = mysql_num_rows($result3);
	
	$sql2 = "SELECT up_nazwa FROM serwis_komorki WHERE ((belongs_to='$es_filia') and (up_id='$temp_id')) LIMIT 1";
	$result2 = mysql_query($sql2, $conn) or die(mysql_error());
	
	$dane = mysql_fetch_array($result2);
	$up = $dane['up_nazwa'];
	
	if ($ilosc>0) {

		echo "<tr><td class=normalfont align=left>&nbsp;<a title=' Ilo�� czynno�ci do wykonania dla $up = $ilosc ' class=normalfont onclick=\"newWindow1(800,400,'p_komorka_czynnosc.php?id=$temp_id&filtruj=$currentuser')\" href='#'>$up&nbsp;";
		echo "<img src=img/goto.gif border=0 align=bottom >";
	
	$dddd = date("Y-m-d H:i:s");
	$sql4 = "SELECT todo_id FROM serwis_komorka_todo WHERE ((belongs_to=$es_filia) and (todo_up_id=$temp_id) and (todo_status=1) and (todo_termin_koncowy<>'0000-00-00 00:00:00') and (todo_termin_koncowy<'$dddd'))";

	$result4 = mysql_query($sql4, $conn) or die(mysql_error());
	$ilosc_po_terminie = mysql_num_rows($result4);

	if ($ilosc_po_terminie>0) echo "&nbsp; ( dla $ilosc_po_terminie czynno�ci up�yn�� termin wykonania )";
	
	echo "</a>";
	echo "</td><td class=center>$ilosc szt</td></tr>";
	}

//}
}
}
// === czynno�ci og�lne dla wszystkich

$accessLevels = array("0"); 
if(array_search($es_prawa, $accessLevels)>-1)
{

echo "<tr><th colspan=2><center>Czynno�ci do wykonania w filii/oddziale (nie przypisane do osoby)</center></th></tr>";

$sql = "SELECT DISTINCT todo_up_id FROM serwis_komorka_todo WHERE ((todo_status=1) and (belongs_to=$es_filia) and (todo_przypisane_osobie=''))";


$result = mysql_query($sql, $conn) or die(mysql_error());

while ($dane1 = mysql_fetch_array($result)) {

	$temp_id = $dane1['todo_up_id'];
	$temp_termin = $dane1['todo_termin_koncowy'];

	$accessLevels = array("9"); 
	if(array_search($es_prawa, $accessLevels)>-1)
	{
		$sql3 = "SELECT todo_up_id FROM serwis_komorka_todo WHERE (todo_status=1) and (belongs_to=$es_filia) and (todo_up_id=$temp_id)";
	} else 
	{
		$sql3 = "SELECT todo_up_id FROM serwis_komorka_todo WHERE ((todo_status=1) and (belongs_to=$es_filia) and (todo_przypisane_osobie='') and (todo_up_id=$temp_id))";
	}

	$result3 = mysql_query($sql3, $conn) or die(mysql_error());
	$ilosc = mysql_num_rows($result3);
	
	$sql2 = "SELECT up_nazwa FROM serwis_komorki WHERE ((belongs_to='$es_filia') and (up_id='$temp_id')) LIMIT 1";
	$result2 = mysql_query($sql2, $conn) or die(mysql_error());
	
	$dane = mysql_fetch_array($result2);
	
	$up = $dane['up_nazwa'];
	
	if ($ilosc>0) {

		echo "<tr><td class=normalfont align=left>&nbsp;<a title=' Ilo�� czynno�ci do wykonania dla $up = $ilosc ' class=normalfont onclick=\"newWindow1(800,400,'p_komorka_czynnosc.php?id=$temp_id')\" href='#'>$up&nbsp;";
		echo "<img src=img/goto.gif border=0 align=bottom >";
	
	$dddd = date("Y-m-d H:i:s");
	$sql4 = "SELECT todo_id FROM serwis_komorka_todo WHERE ((belongs_to=$es_filia) and (todo_up_id=$temp_id) and (todo_status=1) and (todo_termin_koncowy<>'0000-00-00 00:00:00') and (todo_termin_koncowy<'$dddd'))";

	$result4 = mysql_query($sql4, $conn) or die(mysql_error());
	$ilosc_po_terminie = mysql_num_rows($result4);

	if ($ilosc_po_terminie>0) echo "&nbsp; ( dla $ilosc_po_terminie czynno�ci up�yn�� termin wykonania )";
	
	echo "</a>";
	echo "</td><td align=center>$ilosc szt</td></tr>";
	}

//}
}
}

}

if ($zadania_otwarte_ilosc>0) {

$accessLevels = array("9"); 
//if(array_search($es_prawa, $accessLevels)>-1)
//{
	echo "<tr><th colspan=2><center>Zadania do wykonania w filii/oddziale</center></th></tr>";
//} else
//{
//	echo "<tr><th colspan=2><center>$username : zadania do wykonania</center></th></tr>";
//}

$sql = "SELECT * FROM serwis_zadania WHERE (zadanie_status=1)";

if ($es_m==1) $sql=$sql." and (belongs_to=$es_filia)";

$sql=$sql." ORDER BY zadanie_termin_zakonczenia ASC";

$result = mysql_query($sql, $conn) or die(mysql_error());

while ($dane1 = mysql_fetch_array($result)) {

	$temp_id 		= $dane1['zadanie_id'];
	$temp_opis	 	= $dane1['zadanie_opis'];
	$temp_termin	= $dane1['zadanie_termin_zakonczenia'];
	$temp_priorytet	= $dane1['zadanie_priorytet'];
	$temp_uwagi		= $dane1['zadanie_uwagi'];
	
	$termin = substr($temp_termin,0,10);
	$dzisiaj = Date("Y-m-d");
	
	echo "<tr><td class=normalfont align=left>&nbsp;<a title=' Poka� UP/kom�rki przypisane do zadania $temp_opis ' class=normalfont onclick=\"newWindow_r1(800,600,'p_zadanie_pozycje.php?id=$temp_id')\" href='#'>$temp_opis&nbsp;";
	echo "<a title=' Czytaj uwagi do zadania'><input type=image align=absmiddle src=img/comment.gif onclick=\"newWindow2(480,265,'p_zadania_uwagi.php?id=$temp_id')\"></a>";
	echo "<img src=img/goto.gif border=0 align=bottom ></a>&nbsp;";
	
	$pozostalo_dni = round( abs(strtotime($dzisiaj)-strtotime($termin)) / 86400, 0 );
	
if ($termin!='0000-00-00') 
{
	if ($dzisiaj<$termin)
	{
		echo "<br>&nbsp;termin zako�czenia zadania up�ywa $termin (za $pozostalo_dni dni)";
	} else 
	{
		
		echo "<br>&nbsp;<font color=red><b>termin wykonania zadania ";
		if ($pozostalo_dni!=0) { echo "up�yn�� $termin ($pozostalo_dni dni temu)"; } else { echo "up�ywa dzisiaj !!!"; }
		echo "</b></font>";
	}
} else echo "<br>&nbsp;brak okre�lonego terminu zako�czenia zadania";	
	echo "</td>";

	$sql1="SELECT * FROM serwis_zadania_pozycje WHERE (pozycja_zadanie_id=$temp_id)";
	$result1 = mysql_query($sql1, $conn) or die(mysql_error());
	$countall = mysql_num_rows($result1);
	
	$sql2="SELECT * FROM serwis_zadania_pozycje WHERE (pozycja_zadanie_id=$temp_id) and (pozycja_status=9)";
	$result2 = mysql_query($sql2, $conn) or die(mysql_error());
	$countwyk = mysql_num_rows($result2);

	if ($countall>0) { $procent_ = ($countwyk/$countall)*100; } else $procent_=0;
	$procent = round_up($procent_, 2);
	
	echo "<td width=200 class=center>&nbsp;wykonano : <b>$procent%</b></td>";
	
	echo "</tr>";
	}
  }
}

echo "</table>";
?>

</body>
</html>