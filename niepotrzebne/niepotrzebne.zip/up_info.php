<?php include_once('header.php'); ?>

<body>

<?php

$sql1 = "SELECT * FROM serwis_komorki WHERE up_id='$uid'";
$result1 = mysql_query($sql1, $conn) or die(mysql_error());

if (mysql_num_rows($result1)!=0) {
   
   $dane = mysql_fetch_array($result1);
   
								  $mid 		= $dane['up_id'];
								  $mnazwa 	= $dane['up_nazwa'];
								  $madres	= $dane['up_adres'];
								  $mopis	 	= $dane['up_opis'];
								  $mip		= $dane['up_ip'];
								  $mnrwanportu	= $dane['up_nrwanportu'];
								  $mtelefon	= $dane['up_telefon'];

	echo "<br><table cellspacing=1 align=center width=100%>";
	
	echo "<tr><td><font size=2>&nbsp;Telefon/y : </font></td><td><b><font size=2>$mtelefon</font></b></td></tr>";
	echo "<tr><td><font size=2>&nbsp;Podsie�   : </font></td><td><font size=2>$mip</font></td></tr>";

	echo "</table>";
   
} else echo "brak";

	echo "<br><center><input class=buttons type=button onClick=window.close() value='&nbsp;&nbsp;&nbsp;&nbsp;ZAMKNIJ&nbsp;&nbsp;&nbsp;&nbsp;'></center>";
?>

</body>
</html>