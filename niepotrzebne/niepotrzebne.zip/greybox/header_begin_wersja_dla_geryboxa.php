<?php include_once('header_simple.php'); ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<HTML>
<HEAD>
	<META http-equiv="Content-Type" content="text/html; charset=windows-1250">
	<TITLE><?php echo "$nazwa_aplikacji"; ?></TITLE>		
	<?php
		if ($es_style=='') { $template='oryginal'; } else $template=$es_style;
	?>
	<link rel="stylesheet" type="text/css" href="templates/<?php echo $template;?>/listmenu_h.css" id="listmenu-h" />
	<link rel="stylesheet" type="text/css" id="serwis" href="templates/<?php echo $template;?>/serwis.css" />
	<script type="text/javascript" src="templates/<?php echo $template;?>/lightrow.js"></script>
	<script type="text/javascript" src="js/fsmenu.js"></script>
	<script type="text/javascript" src="js/moje.js"></script>
	<script type="text/javascript" src="js/calendar1.js"></script>
	<?php //echo "<script type=text/javascript src=js/skinnytip.js></script>"; ?>
	<script type="text/javascript" src="js/BubbleTooltips.js"></script>
	<?php // echo "<script type=text/javascript src=js/textsizer.js>"; ?>
	<script type="text/javascript">
		var GB_ROOT_DIR = "<?php echo $linkdostrony;?>js/greybox/";
	</script>
	<script type="text/javascript">
	<?php if ($tooltips==1) { ?>
		window.onload=function(){enableTooltips("content")};
	<?php } ?>	
	</script>
	
	<script type="text/javascript" src="js/greybox/AJS.js"></script>
	<script type="text/javascript" src="js/greybox/AJS_fx.js"></script>
	<script type="text/javascript" src="js/greybox/gb_scripts.js"></script>
	<link href="js/greybox/gb_styles.css" rel="stylesheet" type="text/css" />

	
