<?php 
include_once('header.php');

	$sql55="SELECT * FROM serwis_slownik_oprogramowania";
	$result55 = mysql_query($sql55, $conn) or die(mysql_error());
				
			while ($newArray55 = mysql_fetch_array($result55)) 
			{
				$opr_id					= $newArray55['oprogramowanie_slownik_id'];		
				$opr_nazwa				= $newArray55['oprogramowanie_slownik_nazwa'];		
			
			
				$sql555="UPDATE serwis_oprogramowanie SET oprogramowanie_nazwa='$opr_nazwa' WHERE (oprogramowanie_slownik_id=$opr_id)";
//				echo "$sql555<br>";
				$result555 = mysql_query($sql555, $conn) or die(mysql_error());			
			}
	?>
	<script>
	alert('Baza oprogramowania zosta�a zaktualizowana');
	self.close();	
	</script>
	<?php			
//	echo "<h4><br><center>Zmiany zosta�y wprowadzone</center><br></h4>";
//	echo "<br><p align=center><input class=buttons type=button onClick=window.close() value='&nbsp;&nbsp;&nbsp;Zamknij&nbsp;&nbsp;&nbsp;'></p>";
?>
