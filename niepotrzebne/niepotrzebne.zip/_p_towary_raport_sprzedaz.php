<?php include_once('header.php'); ?>

<body>

<?php 
include('inc_encrypt.php');

if ($zatwierdz=='Zatwierd� raport') 
{ 
	$ile = $_REQUEST[ilosc];
	
	$o = 1;
	while ($o<$ile)
	{
		
		$tcena			= $_REQUEST['tc'.$o];
		$sprzedazid		= $_REQUEST['sid'.$o];
		$pozid			= $_REQUEST['pid'.$o];
		$fakid			= $_REQUEST['fnr'.$o];
		
		$cenatwoja 		= str_replace(',','.',$tcena);
		$cenatwoja_cr 	= crypt_md5($cenatwoja,$key);
		
		$miesiac = substr($okres_do,5,2);
		$rok = substr($okres_do, 0,4);
		
		$sql_u = "UPDATE serwis_sprzedaz SET sprzedaz_pozycja_cenatwoja='$cenatwoja_cr', sprzedaz_status='9' WHERE sprzedaz_id=$sprzedazid LIMIT 1";
		$result_u = mysql_query($sql_u, $conn);

		$sql_u = "UPDATE serwis_faktura_szcz SET pozycja_status=9 WHERE pozycja_id=$pozid LIMIT 1";
		$result_u = mysql_query($sql_u, $conn);

		$sql_u = "UPDATE serwis_faktury SET faktura_status=9 WHERE faktura_id=$fakid LIMIT 1";
		$result_u = mysql_query($sql_u,$conn);
		
		$sql_u = "INSERT INTO serwis_sprzedaz_raport VALUES ('',$rok,$miesiac,$es_filia)";
		$result_u = mysql_query($sql_u,$conn);

	  $o++;
	}
	
//	echo "zapisane zmiany"; 
	$submit='Generuj raport';
	$zapiszzmiany='koniec';
	$zatwierdz='koniec';
}

if ($zapiszzmiany=='Zapisz zmiany') 
{ 
	$ile = $_REQUEST[ilosc];
	
	$o = 1;
	while ($o<$ile)
	{
		$tcena			= $_REQUEST['tc'.$o];
		$sprzedazid		= $_REQUEST['sid'.$o];
		
		$cenatwoja 		= str_replace(',','.',$tcena);
		$cenatwoja_cr 	= crypt_md5($cenatwoja,$key);

		$sql_u = "UPDATE serwis_sprzedaz SET sprzedaz_pozycja_cenatwoja='$cenatwoja_cr' WHERE sprzedaz_id=$sprzedazid LIMIT 1";
		//echo "$sql_u<br>";
		$result_u = mysql_query($sql_u, $conn);
	
	  $o++;
	}
	
	echo "<h3>Zmiany zosta�y zapisane</h3>"; 
	$submit='Generuj raport';
	$zapiszzmiany = 'koniec';
}	

if ($submit) { 
$unique=rand(0,999999);

$sql99="TRUNCATE TABLE serwis_temp_raport$es_filia";
$result99=mysql_query($sql99,$conn) or die(mysql_error());

$tumowa=$_GET[tumowa];
$okres_od=$_GET[okres_od];
$okres_do=$_GET[okres_do];
$tfilia = $_GET[tfilia];

if (($tumowa!='') && ($okres_od!='') && ($okres_do!='')) {

if ($tfilia=='all') 
{
	$sql_a = "SELECT * FROM serwis_sprzedaz WHERE sprzedaz_data BETWEEN '$okres_od' AND '$okres_do' ORDER BY sprzedaz_typ ASC";
} else {
	$sql_a = "SELECT * FROM serwis_sprzedaz WHERE belongs_to='$tfilia' and sprzedaz_data BETWEEN '$okres_od' AND '$okres_do' ORDER BY sprzedaz_typ ASC";
}

//echo "$sql_a";

//echo $tfilia;

$result_a = mysql_query($sql_a, $conn) or die(mysql_error());
$count_rows=0;

while ($dane3 = mysql_fetch_array($result_a)) {
  $count_rows+=1;				
}

if ($count_rows==0) {

  echo "<h2>Nie znaleziono pozycji spe�niaj�cych podane przez Ciebie kryteria</h2>";
	echo "<p align=right><input class=buttons type=button onClick=\"window.history.go(-1)\" value='Zmie� kryteria'>&nbsp;";
	echo "<input class=startpage type=button onClick=\"window.location.href='$linkdostronyglownej'\" value='Wr�� do strony g��wnej'>&nbsp;&nbsp;&nbsp;&nbsp;</p>";
	echo "</body></html>";
  exit;
  
} else {

	echo "<h4><center>Generowanie raportu ze sprzeda�y z okresu</h4><h5>$okres_od - $okres_do<br><br>";
	if ($tumowa!='all') { echo "dla umowy nr $tumowa</h5>"; } else echo "dla wszystkich um�w przypisanych do aktualnej filii/oddzia�u</center></h5>";

echo "<div align=center>";
echo "<table cellspacing=1 class=titlebar_add align=center width=98%>";
echo "<tr class=titlebar_add_n>";
echo "<th width=30><center>LP</center></th><th>&nbsp;Nazwa towaru</th><th width=80><center>Cena netto&nbsp;<br>&nbsp;z faktury</center></th><th width=80><center>Cena netto&nbsp;<br>&nbsp;zakupu</center></th><th width=100><center>Sugerowana cena<br>odsprzeda�y</center></th><th width=100><center>&nbsp;Twoja cena&nbsp;netto odsprzeda�y</center></th><th>&nbsp;Sprzedano dla</th><th>&nbsp;Nr zlecenia&nbsp;</th><th><center>Opcje</center></th>";

echo "</tr>";
}

if ($tumowa=='all') { 
	$sql = "SELECT * FROM serwis_sprzedaz WHERE (belongs_to='$es_filia') and (sprzedaz_data BETWEEN '$okres_od' AND '$okres_do') ORDER BY sprzedaz_typ ASC";

} else {
$sql = "SELECT * FROM serwis_sprzedaz WHERE (belongs_to='$es_filia') and (sprzedaz_umowa_nazwa='$tumowa') and (sprzedaz_data BETWEEN '$okres_od' AND '$okres_do') ORDER BY sprzedaz_typ ASC";
}

//echo "$sql";

$result = mysql_query($sql, $conn) or die(mysql_error());

$i = 0;
$j = 1;
$pokaz_zapis=0;

echo "<form action=$PHP_SELF METHOD=GET>";
	
while ($newArray = mysql_fetch_array($result)) {
	$temp_id  			= $newArray['sprzedaz_id'];
	$temp_poz_pid		= $newArray['sprzedaz_pozycja_id'];
	$temp_poz_nazwa		= $newArray['sprzedaz_pozycja_nazwa'];
	$temp_poz_sn		= $newArray['sprzedaz_pozycja_sn'];
	$temp_poz_cena_cr	= $newArray['sprzedaz_pozycja_cenanetto'];

	$temp_poz_cenaodsp_cr	= $newArray['sprzedaz_pozycja_cenaodsp'];
	$temp_poz_cenatwoja_cr	= $newArray['sprzedaz_pozycja_cenatwoja'];

	$temp_data			= $newArray['sprzedaz_data'];
	$temp_umowa			= $newArray['sprzedaz_umowa_nazwa'];
	$temp_pion			= $newArray['sprzedaz_pion_nazwa'];
	$temp_up			= $newArray['sprzedaz_up_nazwa'];
	$temp_uwagi			= $newArray['sprzedaz_uwagi'];
	$temp_fakt_id		= $newArray['sprzedaz_faktura_id'];
	$temp_rodzaj		= $newArray['sprzedaz_rodzaj'];
	$temp_typ			= $newArray['sprzedaz_typ'];

	$temp_status		= $newArray['sprzedaz_status'];

	$sql2 = "SELECT * FROM serwis_umowy WHERE (umowa_nr='$temp_umowa')";
	$result2 = mysql_query($sql2, $conn) or die(mysql_error());	
	$newArray2 = mysql_fetch_array($result2);
	$temp_nrzlecenia = $newArray2['umowa_nr_zlecenia'];

	if ($temp_status=='9') $zatwierdz='koniec';
	
	echo "<input type=hidden name=sid$j value=$temp_id>";
	echo "<input type=hidden name=pid$j value=$temp_poz_pid>";
	
	$temp_poz_cena	= decrypt_md5($temp_poz_cena_cr,$key);
	
	$temp_poz_cenaodsp	= decrypt_md5($temp_poz_cenaodsp_cr,$key);	
	$temp_poz_cenatwoja	= decrypt_md5($temp_poz_cenatwoja_cr,$key);	
 	
	if ($i % 2 != 0 ) echo "<tr id=$i class=nieparzyste onmouseover=rowOver('$i',1); this.style.cursor=arrow onmouseout=rowOver('$i',0) onclick=selectRow('$i') ondblclick=deSelectRow('$i')>";
	if ($i % 2 == 0 ) echo "<tr id=$i class=parzyste onmouseover=rowOver('$i',1); this.style.cursor=arrow onmouseout=rowOver('$i',0) onclick=selectRow('$i') ondblclick=deSelectRow('$i')>";
	
//	echo "<a class=opt href=p_faktura_pozycje.php?id=$temp_nrfaktury target=_blank title=' Poka� pozycje na fakturze '>";
	echo "<td width=30><center>$j</center></td>";

	$sql1="SELECT * FROM serwis_faktury WHERE ((belongs_to='$es_filia') and (faktura_id='$temp_fakt_id'))";
	//echo "$sql1";

	$result1 = mysql_query($sql1, $conn) or die(mysql_error());
	
	while ($newArray4 = mysql_fetch_array($result1)) {
		$temp_id4  			= $newArray4['faktura_id'];
		$temp_numer4		= $newArray4['faktura_numer'];
		$temp_data4			= $newArray4['faktura_data'];
		$temp_dostawca4		= $newArray4['faktura_dostawca'];	
	}
	
	echo "<input type=hidden name=fnr$j value='$temp_id4'>";
	
	//echo "<a class=opt3 onclick=\"newWindow_r(800,600,'p_faktura_pozycje.php?id=$temp_id4')\">";
	echo "<td align=left>&nbsp;$temp_poz_nazwa&nbsp;";
	
	echo "</td>";
	echo "<td>"; 
	
	if ($temp_poz_cena!=0) { echo "<center>$temp_poz_cena z�</center>"; }
	
	echo "</td>";
	echo "<td><center>";
	echo "$temp_poz_cenaodsp z�";
	echo "</center></td>";

	$cena_z_marza = (float) $temp_poz_cenaodsp * 1.1;
	
	if ($temp_poz_cenatwoja=='') $temp_poz_cenatwoja = $cena_z_marza;
	
	echo "<td><center>$cena_z_marza z�</center></td>";	// cena odsprzeda�y
	echo "<td>";

	if (($zatwierdz!='koniec') and ($temp_status!=9))
	{
		echo "&nbsp;<input type=text maxlength=10 name=tc$j size=9 value='$temp_poz_cenatwoja'>&nbsp;z�&nbsp;";
	} else
		{
			echo "<center><input type=hidden maxlength=10 name=tc$j value='$temp_poz_cenatwoja'>&nbsp;$temp_poz_cenatwoja&nbsp;z�&nbsp;</center>";
		}
	
	if ($temp_status==1) $pokaz_zapis=1;
	
	echo "</td>";	// twoja cena
	echo "<td align=left>&nbsp;";
	
	if ($temp_pion!="") { echo "$temp_pion&nbsp;"; } 
	
	echo "$temp_up</td>";


	echo "<td>&nbsp;$temp_nrzlecenia</td>";
	$j+=1;
	
	$r=substr($temp_data,0,4);
	$m=substr($temp_data,5,2);
	$d=substr($temp_data,8,2);
	
	
	$s1=strpos($temp_up,' ');
	$upup=substr($temp_up,$s1+1,strlen($temp_up)-$s1);
	
	echo "<td width=60><center>";
	
	$cena = str_replace('.',',',$temp_poz_cena);
	
	$cenan1 = $temp_poz_cena*1.1;
	$cenan = str_replace('.',',',$cenan1);
	
//	$raport_cena_z_faktury = crypt_md5($cena,$key);
//	$raport_cena_twoja_cr = crypt_md5($temp_poz_cenatwoja,$key);

	$raport_cena_z_faktury_cr = str_replace('.',',',$cena);
	$raport_cena_twoja_cr = str_replace('.',',',$temp_poz_cenatwoja);

	//$cena = str_replace('.',',',$temp_poz_cena);
	
	$sql99="INSERT INTO serwis_temp_raport$es_filia VALUES ('$temp_poz_nazwa','$temp_up','1','szt.','$raport_cena_z_faktury_cr z�','$raport_cena_twoja_cr z�','$temp_numer4','$temp_data4','$temp_dostawca4','$temp_rodzaj','$unique','$temp_nrzlecenia')";
	//echo "$sql99";
	$result99=mysql_query($sql99,$conn) or die(mysql_error());		
	
	echo "</center></td>";

	$i+=1;
	echo "</tr>";
}



echo "</table>";
echo "</div>";

$sqlf="SELECT * FROM serwis_filie WHERE filia_id='$es_filia'";
$resultf = mysql_query($sqlf, $conn) or die(mysql_error());
$dane1f = mysql_fetch_array($resultf);
$filian = $dane1f['filia_nazwa'];
	
		if (($zatwierdz!='koniec') or ($pokaz_zapis==1))
		{
			echo "<p align=right>";	
			echo "<input class=buttons type=button name=odswiez onClick=window.location.reload(true); value='Cofnij niezapisane zmiany'>&nbsp;";	
			echo "<input class=buttons type=submit name=zapiszzmiany value='Zapisz zmiany'>&nbsp;";	
			echo "<input class=buttons type=submit name=zatwierdz value='Zatwierd� raport'>&nbsp;&nbsp;&nbsp;&nbsp;";	
			echo "</p>";		
		}
		
		echo "<input type=hidden name=ilosc value=$j>";
		echo "<input type=hidden name=okres_od value='$okres_od'>";
		echo "<input type=hidden name=okres_do value='$okres_do'>";	
		echo "<input type=hidden name=tumowa value='$tumowa'>";	

	echo "</form>";

	
	echo "<center>";
	echo "<form action=do_xls.php METHOD=POST target=_blank>";
	
	$rr = substr($okres_do,0,4);
	$mm = substr($okres_do,5,2);
	
	echo "<input type=hidden name=r_rok value='$rr'>";
	echo "<input type=hidden name=r_miesiac value='$mm'>";	
	echo "<input type=hidden name=poczatek value='$okres_od'>";
	echo "<input type=hidden name=koniec value='$okres_do'>";
	echo "<input type=hidden name=umowanr value='$tumowa'>";
	echo "<input type=hidden name=unique value=$unique>";
	echo "<input type=hidden name=filian value=$filian>";
		
	echo "<p align=right>";
	
	if ($zatwierdz=='koniec')
	{
		echo "<input class=buttons type=submit name=refresh_ value='Generuj plik XLS'>&nbsp;";
	}
	
	echo "<input class=buttons type=button onClick=\"window.location.href='main.php?action=grzs'\" value='Zmie� kryteria'>&nbsp;";
	echo "<input class=startpage type=button onClick=\"window.location.href='$linkdostronyglownej'\" value='Wr�� do strony g��wnej'>&nbsp;&nbsp;&nbsp;&nbsp;";

	echo "</p></form>";	
	
} else
     {
		echo "<br><h2>Nie wype�ni�e� wymaganych p�l</h2>"; 
	echo "<p align=right><input class=buttons type=button onClick=\"window.location.href='main.php?action=grzs'\" value='Zmie� kryteria'>&nbsp;";
	echo "<input class=startpage type=button onClick=\"window.location.href='$linkdostronyglownej'\" value='Wr�� do strony g��wnej'>&nbsp;&nbsp;&nbsp;&nbsp;</p>";
}

} else { ?>

<?php

	echo "<br><h4><center>Generowanie raportu ze sprzeda�y w okresie</center></h4>";
	echo "<form name=ruch action=p_towary_raport_sprzedaz.php method=GET>";
	echo "<div align=center>";
	echo "<table cellspacing=1 align=center class=titlebar_add width=400";
	echo "<tr class=titlebar_add><td>&nbsp;</td></tr>";

	echo "<tr class=titlebar_add>";
	echo "<td align=center colspan=2>";
	echo "<b>Podaj zakres dat<br><br></b>";
	echo "</td>";
	echo "</tr>";
	
		echo "<tr class=titlebar_add>";
		echo "<td width=150 align=center>&nbsp;od dnia&nbsp;</td>";
		echo "<td width=150 align=center>&nbsp;do dnia&nbsp;</td>";
		echo "</tr>";

	$r1 = Date('Y');
	$m1 = Date('m');
	$d1 = '01';
	
	$r2 = Date('Y');
	$m2 = Date('m');
	
	if ($m2==1) $d2=31;
	if ($m2==2) $d2=28;
	if ($m2==3) $d2=31;
	if ($m2==4) $d2=30;
	if ($m2==5) $d2=31;
	if ($m2==6) $d2=30;
	if ($m2==7) $d2=31;
	if ($m2==8) $d2=31;
	if ($m2==9) $d2=30;
	if ($m2==10) $d2=31;
	if ($m2==11) $d2=30;
	if ($m2==12) $d2=31;
				
	$data1=$r1.'-'.$m1.'-'.$d1;
	$data2=$r1.'-'.$m1.'-'.$d2;

		echo "<tr class=titlebar_add>";
			echo "<td align=center>&nbsp;<input class=wymagane size=10 maxlength=10 type=text name=okres_od value=$data1 onkeypress='return handleEnter(this, event)'>&nbsp;";			
			echo "<a href=javascript:cal1.popup();><img src=img/cal.gif width=16 height=16 border=0 alt='Kliknij, aby wybra� dat�'></a>";
			echo "</td>";
			echo "<td align=center>&nbsp;<input class=wymagane size=10 maxlength=10 type=text name=okres_do value=$data2 onkeypress='return handleEnter(this, event)'>&nbsp;";
			echo "<a href=javascript:cal11.popup();><img src=img/cal.gif width=16 height=16 border=0 alt='Kliknij, aby wybra� dat�'></a>";
			echo "</td>";
		echo "</tr>";		
		echo "<tr class=titlebar_add>";
		echo "<td align=center>&nbsp;RRRR-MM-DD&nbsp;</td>";
		echo "<td align=center>&nbsp;RRRR-MM-DD&nbsp;</td>";
		echo "</tr>";
		
		echo "<tr class=titlebar_add>";
	
		echo "<td align=center colspan=2>";
		echo "<b><br>dla umowy<br><br></b>";
		echo "</td></tr>";
		echo "<tr class=titlebar_add>";	
		echo "<td align=center colspan=2>";
		
		$sql6="SELECT * FROM serwis_umowy ";
		
		if ($es_m!=1) $sql6 = $sql6. " WHERE belongs_to=$es_filia";
		
		$result6 = mysql_query($sql6, $conn) or die(mysql_error());
		$i = 0;
		
		echo "<select class=wymagane name=tumowa onkeypress='return handleEnter(this, event)'>\n"; 					 				
		echo "<option value='all'>Wszystkie przypisane dla aktualnej filii</option>\n"; 
				
		while ($newArray = mysql_fetch_array($result6)) 
		 {
			$temp_id  				= $newArray['umowa_id'];
			$temp_nr				= $newArray['umowa_nr'];			
			$temp_nazwa				= $newArray['umowa_opis'];
			echo "<option value='$temp_nr'>$temp_nazwa ($temp_nr)</option>\n"; 
		}

	echo "</select>\n"; 		
	echo "</td>";
	echo "</tr>";


	echo "<tr class=titlebar_add>";
	
		echo "<td align=center colspan=2>";
		echo "<b><br>dla filii/oddzia�u<br><br></b>";
		echo "</td></tr>";
		echo "<tr class=titlebar_add>";	
		echo "<td align=center colspan=2>";
		
		$sql6="SELECT * FROM serwis_filie";
		
		if ($es_m!=1) $sql6 = $sql6. " WHERE filia_id=$es_filia";
		
		$result6 = mysql_query($sql6, $conn) or die(mysql_error());
		$i = 0;
		
		echo "<select class=wymagane name=tfilia onkeypress='return handleEnter(this, event)'>\n"; 					 				
		echo "<option value='all'>Wszystkie z listy</option>\n"; 
				
		while ($newArray = mysql_fetch_array($result6)) 
		 {
			$temp_id  				= $newArray['filia_id'];
			$temp_nazwa				= $newArray['filia_nazwa'];			
			echo "<option ";
			if ($temp_id==$es_filia) echo "SELECTED ";
			echo "value=$temp_id>$temp_nazwa</option>\n"; 
		}

	echo "</select>\n"; 		
	echo "</td>";
	echo "</tr>";
	
	
	echo "<tr class=titlebar_add>";
	echo "<td align=right colspan=2>";
    echo "<br><input class=buttons type=submit name=submit value='Generuj raport'>&nbsp;&nbsp;&nbsp;&nbsp;<br>&nbsp;<br></td>";
	echo "</tr>";	
	
	echo "</table>";
	echo "</div>";
	echo "</form>";	
	
?>
<script language="JavaScript">
var cal1 = new calendar1(document.forms['ruch'].elements['okres_od']);
	cal1.year_scroll = true;
	cal1.time_comp = false;
var cal11 = new calendar1(document.forms['ruch'].elements['okres_do']);
	cal11.year_scroll = true;
	cal11.time_comp = false;
</script>

<script language="JavaScript" type="text/javascript">
  var frmvalidator  = new Validator("ruch");
  
  frmvalidator.addValidation("okres_od","req","Nie podano daty poczatkowej");
  frmvalidator.addValidation("okres_do","req","Nie podano daty ko�cowej");
  frmvalidator.addValidation("okres_od","numerichyphen","U�y�e� niedozwolonych znak�w w polu \"od dnia\"");
  frmvalidator.addValidation("okres_do","numerichyphen","U�y�e� niedozwolonych znak�w w polu \"do dnia\"");

  frmvalidator.addValidation("tumowa","dontselect","Nie wybrano umowy");  
</script>

<?php } ?>
</body>
</html>