<?php
ob_start();
?> 



<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title><?php echo "$nazwa_aplikacji"; ?></title>

<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">

<style type="text/css" media="print">
.hideme { display: none; }
</style>

<style type="text/css">
<!--
.style8 {font-family: Arial, Helvetica, sans-serif; font-size: 16px; }
.style11 {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-size: 30px;
}
.style20 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.style21 {font-size: 12px}
.style23 {font-family: Arial, Helvetica, sans-serif; font-size: 16px; font-weight: bold; }
.style24 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }
.style25 {font-family: Arial, Helvetica, sans-serif}

.style30 {
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: solid;
	border-top-color: #FFFFFF;
	border-right-color: #FFFFFF;
	border-bottom-color: #FFFFFF;
	border-left-color: #FFFFFF;
	padding: 0px;
	margin: 0px;
}
.style32 {
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: solid;
	border-top-color: #FFFFFF;
	border-right-color: #FFFFFF;
	border-bottom-color: #FFFFFF;
	border-left-color: #FFFFFF;
	padding: 0px;
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
}
.style32d {
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: solid;
	border-top-color: #FFFFFF;
	border-right-color: #FFFFFF;
	border-bottom-color: #FFFFFF;
	border-left-color: #FFFFFF;
	padding: 0px;
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	background-color: #FFFFFF;
}
.style34 {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	background-color: #FFFFFF;
	border-top-width: 0px;
	border-right-width: 0px;
	border-bottom-width: 0px;
	border-left-width: 0px;
	font-size: 16px;
}

.style32 {
	padding: 0px;
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border: 1px solid #000000;
}

.style42 {
	padding: 0px;
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border: 1px solid #000000;
	padding-top : 2px;
}

.style43 {
	padding: 0px;
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: solid;
	border-right-style: none;
	border-bottom-style: solid;
	border-left-style: none;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top : 2px;
}

.style44 {
	padding: 0px;
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: none;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: solid;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top : 1px;
}

.style46 {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: solid;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: solid;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 2px;
	padding-right: 0px;
	padding-bottom: 2px;
	padding-left: 0px;
}

.style47 {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: none;
	border-left-style: none;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 2px;
	padding-right: 0px;
	padding-bottom: 2px;
	padding-left: 3px;
	font-size: 13px;
}

.style47a {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: none;
	border-right-style: solid;
	border-bottom-style: none;
	border-left-style: none;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 2px;
	padding-right: 0px;
	padding-bottom: 2px;
	padding-left: 0px;
	font-size: 13px;
}

.style47b {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: none;
	border-right-style: solid;
	border-bottom-style: none;
	border-left-style: none;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 2px;
	padding-right: 0px;
	padding-bottom: 2px;
	padding-left: 0px;
	font-size: 13px;
}

.style47null {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 2px;
	padding-right: 0px;
	padding-bottom: 2px;
	padding-left: 0px;
	font-size: 13px;
}

.style45 {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: none;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: none;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 2px;
	padding-right: 0px;
	padding-bottom: 2px;
	padding-left: 4px;
}

.style50 {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: none;
	border-left-style: solid;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 3px;
	padding-right: 3px;
	padding-bottom: 3px;
	padding-left: 3px;
	font-size: 14px;
	font-weight: bold;
}
.style50a {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: solid;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 3px;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 3px;
	font-size: 14px;
	font-weight: bold;
}
.style50b {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: none;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 3px;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 3px;
	font-size: 14px;
	font-weight: normal;
}
.style50c {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: none;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 3px;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 3px;
	font-size: 14px;
	font-weight: bold;
}

.style51 {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: none;
	border-right-style: solid;
	border-bottom-style: none;
	border-left-style: solid;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 0px;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 3px;
	font-size: 14px;
	font-weight: bold;
}

.style32t {
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: solid;
	border-top-color: #FFFFFF;
	border-right-color: #FFFFFF;
	border-bottom-color: #FFFFFF;
	border-left-color: #FFFFFF;
	padding: 0px;
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
}
.style32d {
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: solid;
	border-top-color: #000000;
	border-right-color: #FFFFFF;
	border-bottom-color: #FFFFFF;
	border-left-color: #FFFFFF;
	padding: 0px;
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	background-color: #FFFFFF;
}
.style36 {font-size: 14px}
.style37 {font-size: 14}
.style47c {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: none;
	border-right-style: solid;
	border-bottom-style: none;
	border-left-style: solid;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 2px;
	padding-right: 0px;
	padding-bottom: 2px;
	padding-left: 0px;
	font-size: 13px;
}
.style38 {font-size: 13px}
.style47d {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: none;
	border-right-style: solid;
	border-bottom-style: none;
	border-left-style: none;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 2px;
	padding-right: 0px;
	padding-bottom: 2px;
	padding-left: 0px;
	font-size: 13px;
}
.style46a {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: solid;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 2px;
	padding-right: 0px;
	padding-bottom: 2px;
	padding-left: 0px;
}
.style47lr {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: none;
	border-right-style: solid;
	border-bottom-style: none;
	border-left-style: solid;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 2px;
	padding-right: 0px;
	padding-bottom: 2px;
	padding-left: 0px;
	font-size: 13px;
}

-->
</style>

<title>Untitled Document</title>
<style type="text/css">
.hideme { display: normal; }
</style>
</head>

<body>


<?php	

if ($up=="") { $put_up="-";} else { $put_up=$up; }
if ($nazwa_urzadzenia=="") {$put_nazwa_urzadzenia="-";}  else { $put_nazwa_urzadzenia=$nazwa_urzadzenia; }
if ($sn_urzadzenia==""){ $put_sn_urzadzenia="-";} else { $put_sn_urzadzenia=$sn_urzadzenia; }
if ($ni_urzadzenia=="") {$put_ni_urzadzenia="-";} else { $put_ni_urzadzenia=$ni_urzadzenia; }
if ($opis_uszkodzenia==""){ $put_opis_uszkodzenia="-";} else { $put_opis_uszkodzenia=$opis_uszkodzenia; }
if ($wykonane_czynnosci==""){ $put_wykonane_czynnosci="-";} else { $put_wykonane_czynnosci=$wykonane_czynnosci; }
if ($uwagi=="") {$put_uwagi="-";} else { $put_uwagi=$uwagi; }

?>

<?php

$username = $es_imie.' '.$es_nazwisko;
$wersjap=1;
$submit='ok';

if (($wersjap==1) && ($submit)) {
	
?>

<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%" rowspan="3"><div align="right">
	<img src="https://10.216.39.55/serwis/img/logo2.gif">
	</div></td>
    <td colspan="2" align="right" valign="top"><span class="style8">Data <?php echo "$dzien"; ?> / <?php echo "$miesiac"; ?> / <?php echo "$rok"; ?> 
    </span></td>
  </tr>
  <tr>
    <td width="59%" height="70" align="center" valign="middle"><span class="style11">PROTOKӣ</span></td>
    <td width="22%" rowspan="2" align="center" valign="middle">&nbsp;</td>
  </tr>
  <tr>
    <td align="center" valign="middle">&nbsp;</td>
  </tr>
</table>
<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="5%" align="right" valign="middle"><?php if ($c_1=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td width="1%" align="right" valign="middle">&nbsp;</td>
    <td width="94%"><span class="style8">Pobranie do naprawy uszkodzonego sprz�tu</span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><?php if ($c_2=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Przekazanie sprz�tu serwisowego </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><?php if ($c_3=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Zwrot naprawionego sprz�tu </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><?php if ($c_4=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Pobranie sprz�tu serwisowego </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><?php if ($c_5=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8"> Przekazanie sprz�tu do naprawy - serwisu </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><?php if ($c_6=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Odbi�r sprz�tu z naprawy - serwisu</span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><?php if ($c_7=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Wymiana cz�ci / remont sprz�tu</span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><?php if ($c_8=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Przekazanie zam�wionego sprz�tu </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle">&nbsp;</td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><div align="right" class="style20">* zaznacz w�a�ciwe kwadraty </div></td>
  </tr>
</table>

<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td class="style50" width="4%" align="center" valign="middle"><span class="style23">LP</span></td>
    <td class="style47" colspan="3" align="left"><span class="style23">Dane sprz�tu </span></td>
  </tr>
  <tr>
    <td class="style50" height="95" align="center" valign="top"><span class="style8">1</span></td>
    <td class="style47" width="30%" align="left" valign="top"><span class="style8">Nazwa kom�rki - piecz�tka </span></td>
    <td class="style47" width="33%" align="center">
	  <span class="style8"><?php if ($put_up!='') { echo "<b>$put_up</b>"; } else echo "&nbsp;"; ?></span></td>
    <td class="style47" width="33%">&nbsp;</td>
  </tr>
  <tr>
    <td class="style50" height="25" align="center"><span class="style8">2</span></td>
    <td class="style47" align="left"><span class="style8">Nazwa urz�dzenia </span></td>
    <td class="style47" colspan="2" align="left"><span class="style8"><?php if ($put_nazwa_urzadzenia!='') { echo "<b>$put_nazwa_urzadzenia</b>";} else echo "&nbsp"; ?></span></td>
  </tr>
  <tr>
    <td class="style50" height="25" align="center"><span class="style8">3</span></td>
    <td class="style47" align="left"><span class="style8">Nr. seryjny urz�dzenia </span></td>
    <td class="style47" colspan="2" align="left"><span class="style8"><?php if ($put_sn_urzadzenia!='') { echo "<b>$put_sn_urzadzenia</b>";} else echo "&nbsp;"; ?></span></td>
  </tr>
  <tr>
    <td class="style50" height="25" align="center"><span class="style8">4</span></td>
    <td class="style47" align="left"><span class="style8">Nr. inwentarzowy </span></td>
    <td class="style47" colspan="2" align="left"><span class="style8"><?php if ($put_ni_urzadzenia!='') { echo "<b>$put_ni_urzadzenia</b>"; } else echo "&nbsp;"; ?></span></td>
  </tr>
  <tr>
    <td class="style50" height="110" align="center" valign="top"><span class="style8">5</span></td>
    <td class="style47" align="left" valign="top"><span class="style8">Opis uszkodzenia </span></td>
    <td class="style47" colspan="2" align="left" valign="top"><span class="style8"><?php if ($put_opis_uszkodzenia!='') { echo "<b>".nl2br($put_opis_uszkodzenia)."</b>"; } else echo "&nbsp;"; ?></span></td>
  </tr>
  <tr>
    <td class="style50" height="110" align="center" valign="top"><span class="style8">6</span></td>
    <td class="style47" align="left" valign="top"><span class="style8">Wykonane czynno�ci </span></td>
    <td class="style47" colspan="2" align="left" valign="top"><span class="style8"><?php if ($put_wykonane_czynnosci!='') { echo "<b>".nl2br($put_wykonane_czynnosci)."</b>";} else echo "&nbsp;"; ?></span></td>
  </tr>
  <tr>
    <td class="style50a" height="110" align="center" valign="top"><span class="style8">7</span></td>
    <td class="style50b" align="left" valign="top"><span class="style8">Uwagi</span></td>
    <td class="style50c" colspan="2" align="left" valign="top"><span class="style8"><?php if ($put_uwagi!='') { echo "<b>".nl2br($put_uwagi)."</b>"; } else echo "&nbsp;"; ?></span></td>
  </tr>
</table>
<br>
<br>
<br>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="250" align="center" valign="bottom"><span class="style25"><?php echo "$username"; ?></span></td>
    <td width="100%" colspan="2" align="center">

	<div class="hideme" align="center">
	<a style="vertical-align:bottom; cursor:hand" onClick="javascript:window.print();"><img src="img/drukuj_protokol.jpg" border="0"></a>
<?php
if (($readonly!=1) || ($es_prawa=='9')) {
?>	
	<a style="vertical-align:bottom" href="utworz_protokol.php?pnr=<?php echo "$pnr";?>&dzien=<?php echo "$dzien"; ?>&miesiac=<?php echo "$miesiac"; ?>&rok=<?php echo "$rok"; ?>&c_1=<?php echo "$c_1"; ?>&c_2=<?php echo "$c_2"; ?>&c_3=<?php echo "$c_3"; ?>&c_4=<?php echo "$c_4"; ?>&c_5=<?php echo "$c_5"; ?>&c_6=<?php echo "$c_6"; ?>&c_7=<?php echo "$c_7"; ?>&c_8=<?php echo "$c_8"; ?>&up=<?php echo "$up"; ?>&nazwa_urzadzenia=<?php echo "$nazwa_urzadzenia"; ?>&sn_urzadzenia=<?php echo "$sn_urzadzenia"; ?>&ni_urzadzenia=<?php echo "$ni_urzadzenia"; ?>&opis_uszkodzenia=<?php echo urlencode($opis_uszkodzenia); ?>&wykonane_czynnosci=<?php echo urlencode($wykonane_czynnosci); ?>&uwagi=<?php echo urlencode($uwagi); ?>&imieinazwisko=<?php echo "$imieinazwisko"; ?>&wersjap=<?php echo "$wersjap";?>"><img src="img/popraw.jpg" border="0"></a>
<?php 
}	
?>

</div></td>
    <td width="250">&nbsp;</td>
  </tr>
  <tr>
    <td width="250"><div align="left"><strong>............................................................</strong></div></td>
    <td width="100%" colspan="2" align="center">&nbsp;</td>
    <td width="250"><div align="right"><strong>............................................................</strong></div></td>
  </tr>
  <tr>
    <td width="250" align="center"><div align="center" class="style24">strona przekazuj�ca </div></td>
    <td width="100%" colspan="2"><div class="hideme" align="center"><a style="vertical-align:bottom; cursor:hand" onClick="window.close()"><img src="img/anuluj_protokol.jpg" border="0"></a></div></td>
    <td width="250" align="center"><div align="center" class="style24">strona odbieraj�ca </div></td>
  </tr>
</table>

<?php 
} 
// koniec protoko�u w wersji 1 (generuj protok�)
?>

<?php

if (($wersjap==2) && ($submit)) {

	if ($clear==1) {

		$dzien 		= '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
		$miesiac 	= '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
		$rok		= '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
		$c_1		= '';
		$c_2		= '';
		$c_3		= '';
		$c_4		= '';
		$c_5		= '';
		$c_6		= '';
		$c_7		= '';
		$c_8		= '';
		$put_up		= '';
		$put_nazwa_urzadzenia = '';
		$put_sn_urzadzenia = '';
		$put_ni_urzadzenia = '';
		$put_opis_uszkodzenia = '';
		$put_wykonane_czynnosci = '';
		$put_uwagi = '';
		$username = '';
	}

?>

  <table height="100%" width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="25" align="left" bordercolor="#FFFFFF" bgcolor="#FFFFFF"><span class="style34">&nbsp;PROTOKӣ NR :
        <?php echo "$pnr"; ?>
      </span></td>
      <td height="25" align="left" bordercolor="#FFFFFF" bgcolor="#FFFFFF">&nbsp;</td>
      <td height="25" align="left" bordercolor="#FFFFFF" bgcolor="#FFFFFF">&nbsp;</td>
      <td height="25" colspan="2" align="right" valign="top" bordercolor="#ffffff" bgcolor="#ffffff"><span class="style8">Data&nbsp;&nbsp;<?php echo "$dzien"; ?>/<?php echo "$miesiac"; ?>/<?php echo "$rok"; ?>&nbsp;
      </span> </td>
    </tr>
	<tr>
	<td colspan="5">
	&nbsp;
	</td>
	</tr>
    <tr>
      <td colspan="4" align="left" valign="middle" nowrap bordercolor="#FFFFFF"><?php if ($c_1=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?>
        <span class="style8">Pobranie do naprawy uszkodzonego sprz�tu</span></td>
      <td align="right" colspan="1" rowspan="9" valign="top" bordercolor="#FFFFFF"><div align="right"><img src="img/logo2.gif"></div></td>
    </tr>
    <tr>
      <td colspan="4" align="left" valign="middle" nowrap bordercolor="#FFFFFF"><?php if ($c_2=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?>
          <span class="style8">Przekazanie sprz�tu serwisowego</span></td>
    </tr>
    <tr>
      <td colspan="4" align="left" valign="middle" nowrap bordercolor="#FFFFFF"><?php if ($c_3=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?>
          <span class="style8">Zwrot naprawionego sprz�tu </span></td>
    </tr>
    <tr>
      <td colspan="4" align="left" bordercolor="#FFFFFF"><?php if ($c_4=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?>
          <span class="style8">Pobranie sprz�tu serwisowego </span></td>
    </tr>
    <tr>
      <td colspan="4" align="left" bordercolor="#FFFFFF"><?php if ($c_5=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?>
          <span class="style8"> Przekazanie sprz�tu do naprawy - serwisu </span></td>
    </tr>
    <tr>
      <td colspan="4" align="left" valign="middle" bordercolor="#FFFFFF"><?php if ($c_6=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?>
          <span class="style8">Odbi�r sprz�tu z naprawy - serwisu</span></td>
    </tr>
    <tr>
      <td colspan="4" align="left" valign="middle" bordercolor="#FFFFFF"><?php if ($c_7=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?>
          <span class="style8">Wymiana cz�ci / remont sprz�tu</span></td>
    </tr>
    <tr>
      <td colspan="4" align="left" valign="middle" bordercolor="#FFFFFF"><?php if ($c_8=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?>
          <span class="style8">Przekazanie zam�wionego sprz�tu </span></td>
    </tr>
    <tr>
      <td colspan="5">&nbsp;</td>
    </tr>
  </table>	
  <table height="100%" width="100%" border="0" cellspacing="0" cellpadding="0">	
    <tr>
      <td height="25" colspan="5" align="left" bgcolor="#ffffff" class="style50"><span class="style30 style36 style37">SZCZEGӣOWY OPIS WYKONANYCH CZYNNO�CI</span></td>
    </tr>
    <tr>
      <td width="30%" height="100" align="left" valign="top" nowrap="nowrap" class="style42"><span class="style8">&nbsp;Nazwa kom�rki-piecz�tka</span></td>
      <td colspan="3" align="center" valign="top" bordercolor="#FFFFFF" class="style43"><div align="left" class="style28 style26 style25"><em>&nbsp;Nazwa kom�rki</em></div>
          <br><span class="style34">
          <?php echo "<b>$put_up</b>"; ?>
	  </span></td>
      <td width="33%" align="left" valign="top" bordercolor="#FFFFFF" class="style42"><div align="left" class="style28 style26 style25"><em>&nbsp;Piecz�tka</em></div>
      <br></td>
    </tr>
    <tr>
      <td height="25" align="left" class="style44"><span class="style8">&nbsp;Nazwa urz�dzenia </span></td>
      <td colspan="4" align="left" class="style45"><span class="style34"><?php echo "<b>$put_nazwa_urzadzenia</b>"; ?></span></td>
    </tr>
    <tr>
      <td height="25" align="left" class="style44"><span class="style8">&nbsp;Nr. seryjny urz�dzenia </span></td>
      <td colspan="4" align="left" class="style45"><span class="style34"><?php echo "<b>$put_sn_urzadzenia</b>"; ?></span></td>
    </tr>
    <tr>
      <td height="25" align="left" class="style44"><span class="style8">&nbsp;Nr. inwentarzowy </span></td>
      <td colspan="4" align="left" class="style45"><span class="style34"><?php echo "<b>$put_ni_urzadzenia</b>"; ?></span></td>
    </tr>
    <tr>
      <td height="90" align="left" valign="top" class="style44"><span class="style8">&nbsp;Opis uszkodzenia </span></td>
 
      <td colspan="4" align="left" valign="top" class="style45"><span class="style34"><?php echo "<b>".nl2br($put_opis_uszkodzenia)."</b>"; ?></span></td>
    </tr>
    <tr>
      <td height="100" align="left" valign="top" class="style44"><span class="style8">&nbsp;Wykonane czynno�ci </span></td>
      <td colspan="4" align="left" valign="top" class="style45"><span class="style34"><?php echo "<b>".nl2br($put_wykonane_czynnosci)."</b>"; ?></span></td>
    </tr>
    <tr>
      <td height="90" align="left" valign="top" class="style44"><span class="style8">&nbsp;Uwagi</span></td>
      <td colspan="4" align="left" valign="top" class="style45"><span class="style34"><?php echo "<b>".nl2br($put_uwagi)."</b>"; ?></span></td>
    </tr>
  </table>
  
  <table height="100%" width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="26" colspan="4" bgcolor="#ffffff" class="style51">&nbsp;<span class="style25"><strong>POTWIERDZENIE WYKONANIA </strong></span></td>
    </tr>
    <tr class="style32">
      <td rowspan="4" valign="top" class="style46"><div align="right" class="style36 style25"><strong><span class="style36">POCZTA :</span>&nbsp;<br>
                <br>
      UWAGI :&nbsp;</strong></div></td>
      <td colspan="4" valign="top" class="style47"> Poni�szym podpisem potwierdzam odbi�r us�ugi/dostawy </td>
    </tr>
    <tr>
      <td colspan="4" align="left" valign="bottom" class="style47a"><br>
        ..............................................................................................................................................<br>
        <br>
        <br><br>
	  <br></td>
    </tr>
    <tr>
      <td class="style47null"><div align="center" class="style47null">.................................................................. </div></td>
      <td class="style47b"><div align="center" class="style36">.................................................................. </div></td>
    </tr>
    <tr>
      <td class="style47null"><div align="center" class="style36">Piecz�� jednostki </div></td>
      <td class="style47b"><div align="center" class="style36">Podpis osoby odbieraj�cej prace </div></td>
    </tr>
	<tr>
	<td colspan="4" class="style44">&nbsp;</td>
	</tr>
    <tr>
      <td class="style46a"><div align="right" class="style36"><strong>&nbsp;POSTDATA :&nbsp;</strong></div> </td>
      <td colspan="2" class="style47d">Poni�szym podpisem potwierdzam wykonanie Us�ugi/dostawy</td>
    </tr>
	<tr>
	<td colspan="4" class="style47lr">&nbsp;</td>
	</tr>
	<tr>
	<td colspan="4" class="style47lr" align="right"><?php echo "$username"; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
	</tr>	
    <tr>
      <td rowspan="3" class="style46a">&nbsp;
      </td>
    </tr>
    <tr>
      <td class="style47null">&nbsp;</td>
      <td class="style47b"><div align="center">..................................................................</div></td>
    </tr>
    <tr>
      <td class="style47null">&nbsp;</td>
      <td class="style47b"><div align="center"><span class="style36">Podpis osoby wykonuj�cej prace</span></div></td>
    </tr>
    <tr>
      <td colspan="4" class="style44"><br>
      </td>
    </tr>
</table>

<div class="hideme" align="center">
<br>
<a style="vertical-align:bottom; cursor:hand" onClick="javascript:window.print();"><img src="img/drukuj_protokol.jpg" border="0"></a>
<?php
if (($readonly!=1) || ($es_prawa=='9')) {
?>	

<a style="vertical-align:bottom" href="utworz_protokol.php?pnr=<?php echo "$pnr";?>&dzien=<?php echo "$dzien"; ?>&miesiac=<?php echo "$miesiac"; ?>&rok=<?php echo "$rok"; ?>&c_1=<?php echo "$c_1"; ?>&c_2=<?php echo "$c_2"; ?>&c_3=<?php echo "$c_3"; ?>&c_4=<?php echo "$c_4"; ?>&c_5=<?php echo "$c_5"; ?>&c_6=<?php echo "$c_6"; ?>&c_7=<?php echo "$c_7"; ?>&c_8=<?php echo "$c_8"; ?>&up=<?php echo "$up"; ?>&nazwa_urzadzenia=<?php echo "$nazwa_urzadzenia"; ?>&sn_urzadzenia=<?php echo "$sn_urzadzenia"; ?>&ni_urzadzenia=<?php echo "$ni_urzadzenia"; ?>&opis_uszkodzenia=<?php echo urlencode($opis_uszkodzenia); ?>&wykonane_czynnosci=<?php echo urlencode($wykonane_czynnosci); ?>&uwagi=<?php echo urlencode($uwagi); ?>&imieinazwisko=<?php echo "$imieinazwisko"; ?>&wersjap=<?php echo "$wersjap";?>"><img src="img/popraw.jpg" border="0"></a>

<?php 
}	
?>
<a style="vertical-align:bottom; cursor:hand" onClick="window.close()"><img src="img/anuluj_protokol.jpg" border="0"></a>
</div>
</div>






<?php 

}
// koniec protoko�u w wersji 2(generuj protok�)
?>

<?php

/*
if ($pdf) 
{  
require_once("fpdf/html2fpdf.php"); 

//include_once($PHP_SELF);
$htmlbuffer = ob_get_contents();
  
$pdf->AddPage(); 
$pdf->UseCSS(true);  
//$htmlbuffer = iconv("UTF-8", "ISO8859-2", $htmlbuffer); 
$pdf->WriteHTML($htmlbuffer); 
$pdf->Output("file.pdf", "D"); 

}
?>
*/


//ob_end_clean();
?>

<?php

$data = ob_get_contents();
ob_end_clean();

echo $data;

/*
define('FPDF_FONTPATH','fpdf/font/');
require('fpdf/html_table.php');

$data = '<TABLE width="100%">
<TR>
<TD>S. No.</TD>
<TD>Name</TD>
<TD>Age</TD>
<TD>Sex</TD>
<TD>Location</TD>
</TR>

<TR>
<TD>1</TD>
<TD>Azeem</TD>
<TD>24</TD>
<TD>Male</TD>
<TD>Pakistan</TD>
</TR>

<TR>
<TD>2</TD>
<TD>Atiq</TD>
<TD>24</TD>
<TD>Male</TD>
<TD>Pakistan</TD>
</TR>

<TR>
<TD>3</TD>
<TD>Shahid</TD>
<TD>24</TD>
<TD>Male</TD>
<TD>Pakistan</TD>
</TR>

<TR>
<TD>4</TD>
<TD>Roy Montgome</TD>
<TD>36</TD>
<TD>Male</TD>
<TD>USA</TD>
</TR>

<TR>
<TD>5</TD>
<TD>M.Bony</TD>
<TD>18</TD>
<TD>Female</TD>
<TD>&nbsp;</TD>
</TR>
</TABLE>';

$pdf=new PDF_HTML_Table();
$pdf->AddPage();
$pdf->SetFont('Arial','',10);
$pdf->WriteHTML($data);
$pdf->Output();

*/
/*
require_once("dompdf/dompdf_config.inc.php"); 
if ( get_magic_quotes_gpc() ) $data = stripslashes($data);

$old_limit = ini_set("memory_limit", "16M");
  
$dompdf = new DOMPDF();
$dompdf->load_html($data);
$dompdf->set_paper("letter", "portrait");
$dompdf->render();

$dompdf->stream("dompdf_out.pdf"); 
  
?>
*/
?>

</body>
</html>
