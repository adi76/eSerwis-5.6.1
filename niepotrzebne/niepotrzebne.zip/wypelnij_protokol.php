<?php include_once('header_simple.php'); ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title><?php echo "$nazwa_aplikacji"; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<script type="text/javascript" src="js/saveRestoreForm.js"></script>
<title>Untitled Document</title>
<style type="text/css">
<!--
.style8 {font-family: Arial, Helvetica, sans-serif; font-size: 13px; }
.style20 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.style25 {font-family: Arial, Helvetica, sans-serif}
.style28 {font-size: 9px}
.style30 {
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: solid;
	border-top-color: #FFFFFF;
	border-right-color: #FFFFFF;
	border-bottom-color: #FFFFFF;
	border-left-color: #FFFFFF;
	padding: 0px;
	margin: 0px;
}
.style32 {
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: solid;
	border-top-color: #FFFFFF;
	border-right-color: #FFFFFF;
	border-bottom-color: #FFFFFF;
	border-left-color: #FFFFFF;
	padding: 0px;
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
}
.style32d {
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: solid;
	border-top-color: #FFFFFF;
	border-right-color: #FFFFFF;
	border-bottom-color: #FFFFFF;
	border-left-color: #FFFFFF;
	padding: 0px;
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	background-color: #FFFFFF;
}
.style34 {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
	background-color: #FFFFFF;
	font-size: 14px;
	border: 0px none #FFFFFF;
}

.style32 {
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: solid;
	border-top-color: #FFFFFF;
	border-right-color: #FFFFFF;
	border-bottom-color: #FFFFFF;
	border-left-color: #FFFFFF;
	padding: 0px;
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
}
.style32t {
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: solid;
	border-top-color: #FFFFFF;
	border-right-color: #FFFFFF;
	border-bottom-color: #FFFFFF;
	border-left-color: #FFFFFF;
	padding: 0px;
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
}
.style32d {
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: solid;
	border-top-color: #000000;
	border-right-color: #FFFFFF;
	border-bottom-color: #FFFFFF;
	border-left-color: #FFFFFF;
	padding: 0px;
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	background-color: #FFFFFF;
}

.style35 {
	border-right-color: #FFFFFF;
	border-bottom-color: #FFFFFF;
	border-left-color: #FFFFFF;
}
.style37 {font-size: 16px}
.style34a {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
	background-color: #FFFFFF;
	font-size: 16px;
	border: 0px none #FFFFFF;
	padding-top: 2px;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 0px;
}
-->

.style42 {
	padding: 0px;
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border: 1px solid #000000;
}

.style43 {
	padding: 0px;
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: solid;
	border-right-style: none;
	border-bottom-style: solid;
	border-left-style: none;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
}

.style44 {
	padding: 0px;
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: none;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: solid;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
}

.style46 {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: solid;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: solid;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 2px;
	padding-right: 0px;
	padding-bottom: 2px;
	padding-left: 0px;
}

.style47 {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: none;
	border-left-style: none;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 2px;
	padding-right: 0px;
	padding-bottom: 2px;
	padding-left: 0px;
	font-size: 13px;
}

.style47a {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: none;
	border-right-style: solid;
	border-bottom-style: none;
	border-left-style: none;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 2px;
	padding-right: 0px;
	padding-bottom: 2px;
	padding-left: 0px;
	font-size: 13px;
}

.style47b {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: none;
	border-right-style: solid;
	border-bottom-style: none;
	border-left-style: none;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 2px;
	padding-right: 0px;
	padding-bottom: 2px;
	padding-left: 0px;
	font-size: 13px;
}

.style47null {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 2px;
	padding-right: 0px;
	padding-bottom: 2px;
	padding-left: 0px;
	font-size: 13px;
}

.style45 {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: none;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: none;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 0px;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 5px;
}

.style50 {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: none;
	border-left-style: solid;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 0px;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 3px;
	font-size: 14px;
	font-weight: bold;
}
.style51 {
	margin: 0px;
	background-position: center;
	font-family: Arial, Helvetica, sans-serif;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: none;
	border-right-style: solid;
	border-bottom-style: none;
	border-left-style: solid;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
	padding-top: 0px;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 3px;
	font-size: 14px;
	font-weight: bold;
}

</style>

<style type="text/css" media="print">
.hideme { display: none; }

</style>

</head>

<body OnLoad="document.protokol.nr.focus();">
<form name="protokol" action="wypelnij_protokol_do.php" method="GET">
  <table height="100%" width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="25" colspan="2" align="left" bordercolor="#FFFFFF" bgcolor="#FFFFFF"><span class="style34a style37 style37">&nbsp;PROTOKӣ NR
        <input class="style34a" name="nr" type=text size="18" maxlength="18" value="<?php echo "$nr"; ?>">
      </span></td>
      <td height="25" align="left" bordercolor="#FFFFFF" bgcolor="#FFFFFF">&nbsp;</td>
      <td height="25" colspan="2" align="right" valign="top" bordercolor="#ffffff" bgcolor="#ffffff"><span class="style8">Data&nbsp;&nbsp;
            <input class="style32" name="dzien" type=text size="2" maxlength="2" value="<?php echo "$dzien"; ?>">
        /
        <input class="style32" name="miesiac" type=text size="2" maxlength="2" value="<?php echo "$miesiac"; ?>">
        /
        <input class="style32" name="rok" type=text size="2" maxlength="4" value="<?php echo "$rok"; ?>">
      </span> </td>
    </tr>
	<tr>
	<td>
	&nbsp;
	</td>
	</tr>
    <tr>
      <td colspan="2" align="left" valign="middle" nowrap bordercolor="#FFFFFF"><input type="checkbox" name="c_1" <?php if ($_GET[c_1]=='on') { echo "checked=checked"; } ?>>
        &nbsp;<span class="style8">Pobranie do naprawy uszkodzonego sprz�tu</span></td>
      <td align="left" valign="middle" nowrap bordercolor="#FFFFFF">&nbsp;</td>
      <td align="left" valign="middle" nowrap bordercolor="#FFFFFF">&nbsp;</td>
      <td align="right" colspan="1" rowspan="9" valign="top" bordercolor="#FFFFFF"><div align="right"><img src="img/logo2.gif"></div></td>
    </tr>
    <tr>
      <td colspan="2" align="left" valign="middle" nowrap bordercolor="#FFFFFF"><input type="checkbox" name="c_2" <?php if ($_GET[c_2]=='on') { echo "checked=checked"; } ?>>
          <span class="style8">Przekazanie sprz�tu serwisowego</span></td>
      <td align="left" valign="middle" nowrap bordercolor="#FFFFFF">&nbsp;</td>
      <td align="left" valign="middle" nowrap bordercolor="#FFFFFF">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2" align="left" valign="middle" nowrap bordercolor="#FFFFFF"><input type="checkbox" name="c_3" <?php if ($_GET[c_3]=='on') { echo "checked=checked"; } ?>>
          <span class="style8">Zwrot naprawionego sprz�tu </span></td>
      <td align="left" valign="middle" nowrap bordercolor="#FFFFFF">&nbsp;</td>
      <td align="left" valign="middle" nowrap bordercolor="#FFFFFF">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2" align="left" bordercolor="#FFFFFF"><input type="checkbox" name="c_4" <?php if ($_GET[c_4]=='on') { echo "checked=checked"; } ?>>
          <span class="style8">Pobranie sprz�tu serwisowego </span></td>
      <td align="left" bordercolor="#FFFFFF">&nbsp;</td>
      <td align="left" bordercolor="#FFFFFF">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2" align="left" bordercolor="#FFFFFF"><input type="checkbox" name="c_5" <?php if ($_GET[c_5]=='on') { echo "checked=checked"; } ?>>
          <span class="style8"> Przekazanie sprz�tu do naprawy - serwisu </span></td>
      <td align="left" bordercolor="#FFFFFF">&nbsp;</td>
      <td align="left" bordercolor="#FFFFFF">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2" align="left" valign="middle" bordercolor="#FFFFFF"><input type="checkbox" name="c_6" <?php if ($_GET[c_6]=='on') { echo "checked=checked"; } ?>>
          <span class="style8">Odbi�r sprz�tu z naprawy - serwisu</span></td>
      <td align="left" valign="middle" bordercolor="#FFFFFF">&nbsp;</td>
      <td align="left" valign="middle" bordercolor="#FFFFFF">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="3" align="left" valign="middle" bordercolor="#FFFFFF"><input type="checkbox" name="c_7" <?php if ($_GET[c_7]=='on') { echo "checked=checked"; } ?>>
          <span class="style8">Wymiana cz�ci / remont sprz�tu (niepotrzebne skre�li�)</span></td>
      <td align="left" valign="middle" bordercolor="#FFFFFF">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2" align="left" valign="middle" bordercolor="#FFFFFF"><input type="checkbox" name="c_8" <?php if ($_GET[c_8]=='on') { echo "checked=checked"; } ?>>
          <span class="style8">Przekazanie zam�wionego sprz�tu </span></td>
      <td align="left" valign="middle" bordercolor="#FFFFFF">&nbsp;</td>
      <td align="left" valign="middle" bordercolor="#FFFFFF">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="4" bordercolor="#FFFFFF"><div align="left" class="style20">
          <div align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;* zaznacz w�a�ciwe kwadraty</div>
      </div></td>
    </tr>
    <tr>
      <td class="style32" colspan="5">&nbsp;</td>
    </tr>
    <tr>
      <td height="25" colspan="5" align="left" bgcolor="#ffffff" class="style50"><span class="style34">&nbsp;SZCZEGӣOWY OPIS WYKONANYCH CZYNNO�CI</span></td>
    </tr>
    <tr>
      <td height="100" width="33%" align="left" valign="top" class="style42"><span class="style8">&nbsp;Nazwa kom�rki-piecz�tka </span></td>
      <td width="33%" colspan="3" align="center" valign="top" class="style43"><div align="left" class="style28 style26 style25"><em>&nbsp;Nazwa kom�rki</em></div>
          <br>
          <?php 
		  
		$sql44="SELECT * FROM serwis_komorki WHERE belongs_to='$es_filia' ORDER BY up_nazwa";
		$result44 = mysql_query($sql44, $conn) or die(mysql_error());
		$count_rows = mysql_num_rows($result44);
			
		echo "<select class=style32 name=up>\n"; 					 				
		echo "<option value=''>Wybierz z listy...";
				
		while ($newArray44 = mysql_fetch_array($result44)) 
		 {
			$temp_id  				= $newArray44['up_id'];
			$temp_nazwa				= $newArray44['up_nazwa'];
			
			echo "<option";
			if ($temp_nazwa==$up) { echo " SELECTED"; }
			echo " value='$temp_nazwa'>$temp_nazwa</option>\n"; 
		
		}
		
		echo "</select>\n";
	?>
        <br><br>
        <br></td>
      <td align="left" valign="top" class="style42"><div align="left" class="style28 style26 style25"><em>&nbsp;Piecz�tka</em></div>
          <br></td>
    </tr>
    <tr>
      <td height="25" align="left" class="style44"><span class="style8">&nbsp;Nazwa urz�dzenia </span></td>
      <td colspan="4" align="left" class="style45"><input class="style30" name="nazwa_urzadzenia" type=text size="60" value="<?php echo "$nazwa_urzadzenia"; ?>"></td>
    </tr>
    <tr>
      <td height="25" align="left" class="style44"><span class="style8">&nbsp;Nr. seryjny urz�dzenia </span></td>
      <td colspan="4" align="left" class="style45"><input class="style30" name="sn_urzadzenia" type=text size="40" value="<?php echo "$sn_urzadzenia"; ?>"></td>
    </tr>
    <tr>
      <td height="25" align="left" class="style44"><span class="style8">&nbsp;Nr. inwentarzowy </span></td>
      <td colspan="4" align="left" class="style45"><input class="style30" name="ni_urzadzenia" type=text size="40" value="<?php echo "$ni_urzadzenia"; ?>"></td>
    </tr>
    <tr>
      <td height="90" align="left" valign="top" class="style44"><span class="style8">&nbsp;Opis uszkodzenia </span></td>
 
      <td colspan="4" align="left" valign="top" class="style45"><textarea class="style32" name="opis_urzadzenia" cols=70 rows=4><?php echo "$opis_urzadzenia"; ?></textarea></td>
    </tr>
    <tr>
      <td height="100" align="left" valign="top" class="style44"><span class="style8">&nbsp;Wykonane czynno�ci </span></td>
      <td colspan="4" align="left" valign="top" class="style45"><textarea class="style32" name="wykonane_czynnosci" cols=70 rows=5><?php echo "$wykonane_czynnosci"; ?></textarea></td>
    </tr>
    <tr>
      <td height="90" align="left" valign="top" class="style44"><span class="style8">&nbsp;Uwagi</span></td>
      <td colspan="4" align="left" valign="top" class="style45"><textarea class="style32" name="uwagi" cols=70 rows=4><?php echo "$uwagi"; ?></textarea></td>
    </tr>
  </table>
  <br>
  <div align="center">
  <input type="hidden" name="imieinazwisko" value="<?php echo "$es_imie $es_nazwisko"; ?>">
  <input type="hidden" name="readonly" value="0">
  <input class="buttons" type="submit" name="submit" value="Generuj protok�">
  <input class="buttons" type="reset" name="reset" value="Wyczy�� protok�">
  <input name="button" type="button" class="buttons" onClick="window.close()" value="&nbsp;&nbsp;Anuluj przygotowywanie protoko�u&nbsp;">
  </div>

</form>
</body>
</html>
