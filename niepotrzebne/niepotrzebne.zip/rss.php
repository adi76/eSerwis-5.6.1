<?php include_once('header.php'); ?>

<?php
include ("rss/feedcreator.class.php");

//define channel
$rss = new UniversalFeedCreator();
$rss->useCached();
$rss->title="Raport z bazy eSerwis";
$rss->description="Baza serwisowa Postdata S.A.";
$rss->link="http://127.0.0.1/serwis";
$rss->syndicationURL="http://127.0.0.1/serwis/$PHP_SELF";

$sql = "SELECT * FROM serwis_naprawa WHERE naprawa_status='-1' and belongs_to='$es_filia'";
$result = mysql_query($sql, $conn) or die(mysql_error());
$naprawy_ilosc_pobrana = mysql_num_rows($result);

$item = new FeedItem();

$szcz='<table cellspacing=1 border=1 align=left><tr class=titlebar_add_n><th>LP</th><th nowrap  align=left>&nbsp;Nazwa urz�dzenia<br>&nbsp;Lokalizacja sprz�tu</th><th nowrap align=left>&nbsp;Numer seryjny<br>&nbsp;Numer inwentarzowy</th><th nowrap align=left>&nbsp;Pobrane przez<br>&nbsp;Data pobrania</th><th align=left>Uwagi</th></tr>';

$info='Sprz�t pobrany do naprawy';

$i = 1;
while ($data = mysql_fetch_array($result)) {

	$nazwa 	= $data['naprawa_nazwa'];
	$model 	= $data['naprawa_model'];
	$sn 	= $data['naprawa_sn'];
	$ni	 	= $data['naprawa_ni'];
	$uwagi	= $data['naprawa_uwagi'];
	$lokalizacja = $data['naprawa_pobrano_z'];
	$kto	= $data['naprawa_osoba_pobierajaca'];
	$datapobrania = $data['naprawa_data_pobrania'];

	if ($uwagi=='') $uwagi='&nbsp;';
	
	$szcz = $szcz.'<tr><td><center>'.$i.'</center></td><td nowrap>&nbsp;'.$nazwa.' '.$model.'&nbsp;<br>&nbsp;'.$lokalizacja.'&nbsp;</td><td nowrap>&nbsp;'.$sn.'&nbsp;<br>&nbsp;'.$ni.'&nbsp;</td><td nowrap>&nbsp;'.$kto.'&nbsp;<br>&nbsp;'.$datapobrania.'&nbsp;</td><td>'.$uwagi.'</tr>';
    
	$i++;
}

$szcz = $szcz.'</table>';

$item->title = $info;
$item->description = $szcz;
$item->date = $datapobrania;
$item->source = "http://127.0.0.1/serwis";
$item->author = "eSerwis";
$rss->addItem($item);

// ================

$sql = "SELECT naprawa_id FROM serwis_naprawa WHERE (naprawa_status='1') and belongs_to='$es_filia'";
$result = mysql_query($sql, $conn) or die(mysql_error());
$naprawy_ilosc_serwis_zewn = mysql_num_rows($result);

if ($naprawy_ilosc_serwis_zewn>0) 
{
	$item = new FeedItem();
	$szcz2='<table cellspacing=1 border=1 align=left><tr class=titlebar_add_n><th>LP</th><th nowrap  align=left>&nbsp;Nazwa urz�dzenia<br>&nbsp;Lokalizacja sprz�tu</th><th nowrap align=left>&nbsp;Numer seryjny<br>&nbsp;Numer inwentarzowy</th><th nowrap align=left>&nbsp;Osoba wysy�aj�ca sprz�t<br>&nbsp;Data wysy�ki</th><th>Termin naprawy</th><th align=left>Uwagi</th></tr>';

	$info='Sprz�t w naprawie w serwisach zewn�trznych';
	$i = 1;
	while ($data1 = mysql_fetch_array($result)) {

		$nazwa 	= $data1['naprawa_nazwa'];
		$model 	= $data1['naprawa_model'];
		$sn 	= $data1['naprawa_sn'];
		$ni	 	= $data1['naprawa_ni'];
		$uwagi	= $data1['naprawa_uwagi'];
		$lokalizacja = $data1['naprawa_pobrano_z'];
		$kto	= $data1['naprawa_osoba_wysylajaca'];
		$datawysylki = $data1['naprawa_data_wysylki'];
		$terminnaprawy = $data1['naprawa_przewidywany_termin_naprawy'];

		if ($uwagi=='') $uwagi='&nbsp;';
		
		$szcz2 = $szcz2.'<tr><td><center>'.$i.'</center></td><td nowrap>&nbsp;'.$nazwa.' '.$model.'&nbsp;<br>&nbsp;'.$lokalizacja.'&nbsp;</td><td nowrap>&nbsp;'.$sn.'&nbsp;<br>&nbsp;'.$ni.'&nbsp;</td><td nowrap>&nbsp;'.$kto.'&nbsp;<br>&nbsp;'.$datawysylki.'&nbsp;</td><td>&nbsp'.$terminnaprawy.'&nbsp;</td><td>'.$uwagi.'</tr>';
	    
		$i++;
	}
	$szcz2 = $szcz2.'</table>';

	$item->title = $info;
	$item->description = $szcz2;
	$item->date = $datapobrania;
	$item->source = "http://127.0.0.1/serwis";
	$item->author = "eSerwis";
	$rss->addItem($item);
} 

// ================

$sql = "SELECT awaria_id FROM serwis_awarie WHERE ((awaria_status='0') and (belongs_to='$es_filia'))";
$result = mysql_query($sql, $conn) or die(mysql_error());
$awarie_otwarte_ilosc = mysql_num_rows($result);

if ($awarie_otwarte_ilosc>0) 
{
	$item = new FeedItem();
	$szcz3='<table cellspacing=1 border=1 align=left><tr class=titlebar_add_n><th>LP</th><th nowrap  align=left>&nbsp;Miejsce awarii</th><th nowrap align=left>&nbsp;Numer zg�oszenia</th><th nowrap align=left>&nbsp;Data zg�oszenia</th></tr>';

	$info='Otwarte awarie ��czy WAN';
	$i = 1;
	while ($data2 = mysql_fetch_array($result)) {

		$miejsce= $data2['awaria_gdzie'];
		$nr 	= $data2['awaria_nrzgloszenia'];
		$data	= $data2['awaria_datazgloszenia'];
		
		$szcz3 = $szcz3.'<tr><td><center>'.$i.'</center></td><td nowrap>&nbsp;'.$miejsce.'&nbsp;</td><td nowrap>&nbsp;'.$nr.'&nbsp;</td><td nowrap>&nbsp;'.$data.'&nbsp;</td></tr>';
	    
		$i++;
	}
	$szcz3 = $szcz3.'</table>';

	$item->title = $info;
	$item->description = $szcz3;
	$item->date = $datapobrania;
	$item->source = "http://127.0.0.1/serwis";
	$item->author = "eSerwis";
	$rss->addItem($item);
}

//$rss->outputFeed("RSS2.0"); 
$rss->saveFeed("RSS2.0", "rss/feed.xml"); 

?>