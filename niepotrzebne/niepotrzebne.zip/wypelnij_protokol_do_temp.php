<?php include_once('header_simple.php'); ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title><?php echo "$nazwa_aplikacji"; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">

<style type="text/css" media="print">
.hideme { display: none; }
</style>

<title>Untitled Document</title>
<style type="text/css">
<!--

.style8 {font-family: Arial, Helvetica, sans-serif; font-size: 13px; }
.style11 {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-size: 24px;
	font-style: italic;
}
.style20 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 13px;
}
.style21 {font-size: 13px}
.style23 {font-family: Arial, Helvetica, sans-serif; font-size: 13px; font-weight: bold; }
.style24 {font-family: Arial, Helvetica, sans-serif; font-size: 13px; }
.style25 {font-family: Arial, Helvetica, sans-serif}
.style26 {
	font-size: 10px;
	font-style: italic;
}
.style27 {font-size: 10px; font-style: italic; font-family: Arial, Helvetica, sans-serif; }
-->
</style>
</head>

<body OnLoad="document.protokol.dzien.focus();">

<?php

if ($up=="") { $put_up="&nbsp;";} else { $put_up=$up; }
if ($nazwa_urzadzenia=="") {$put_nazwa_urzadzenia="&nbsp;";}  else { $put_nazwa_urzadzenia=$nazwa_urzadzenia; }
if ($sn_urzadzenia==""){ $put_sn_urzadzenia="&nbsp;";} else { $put_sn_urzadzenia=$sn_urzadzenia; }
if ($ni_urzadzenia=="") {$put_ni_urzadzenia="&nbsp;";} else { $put_ni_urzadzenia=$ni_urzadzenia; }
if ($opis_urzadzenia==""){ $put_opis_urzadzenia="&nbsp;";} else { $put_opis_urzadzenia=$opis_urzadzenia; }
if ($wykonane_czynnosci==""){ $put_wykonane_czynnosci="&nbsp;";} else { $put_wykonane_czynnosci=$wykonane_czynnosci; }
if ($uwagi=="") {$put_uwagi="&nbsp;";} else { $put_uwagi=$uwagi; }

?>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%" rowspan="3"><div align="right"><img src="img/logo2.gif"></div></td>
    <td colspan="2" align="right" valign="top"><span class="style8">Data&nbsp;&nbsp;<?php echo "$dzien"; ?> / <?php echo "$miesiac"; ?> / <?php echo "$rok"; ?> 
    </span></td>
  </tr>
  <tr>
    <td width="59%" height="70" align="center" valign="middle"><span class="style11">PROTOKӣ nr <?php echo "$nr"; ?></span></td>
    <td width="22%" rowspan="2" align="center" valign="middle">&nbsp;</td>
  </tr>
  <tr>
    <td align="center" valign="middle">&nbsp;</td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="5%" align="right" valign="middle"><?php if ($c_1=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td width="1%" align="right" valign="middle">&nbsp;</td>
    <td width="94%"><span class="style8">Pobranie do naprawy uszkodzonego sprz�tu</span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><?php if ($c_2=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Przekazanie sprz�tu serwisowego </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><?php if ($c_3=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Zwrot naprawionego sprz�tu </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><?php if ($c_4=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Pobranie sprz�tu serwisowego </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><?php if ($c_5=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8"> Przekazanie sprz�tu do naprawy - serwisu </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><?php if ($c_6=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Odbi�r sprz�tu z naprawy - serwisu</span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><?php if ($c_7=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Wymiana cz�ci / remont sprz�tu <span class="style21">(niepotrzebne skre�li�)</span> </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><?php if ($c_8=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Przekazanie zam�wionego sprz�tu </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle">&nbsp;</td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><div align="right" class="style20">
      <div align="left">* zaznacz w�a�ciwe kwadraty </div>
    </div></td>
  </tr>
</table>
<br>
<table width="100%" border="1" cellspacing="0" cellpadding="5">
  <tr>
    <td width="4%" align="center" valign="middle"><span class="style23">LP</span></td>
    <td colspan="3" align="left"><span class="style23">Dane sprz�tu </span></td>
  </tr>
  <tr>
    <td height="95" align="center" valign="top"><span class="style8">1</span></td>
    <td width="30%" align="left" valign="top"><span class="style8">Nazwa kom�rki - piecz�tka </span></td>
    <td width="33%" align="center" valign="top">
	  <div align="left" class="style26 style25">Nazwa kom�rki</div>
	  <span class="style25"><br>
	  </span>      <span class="style8"><?php echo "<b>$put_up</b>"; ?></span></td>
    <td width="33%" align="left" valign="top">
	  <div align="left" class="style27">Piecz�tka</div>
	  <br>	
	</td>
  </tr>
  <tr>
    <td height="25" align="center"><span class="style8">2</span></td>
    <td align="left"><span class="style8">Nazwa urz�dzenia </span></td>
    <td colspan="2" align="left"><span class="style8"><?php echo "<b>$put_nazwa_urzadzenia</b>"; ?></span></td>
  </tr>
  <tr>
    <td height="25" align="center"><span class="style8">3</span></td>
    <td align="left"><span class="style8">Nr. seryjny urz�dzenia </span></td>
    <td colspan="2" align="left"><span class="style8"><?php echo "<b>$put_sn_urzadzenia</b>"; ?></span></td>
  </tr>
  <tr>
    <td height="25" align="center"><span class="style8">4</span></td>
    <td align="left"><span class="style8">Nr. inwentarzowy </span></td>
    <td colspan="2" align="left"><span class="style8"><?php echo "<b>$put_ni_urzadzenia</b>"; ?></span></td>
  </tr>
  <tr>
    <td height="80" align="center" valign="top"><span class="style8">5</span></td>
    <td align="left" valign="top"><span class="style8">Opis uszkodzenia </span></td>
    <td colspan="2" align="left" valign="top"><span class="style8"><?php echo "<b>$put_opis_urzadzenia</b>"; ?></span></td>
  </tr>
  <tr>
    <td height="100" align="center" valign="top"><span class="style8">6</span></td>
    <td align="left" valign="top"><span class="style8">Wykonane czynno�ci </span></td>
    <td colspan="2" align="left" valign="top"><span class="style8"><?php echo "<b>$put_wykonane_czynnosci</b>"; ?></span></td>
  </tr>
  <tr>
    <td height="80" align="center" valign="top"><span class="style8">7</span></td>
    <td align="left" valign="top"><span class="style8">Uwagi</span></td>
    <td colspan="2" align="left" valign="top"><span class="style8"><?php echo "<b>$put_uwagi</b>"; ?></span></td>
  </tr>
</table>
<br>
<br>
<br>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="250" align="center" valign="bottom"><span class="style25"><?php echo "$es_imie $es_nazwisko"; ?></span></td>
    <td width="100%" colspan="2" align="center"><div class="hideme" align="center">
	<a style="vertical-align:bottom; cursor:hand" onClick="javascript:window.print();"><img src="img\drukuj_protokol.jpg" border="0"></a>
<?php
if ($readonly!=1) {
?>	
	<a style="vertical-align:bottom" href="wypelnij_protokol.php?dzien=<?php echo "$dzien"; ?>&miesiac=<?php echo "$miesiac"; ?>&rok=<?php echo "$rok"; ?>&c_1=<?php echo "$c_1"; ?>&c_2=<?php echo "$c_2"; ?>&c_3=<?php echo "$c_3"; ?>&c_4=<?php echo "$c_4"; ?>&c_5=<?php echo "$c_5"; ?>&c_6=<?php echo "$c_6"; ?>&c_7=<?php echo "$c_7"; ?>&c_8=<?php echo "$c_8"; ?>&up=<?php echo "$up"; ?>&nazwa_urzadzenia=<?php echo "$nazwa_urzadzenia"; ?>&sn_urzadzenia=<?php echo "$sn_urzadzenia"; ?>&ni_urzadzenia=<?php echo "$ni_urzadzenia"; ?>&opis_urzadzenia=<?php echo "$opis_urzadzenia"; ?>&wykonane_czynnosci=<?php echo "$wykonane_czynnosci"; ?>&uwagi=<?php echo "$uwagi"; ?>&imieinazwisko=<?php echo "$imieinazwisko"; ?>"><img src="img\popraw.jpg" border="0"></a>
<?php 
}	
?>

</div></td>
    <td width="250">&nbsp;</td>
  </tr>
  <tr>
    <td width="250"><div align="left"><strong>............................................................</strong></div></td>
    <td width="100%" colspan="2"><div class="hideme" align="center"><a style="vertical-align:bottom; cursor:hand" onClick="window.close()"><img src="img\anuluj_protokol.jpg" border="0"></a></div></td>
    <td width="250"><div align="right"><strong>............................................................</strong></div></td>
  </tr>
  <tr>
    <td width="250" align="center"><div align="center" class="style24">strona przekazuj�ca </div></td>
    <td width="100%" colspan="2" align="center">&nbsp;</td>
    <td width="250" align="center"><div align="center" class="style24">strona odbieraj�ca </div></td>
  </tr>
</table>
</body>
</html>
