<?php include_once('header.php'); ?>

<body>

<?php 
if ($submit) { 
$search=$_GET[search1];

if ($search=="") {
  
  echo "<br><h2><center>Nie poda�e� ci�gu znak�w do wyszukania</center></h2>";
  echo "<br><center><input class=buttons type=button onClick=window.close() value='Zamknij'></center>";
  
} else {


$sql_a = "SELECT * FROM serwis_faktury WHERE ((belongs_to='$es_filia') and (
faktura_numer LIKE '%$search%' or
faktura_data LIKE '%$search%' or 
faktura_dostawca LIKE '%$search%'))";

$result_a = mysql_query($sql_a, $conn) or die(mysql_error());
$count_rows=0;
while ($dane3 = mysql_fetch_array($result_a)) 
{
	$count_rows+=1;
}
if ($count_rows==0) {

  echo "<br><h2><center>Nie znaleziono pozycji spe�niaj�cych podane przez Ciebie kryteria</center></h2>";
  echo "<br><center><input class=buttons type=button onClick=window.close() value='Zamknij'></center>";
  
  
} else {	

	echo "<br><h4><center>Wyniki wyszukiwania ci�gu znak�w<font class=blue_font></h4><h5>$search</font>";
	
	echo "</center></h5>";
						
echo "<table cellspacing=1 class=titlebar_add align=center width=96%>";
echo "<tr class=titlebar_add_n>";
echo "<td width=20><center>LP</center></td><td>&nbsp;Numer faktury</td><td><center>Ilo�� pozycji<br>na fakturze</center></td><td><center>Data wystawienia</center></td><td>&nbsp;Dostawca</td><td width=100>&nbsp;Koszty dodatkowe</td>";

echo "<td>Status</td>";

echo "</tr>";

$sql_a = "SELECT * FROM serwis_faktury WHERE ((belongs_to='$es_filia') and (
faktura_numer LIKE '%$search%' or
faktura_data LIKE '%$search%' or 
faktura_dostawca LIKE '%$search%'))";

$result_a = mysql_query($sql_a, $conn) or die(mysql_error());

$i=0;
$j = 1;

while ($newArray = mysql_fetch_array($result_a)) {		
	
	$temp_id  			= $newArray['faktura_id'];
	$temp_numer			= $newArray['faktura_numer'];
	$temp_data			= $newArray['faktura_data'];
	$temp_dostawca		= $newArray['faktura_dostawca'];
	$temp_koszty		= $newArray['faktura_koszty_dodatkowe'];
	$temp_osoba			= $newArray['faktura_osoba'];
	$temp_datawpisu		= $newArray['faktura_datawpisu'];
	$temp_status		= $newArray['faktura_status'];
  
 	if ($i % 2 != 0 ) echo "<tr id=$i class=nieparzyste onmouseover=rowOver('$i',1); this.style.cursor=arrow onmouseout=rowOver('$i',0) onclick=selectRow('$i') ondblclick=deSelectRow('$i')>";
	if ($i % 2 == 0 ) echo "<tr id=$i class=parzyste onmouseover=rowOver('$i',1); this.style.cursor=arrow onmouseout=rowOver('$i',0) onclick=selectRow('$i') ondblclick=deSelectRow('$i')>";

							  	$i+=1;

//echo "<a class=opt href=p_faktura_pozycje.php?id=$temp_id target=_blank title=' Poka� pozycje na fakturze '>";
echo "<a onclick=\"newWindow_r(800,600,'p_faktura_pozycje.php?id=$temp_id')\">";
							
echo "<td width=30 align=center>$j</td>";
echo "<td>&nbsp;$temp_numer</td>";


$count=0;

$sql1="SELECT * FROM serwis_faktura_szcz WHERE ((belongs_to='$es_filia') and (pozycja_nr_faktury='$temp_id'))";

$result1 = mysql_query($sql1, $conn) or die(mysql_error());
$count_rows = mysql_num_rows($result1);

$count=$count_rows;

echo "<td width=100><b><center>$count</center></b></td>";
							
echo "<td width=120><center>$temp_data</center></td>";
echo "<td>&nbsp;$temp_dostawca</td>";
echo "<td width=80>&nbsp;$temp_koszty z�</td>";
echo "</a>";
$j+=1;		   
 
if ($temp_status==0) { 
echo "<td width=100 align=center><center>niezatwierdzona</center>";
} else {
	echo "<td width=100 align=center><center><b>zatwierdzona</center></b>";
} 						   
 
$i+=1;
echo "</tr>";
							}
							
							echo "</table>";
							
	echo "<br><center><input class=buttons type=button onClick=window.close() value='Zamknij'></center>";
		}	
	}			

} else { ?>

<?php

	echo "<br><h4><center>Szukaj faktury</center></h4><br>";
	echo "<form name=ruch action=fsf.php target=_blank method=GET>";
	
	echo "<table cellspacing=1 align=center class=titlebar_add width=200";
	echo "<tr class=titlebar_add><td>&nbsp;</td></tr>";

	echo "<tr class=titlebar_add>";
	echo "<td align=center colspan=2>";
	echo "<b>Znajd? ci�g znak�w<br><br></b>";
	echo "</td>";
	echo "</tr>";
	
	echo "<tr class=titlebar_add>";
	echo "<td colspan=2 align=center>&nbsp;<input class=wymagane size=30 type=text name=search1>&nbsp;</td>";
	echo "</tr>";		

	echo "<tr class=titlebar_add>";
	echo "<td align=right colspan=2>";
    echo "<br><input class=buttons type=submit name=submit value='Szukaj'>&nbsp;&nbsp;&nbsp;&nbsp;<br>&nbsp;<br></td>";
	echo "</tr>";	
	
	echo "</table>";
	echo "</form>";	

?>

<script language="JavaScript" type="text/javascript">
  var frmvalidator  = new Validator("ruch");
  
  frmvalidator.addValidation("search1","req","Nie wpisano zadnego znaku");
  
</script>
	
<?php } ?>
</body>
</html>