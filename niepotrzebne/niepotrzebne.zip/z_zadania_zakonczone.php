<?php include_once('header.php'); ?>
<body>
<?php include_once('body_start.php'); ?>
<?php

$sql="SELECT * FROM serwis_zadania WHERE (";

if ($es_m!=1) {
	$sql=$sql."(belongs_to='$es_filia') and ";
}

$sql=$sql."(zadanie_status=9)) ORDER BY zadanie_data_utworzenia DESC";
$result = mysql_query($sql, $conn) or die(mysql_error());
$count_rows = mysql_num_rows($result);

// paging
// ============================================================================================================
$totalrows = mysql_num_rows($result);
if(empty($page)){ $page = 1; }

if ($showall==0) {
  $rps=$rowpersite;
} else $rps=10000;

$limitvalue = $page * $rps - ($rps);
$sql=$sql." LIMIT $limitvalue, $rps";
$result = mysql_query($sql, $conn) or die(mysql_error());
// ============================================================================================================
// koniec - paging

if ($count_rows!=0) {
echo "<h4>Przegl�danie zako�czonych zada�</h4>";

echo "<div align=center>";

if ($showall==0) {
echo "<a class=nav_normal href=z_zadania_zakonczone.php?showall=1&paget=$page>Poka� wszystko na jednej stronie</a>";
} else {
echo "<a class=nav_normal href=z_zadania_zakonczone.php?showall=0&page=$paget>Dziel na strony</a>";	
}

echo "</div>";

echo "<table cellspacing=1 class=titlebar_add align=center width=98%>";
echo "<tr class=titlebar_add_n>";
echo "<th width=30><center>LP</center></th><th>&nbsp;Opis zadania&nbsp;</th><th width=120>&nbsp;Data utworzenia&nbsp;<br>&nbsp;Utworzone przez</th><th width=120>&nbsp;Termin zako�czenia&nbsp;</th><th width=120>&nbsp;Data zako�czenia<br>&nbsp;Zako�czone przez</th><th width=120><center>&nbsp;Status<br>&nbsp;% wykonania&nbsp;</center></th><th><center>&nbsp;Opcje&nbsp;</center></th>";

echo "</tr>";

$i = 0;
$j = $page*$rowpersite-$rowpersite+1;
	
while ($newArray = mysql_fetch_array($result)) {
	$temp_id  			= $newArray['zadanie_id'];
	$temp_opis			= $newArray['zadanie_opis'];
	$temp_termin_zak	= $newArray['zadanie_termin_zakonczenia'];
	$temp_data_zak		= $newArray['zadanie_data_zakonczenia'];
	$temp_osoba_zak		= $newArray['zadanie_zakonczone_przez'];
	$temp_status		= $newArray['zadanie_status'];
	$temp_data_utw		= $newArray['zadanie_data_utworzenia'];
	$temp_osoba_utw		= $newArray['zadanie_utworzone_przez'];
	$temp_priorytet		= $newArray['zadanie_priorytet'];
	
 	if ($i % 2 != 0 ) echo "<tr id=$i class=nieparzyste onmouseover=rowOver('$i',1); this.style.cursor=arrow onmouseout=rowOver('$i',0) onclick=selectRow('$i') ondblclick=deSelectRow('$i')>";
	if ($i % 2 == 0 ) echo "<tr id=$i class=parzyste onmouseover=rowOver('$i',1); this.style.cursor=arrow onmouseout=rowOver('$i',0) onclick=selectRow('$i') ondblclick=deSelectRow('$i')>";
	
	echo "<td width=30 align=center>$j</td>";
	echo "<td>&nbsp;$temp_opis</td>";
	
	if ($temp_data_utw=='0000-00-00 00:00:00') $temp_data_utw='&nbsp;';
	if ($temp_termin_zak=='0000-00-00 00:00:00') $temp_termin_zak='nieokre�lony';

	if ($temp_osoba_zak=='') $temp_osoba_zak='&nbsp;';
	echo "<td>&nbsp;$temp_data_utw&nbsp;<br>&nbsp;$temp_osoba_utw&nbsp;</td>";
	if ($temp_termin_zak!='nieokre�lony') { $termin = substr($temp_termin_zak,0,10); } else $termin=$temp_termin_zak;
	echo "<td><center>&nbsp;<b>$termin</b>&nbsp;</center></td>";
	
	echo "<td>&nbsp;$temp_data_zak&nbsp;<br>&nbsp;$temp_osoba_zak&nbsp;</td>";
	
	if ($temp_status==-1) $status='w przygotowaniu';
	if ($temp_status==0) $status='nowe';
	if ($temp_status==1) $status='wykonywane';
	if ($temp_status==9) $status='zako�czone';
	
	echo "<td><center><b>$status</b></center></td>";

	$j+=1;

	echo "<td width=30 align=center>";
	
//	echo "<a title= ' Zako�cz zadanie $temp_opis '><input type=image src=img/accept.gif  onclick=\"newWindow(550,115,'z_zadania_zamknij.php?id=$temp_id')\"></a>";
	
	echo "</td>";
	$i+=1;
}

echo "</table>";

// paging_end
include_once('paging_end.php');
// paging_end

echo "<div clas=showr><input class=startpage type=button onClick=\"window.location.href='$linkdostronyglownej'\" value='Wr�� do strony g��wnej'></div>";

} else {
	echo "<h2>Brak zako�czonych zada� w bazie</h2>";
	echo "<div clas=showr><input class=startpage type=button onClick=\"window.location.href='$linkdostronyglownej'\" value='Wr�� do strony g��wnej'></div>";
}

?>
<?php include('body_stop.php'); ?>
</body>
</html>