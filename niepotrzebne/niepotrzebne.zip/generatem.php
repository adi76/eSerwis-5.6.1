<?php 
	require_once 'cfg_eserwis.php';
	session_start(); 
	if (!session_is_registered('es_autoryzacja')) { header("Location: ".$linkdostrony.""); }
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<title><?php echo "$nazwa_aplikacji"; ?></title>
<style type="text/css">
<!--
.style8 {font-family: Arial, Helvetica, sans-serif; font-size: 16px; }
.style11 {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-size: 30px;
}
.style20 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.style21 {font-size: 12px}
.style23 {font-family: Arial, Helvetica, sans-serif; font-size: 16px; font-weight: bold; }
.style24 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }
.style25 {font-family: Arial, Helvetica, sans-serif}
-->
</style>
</head>

<body OnLoad="document.protokol1.dzien.focus();">
<form name="protokol1" action="generate_do.php" method="POST">

<?php

if ($type=='1') { $opcja1="on"; } else {$opcja1="off";}
if ($type=='2') { $opcja2="on"; } else {$opcja2="off";}
if ($type=='3') { $opcja3="on"; } else {$opcja3="off";}
if ($type=='4') { $opcja4="on"; } else {$opcja4="off";}
if ($type=='5') { $opcja5="on"; } else {$opcja5="off";}
if ($type=='6') { $opcja6="on"; } else {$opcja6="off";}
if ($type=='7') { $opcja7="on"; } else {$opcja7="off";}
if ($type=='8') { $opcja8="on"; } else {$opcja8="off";}

if ($type=='12') { $opcja1="on"; $opcja2="on"; } else {$opcja1="off"; $opcja2="off"; }
if ($type=='34') { $opcja3="on"; $opcja4="on"; } else {$opcja3="off"; $opcja4="off"; }


if ($opcja1=="on") { echo "<input type=hidden name=opcja_1 value=$opcja1>"; } else echo "<input type=hidden name=opcja_1 value='&nbsp'>";

if ($opcja2=="on") { echo "<input type=hidden name=opcja_2 value=$opcja2>"; } else echo "<input type=hidden name=opcja_2 value='&nbsp'>";

if ($opcja3=="on") { echo "<input type=hidden name=opcja_3 value=$opcja3>"; } else echo "<input type=hidden name=opcja_3 value='&nbsp'>";

if ($opcja4=="on") { echo "<input type=hidden name=opcja_4 value=$opcja4>"; } else echo "<input type=hidden name=opcja_4 value='&nbsp'>";

if ($opcja5=="on") { echo "<input type=hidden name=opcja_5 value=$opcja5>"; } else echo "<input type=hidden name=opcja_5 value='&nbsp'>";

if ($opcja6=="on") { echo "<input type=hidden name=opcja_6 value=$opcja6>"; } else echo "<input type=hidden name=opcja_6 value='&nbsp'>";

if ($opcja7=="on") { echo "<input type=hidden name=opcja_7 value=$opcja7>"; } else echo "<input type=hidden name=opcja_7 value='&nbsp'>";

if ($opcja8=="on") { echo "<input type=hidden name=opcja_8 value=$opcja8>"; } else echo "<input type=hidden name=opcja_8 value='&nbsp'>";

$sql = "SELECT * FROM serwis_historia WHERE (historia_id=$id) LIMIT 1";
$result = mysql_query($sql, $conn) or die(mysql_error());
//echo "$sql";

while ($dane = mysql_fetch_array($result)) {
	$mid 		= $dane['magazyn_id'];
	$mnazwa 	= $dane['magazyn_nazwa'];
	$mmodel		= $dane['magazyn_model'];
	$msn	 	= $dane['magazyn_sn'];
	$mni		= $dane['magazyn_ni'];
	$mup		= $dane['naprawa_pobrano_z'];
	$moo		= $dane['naprawa_osoba_pobierajaca'];
	$mdp		= $dane['naprawa_data_pobrania'];
	$mstatus	= $dane['naprawa_status'];
							  
}

echo "<input type=hidden name=pid value=$id>";

$rok1 = substr($mdp, 0, 4);
$miesiac1 = substr($mdp,5,2);
$dzien1 = substr($mdp,8,2);

echo "<input type=hidden name=dzien5 value=$dzien1>";
echo "<input type=hidden name=miesiac5 value=$miesiac1>";
echo "<input type=hidden name=rok5 value=$rok1>";


if ($type=='1') { $op1="on"; }
if ($type=='2') { $op2="on"; }
if ($type=='3') { $op3="on"; }
if ($type=='4') { $op4="on"; }
if ($type=='5') { $op5="on"; }
if ($type=='6') { $op6="on"; }
if ($type=='7') { $op7="on"; }
if ($type=='8') { $op8="on"; }

if ($type=='12') { $op1="on"; $op2="on"; }
if ($type=='34') { $op3="on"; $op4="on"; }



$put_up=$mup;
$put_nazwa_urzadzenia=$mnazwa;
$put_sn_urzadzenia=$msn;
$put_ni_urzadzenia=$mni;

echo "<input type=hidden name=put_up5 value=$put_up>";
echo "<input type=hidden name=put_nazwa_urzadzenia5 value=$put_nazwa_urzadzenia>";
echo "<input type=hidden name=put_sn_urzadzenia5 value=$put_sn_urzadzenia>";
echo "<input type=hidden name=put_ni_urzadzenia5 value=$put_ni_urzadzenia>";
echo "<input type=hidden name=put_uwagi5 value=$put_uwagi>";

if ($_POST['opis_urzadzenia']==""){ $put_opis_urzadzenia="&nbsp;";} else { $put_opis_urzadzenia=$_POST['opis_urzadzenia']; }
if ($_POST['wykonane_czynnosci']==""){ $put_wykonane_czynnosci="&nbsp;";} else { $put_wykonane_czynnosci=$_POST['wykonane_czynnosci']; }
if ($_POST['uwagi']=="") {$put_uwagi="&nbsp;";} else { $put_uwagi=$_POST['uwagi']; }

?>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%" rowspan="3"><div align="right"><img src="img/logo.gif"></div></td>
    <td colspan="2" align="right" valign="top"><span class="style8">Data <?php echo "$dzien1"; ?> / <?php echo "$miesiac1"; ?> / <?php echo "$rok1"; ?> 
    </span></td>
  </tr>
  <tr>
    <td width="59%" height="78" align="center" valign="middle"><span class="style11">PROTOKӣ</span></td>
    <td width="22%" rowspan="2" align="center" valign="middle">&nbsp;</td>
  </tr>
  <tr>
    <td align="center" valign="middle">&nbsp;</td>
  </tr>
</table>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="5%" align="right" valign="middle"><?php if ($op1=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td width="1%" align="right" valign="middle">&nbsp;</td>
    <td width="94%"><span class="style8">Pobranie do naprawy uszkodzonego sprz�tu</span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><?php if ($op2=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Przekazanie sprz�tu serwisowego </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><?php if ($op3=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Zwrot naprawionego sprz�tu </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><?php if ($op4=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Pobranie sprz�tu serwisowego </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><?php if ($op5=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8"> Przekazanie sprz�tu do naprawy - serwisu </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><?php if ($op6=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Odbi�r sprz�tu z naprawy - serwisu</span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><?php if ($op7=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Wymiana cz�ci / remont sprz�tu <span class="style21">(niepotrzebne skre�li�)</span> </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><?php if ($op8=="on") { echo "<img src=img/checkbox_on.gif border=0>"; } else echo "<img src=img/checkbox.gif border=0>"; ?></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Przekazanie zam�wionego sprz�tu </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle">&nbsp;</td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><div align="right" class="style20">* zaznacz w�a�ciwe kwadraty </div></td>
  </tr>
</table>

<br>


<table width="100%" border="1" cellspacing="0" cellpadding="5">
  <tr>
    <td width="4%" align="center" valign="middle"><span class="style23">LP</span></td>
    <td colspan="3" align="left"><span class="style23">Dane sprz�tu </span></td>
  </tr>
  <tr>
    <td height="97" align="center" valign="top"><span class="style8">1</span></td>
    <td width="30%" align="left" valign="top"><span class="style8">Nazwa kom�rki - piecz�tka </span></td>
    <td width="33%" align="center">
	  <span class="style8"><?php echo "<b>$put_up</b>"; ?></span>	</td>
    <td width="33%">&nbsp;</td>
  </tr>
  <tr>
    <td align="center"><span class="style8">2</span></td>
    <td align="left"><span class="style8">Nazwa urz�dzenia </span></td>
    <td colspan="2" align="left"><span class="style8"><?php echo "<b>$put_nazwa_urzadzenia</b>";?></span></td>
  </tr>
  <tr>
    <td align="center"><span class="style8">3</span></td>
    <td align="left"><span class="style8">Nr. seryjny urz�dzenia </span></td>
    <td colspan="2" align="left"><span class="style8"><?php echo "<b>$put_sn_urzadzenia</b>"; ?></span></td>
  </tr>
  <tr>
    <td align="center"><span class="style8">4</span></td>
    <td align="left"><span class="style8">Nr. inwentarzowy </span></td>
    <td colspan="2" align="left"><span class="style8"><?php echo "<b>$put_ni_urzadzenia</b>"; ?></span></td>
  </tr>
  <tr>
    <td height="98" align="center" valign="top"><span class="style8">5</span></td>
    <td align="left" valign="top"><span class="style8">Opis uszkodzenia </span></td>
    <td colspan="2" align="left" valign="top"><span class="style8"><textarea name="opis_urzadzenia" cols=60 rows=5></textarea></span></td>
  </tr>
  <tr>
    <td height="124" align="center" valign="top"><span class="style8">6</span></td>
    <td align="left" valign="top"><span class="style8">Wykonane czynno�ci </span></td>
    <td colspan="2" align="left" valign="top"><span class="style8"><textarea name="wykonane_czynnosci" cols=60 rows=6></textarea></span></td>
  </tr>
  <tr>
    <td height="120" align="center" valign="top"><span class="style8">7</span></td>
    <td align="left" valign="top"><span class="style8">Uwagi</span></td>
    <td colspan="2" align="left" valign="top"><span class="style8"><textarea name="uwagi" cols=60 rows=6></textarea></span></td>
  </tr>
</table>
<br>
<br>
<br>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="25%" align="center" valign="bottom"><span class="style25"><?php echo "$es_imie $es_nazwisko"; ?></span></td>
    <td colspan="2" align="center"><div align="center">
      <input class="buttons" type="submit" name="submit" value="Generuj protok�">
    </div></td>
    <td width="25%">&nbsp;</td>
  </tr>
  <tr>
    <td><div align="left"><strong>............................................................</strong></div></td>
    <td width="25%">&nbsp;</td>
    <td width="25%">&nbsp;</td>
    <td><div align="right"><strong>............................................................</strong></div></td>
  </tr>
  <tr>
    <td><div align="center" class="style24">strona przekazuj�ca </div></td>
    <td colspan="2" align="center"><div align="center">
      <input name="button" type="button" class="buttons" onClick="window.close()" value="Anuluj przygotowywanie protoko�u">
    </div></td>
    <td><div align="center" class="style24">strona odbieraj�ca </div></td>
  </tr>
</table>
</form>
</body>
</html>
