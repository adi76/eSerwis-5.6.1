<?php include_once('header.php'); ?>
<body>
<?php
	echo "rozpoczynam....";

	$sqll="SELECT * FROM serwis_ewidencja WHERE belongs_to='$es_filia'";
	$resultl = mysql_query($sqll, $conn) or die(mysql_error());

	while ($dane = mysql_fetch_array($resultl)) {

								  $eid 		= $dane['ewidencja_id'];
								  $etyp_id	= $dane['ewidencja_typ'];
								  $eup_id	= $dane['ewidencja_up_id'];
								  $euser	= $dane['ewidencja_uzytkownik'];									  
								  $enrpok	= $dane['ewidencja_nr_pokoju'];
								  $enizest	= $dane['ewidencja_zestaw_ni'];
								  $eknazwa	= $dane['ewidencja_komputer_nazwa'];
								  $ekopis	= $dane['ewidencja_komputer_opis'];
								  $eksn		= $dane['ewidencja_komputer_sn'];
								  $ekip		= $dane['ewidencja_komputer_ip'];
								  $eke		= $dane['ewidencja_komputer_endpoint'];
								  $emo		= $dane['ewidencja_monitor_opis'];
								  $emsn		= $dane['ewidencja_monitor_sn'];
								  $edo		= $dane['ewidencja_drukarka_opis'];
								  $edsn		= $dane['ewidencja_drukarka_sn'];
								  $edni		= $dane['ewidencja_drukarka_ni'];
								  $eu		= $dane['ewidencja_uwagi'];
								  $es		= $dane['ewidencja_status'];
								  $eo_id	= $dane['ewidencja_oprogramowanie'];
								  $emoduser = $dane['ewidencja_modyfikacja_user'];
								  $emoddata	= $dane['ewidencja_modyfikacja_date'];
								  $ekonf	= $dane['ewidencja_konfiguracja'];
								  
								  $k__procesor 	= $dane['k_procesor'];
								  $k__pamiec	= $dane['k_pamiec'];
								  $k__dysk		= $dane['k_dysk'];


				$sqls="SELECT * FROM serwis_slownik_konfiguracja WHERE konfiguracja_nazwa='$ekonf' LIMIT 1";
				$results = mysql_query($sqls, $conn) or die(mysql_error());	
				
				while ($danes = mysql_fetch_array($results)) {
			
											  $pr 		= $danes['procesor'];
											  $pa		= $danes['pamiec'];
											  $dy		= $danes['dysk'];
			
					$k__procesor=$pr;
					$k__pamiec=$pa;
					$k__dysk=$dy;
			
					$konf_opis='Procesor '.$k__procesor.'GHz, '.$k__pamiec.'MB RAM, '.$k__dysk.'GB HDD';
					
				$sqlu="UPDATE serwis_ewidencja SET k_procesor='$k__procesor',k_pamiec='$k__pamiec', k_dysk='$k__dysk', ewidencja_konfiguracja='$konf_opis' WHERE ewidencja_id='$eid' LIMIT 1";
				$resultu = mysql_query($sqlu, $conn) or die(mysql_error());	
			
				}

	
}

echo "<br>koniec";

?>

</body>
</html>