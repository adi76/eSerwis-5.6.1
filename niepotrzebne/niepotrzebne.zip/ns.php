<?php include_once('header_begin.php'); ?>

	<SCRIPT>

	function validateForm() {
		if (document.ruch.search1.value=="") { alert('Nie wpisano �adnego znaku'); document.ruch.search1.focus(); return false; }		
	}

	</SCRIPT>
</head>

<body>

<?php 
if ($submit) { 
$search=$_GET[search1];

$sql_a = "SELECT * FROM serwis_naprawa WHERE belongs_to='$es_filia' and (
naprawa_nazwa LIKE '%$search%' or
naprawa_model LIKE '%$search%' or 
naprawa_sn LIKE '%$search%' or 
naprawa_ni LIKE '%$search%' or 
naprawa_uwagi LIKE '%$search%' or 
naprawa_pobrano_z LIKE '%$search%' or 
naprawa_osoba_pobierajaca LIKE '%$search%' or 
naprawa_fs_nazwa LIKE '%$search%' or 
naprawa_fk_nazwa LIKE '%$search%' or 
naprawa_osoba_wysylajaca LIKE '%$search%' or 
naprawa_nr_listu_przewozowego LIKE '%$search%' or 
naprawa_osoba_przyjmujaca_sprzet_z_serwisu LIKE '%$search%' or 
naprawa_osoba_oddajaca_sprzet LIKE '%$search%' or 
naprawa_nwwz_osoba LIKE '%$search%')";

$result_a = mysql_query($sql_a, $conn) or die(mysql_error());
$count_rows=0;
while ($dane3 = mysql_fetch_array($result_a)) {	

	$count_rows+=1;

}
if ($count_rows==0) {

  echo "<h2><center>Nie znaleziono pozycji spe�niaj�cych podane przez Ciebie kryteria</center></h2>";
  echo "<p align=right>";
echo "<input class=buttons type=button onClick=\"window.history.go(-1);\" value='Zmie� kryteria'>&nbsp;";
echo "<input class=startpage type=button onClick=\"window.location.href='$linkdostronyglownej'\" value='Wr�� do strony g��wnej'>&nbsp;&nbsp;&nbsp;&nbsp;</p>"; 
  
} else {	

	echo "<h4><center>Wyniki wyszukiwania ci�gu znak�w<font class=blue_font></h4><h5>$search</font>";
	
	echo "</center></h5>";
						
echo "<table cellspacing=1 align=center class=titlebar_add width=98%>";
			
echo "<tr class=titlebar_add_n>";
echo "<td><center>LP</center></td>";
echo "<td>&nbsp;Nazwa<br>&nbsp;Model</td>";
//echo "<td>Model</td>";
echo "<td>&nbsp;SN<br>&nbsp;NI</td>";
echo "<td>&nbsp;Pobrano z</td>";
//echo "<td>Numer inwentarzowy</td>";
//echo "<td><center>Uwagi</center></td>";
echo "<td>&nbsp;Przyj�cie sprz�tu<br>&nbsp;Data przyj�cia</td>";
echo "<td aling=center><center>Status</center></td>";
//echo "<td>Opcje</td>";

echo "</tr>";

$sql_a = "SELECT * FROM serwis_naprawa WHERE belongs_to='$es_filia' and (
naprawa_nazwa LIKE '%$search%' or
naprawa_model LIKE '%$search%' or 
naprawa_sn LIKE '%$search%' or 
naprawa_ni LIKE '%$search%' or 
naprawa_uwagi LIKE '%$search%' or 
naprawa_pobrano_z LIKE '%$search%' or 
naprawa_osoba_pobierajaca LIKE '%$search%' or 
naprawa_fs_nazwa LIKE '%$search%' or 
naprawa_fk_nazwa LIKE '%$search%' or 
naprawa_osoba_wysylajaca LIKE '%$search%' or 
naprawa_nr_listu_przewozowego LIKE '%$search%' or 
naprawa_osoba_przyjmujaca_sprzet_z_serwisu LIKE '%$search%' or 
naprawa_osoba_oddajaca_sprzet LIKE '%$search%' or 
naprawa_nwwz_osoba LIKE '%$search%')";

							//	echo "$sql_a";
$result_a = mysql_query($sql_a, $conn) or die(mysql_error());

$i=0;

while ($dane3 = mysql_fetch_array($result_a)) {		
	
  $mid 		= $dane3['naprawa_id'];
  $mnazwa 	= $dane3['naprawa_nazwa'];
  $mmodel	= $dane3['naprawa_model'];
  $msn	 	= $dane3['naprawa_sn'];
  $mni		= $dane3['naprawa_ni'];
  $muwagisa	= $dane3['naprawa_uwagi_sa'];
  $muwagi	= $dane3['naprawa_uwagi'];
  
  $mup		= $dane3['naprawa_pobrano_z'];
  $moo		= $dane3['naprawa_osoba_pobierajaca'];
  $mdp		= $dane3['naprawa_data_pobrania'];
  
  $mstatus	= $dane3['naprawa_status'];
  
 	if ($i % 2 != 0 ) echo "<tr id=$i class=nieparzyste onmouseover=rowOver('$i',1); this.style.cursor=arrow onmouseout=rowOver('$i',0) onclick=selectRow('$i') ondblclick=deSelectRow('$i')>";
	if ($i % 2 == 0 ) echo "<tr id=$i class=parzyste onmouseover=rowOver('$i',1); this.style.cursor=arrow onmouseout=rowOver('$i',0) onclick=selectRow('$i') ondblclick=deSelectRow('$i')>";

$i+=1;

//echo "<a class=opt href=szczegoly.php?id=$mid target=_blank>";
echo "<a onclick=\"newWindow(700,300,'szczegoly.php?id=$mid')\">";

echo "<td width=20 align=center>$i</td>";						

echo "<td>&nbsp;$mnazwa<br>&nbsp;$mmodel</td>";
//echo "<td>$mmodel</td>";
echo "<td>&nbsp;$msn<br>&nbsp;$mni</td>";
echo "<td>&nbsp;$mup</td>";
//echo "<td>$mni</td>";
echo "</a>";	
/*		if ($muwagisa=='1') {
  echo "<td width=40 align=center><a class=opt href=p_naprawy_uwagi.php?id=$mid target=_blank>&nbsp;czytaj&nbsp;</a>&nbsp;<a class=opt href=e_naprawy_uwagi.php?id=$mid target=_blank title='Edytuj uwagi'>&nbsp;E&nbsp;</a></td>";
} else echo "<td><a class=opt href=e_naprawy_uwagi.php?id=$mid target=_blank title='Dodaj uwagi'>&nbsp;dodaj&nbsp;</a></td>";
*/
//echo "<a class=opt href=szczegoly.php?id=$mid target=_blank>";
echo "<td width=120>&nbsp;$moo<br>&nbsp;$mdp</td>";



if ($mstatus=='-1') echo "<td width=90 align=center><a class=opt_g>pobrany od klienta</a></td>";
if ($mstatus=='0') echo "<td width=90 align=center><a class=opt_blue>naprawa we w�asnym zakresie</a></td>";
if ($mstatus=='1') echo "<td width=90 align=center><a class=opt_r>naprawa w serwisie zewn�trznym</a></td>";
if ($mstatus=='2') echo "<td width=90 align=center><a class=opt_b>naprawa na rynku lokalnym</a></td>";
if ($mstatus=='3') echo "<td width=90 align=center><a class=opt_w>naprawiony</a></td>";
if ($mstatus=='5') echo "<td width=90 align=center><a class=opt_pink>zwr�cony do klienta</a></td>";
echo "</a>";						

echo "</tr>";
}
echo "</table>";
echo "<br><p align=right>";
echo "<input class=buttons type=button onClick=\"window.history.go(-1);\" value='Zmie� kryteria'>&nbsp;";
echo "<input class=startpage type=button onClick=\"window.location.href='$linkdostronyglownej'\" value='Wr�� do strony g��wnej'>&nbsp;&nbsp;&nbsp;&nbsp;</p>"; 

		}	
	
} else { ?>

<?php

	echo "<h4><center>Szukaj naprawionego/naprawianego sprz�tu</center></h4><br>";
	echo "<form name=ruch action=ns.php method=GET onsubmit='return validateForm();'>";
	
	echo "<table cellspacing=1 align=center class=titlebar_add width=200";
	echo "<tr class=titlebar_add><td>&nbsp;</td></tr>";

	echo "<tr class=titlebar_add>";
	echo "<td align=center colspan=2>";
	echo "<b>Znajd� ci�g znak�w<br><br></b>";
	echo "</td>";
	echo "</tr>";
	
	echo "<tr class=titlebar_add>";
	echo "<td colspan=2 align=center>&nbsp;<input class=wymagane size=30 type=text name=search1>&nbsp;</td>";
	echo "</tr>";		
	
	echo "<tr class=titlebar_add>";
	echo "<td align=right colspan=2>";
    echo "<br><input class=buttons type=submit name=submit value='Szukaj'>&nbsp;&nbsp;&nbsp;&nbsp;<br>&nbsp;<br></td>";
	echo "</tr>";	
	
	echo "</table>";
	echo "</form>";	
?>

<?php } ?>
</body>
</html>
