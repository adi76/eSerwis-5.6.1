<?php include_once('header.php'); ?>

<?php

	$sql = 'DELETE FROM `serwis_firmy_serwisowe` WHERE belongs_to<>1'; 
    $result = mysql_query($sql, $conn) or die(mysql_error());

	$sql = 'DELETE FROM `serwis_historia` WHERE belongs_to<>1'; 
    $result = mysql_query($sql, $conn) or die(mysql_error());

?>
