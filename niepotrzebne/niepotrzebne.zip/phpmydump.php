<?php
require_once 'cfg_eserwis.php';

$host = $dbhost;      // MySQL hostname
//$dbname ='dbname';        // MySQL basename
$uid = $dbusername;          // MySQL user
$pwd = $dbpassword;       // MySQL password
$structure_only = false;  // set false to get table content
$output = true;           // set true to to get file with dump

set_time_limit(600);      // Number of seconds before timeout (does not work in safe mode!)

//////////////////////////////////////////////////
//
//  phpMyDump v1.0
//
//  check for new version
//  http://szewo.com/php/mydump/eng
//
//  some functions are adapted from the phpMyAdmin
//
//  do not change anything below this line
//
//////////////////////////////////////////////////

$con = @mysql_connect($host,$uid, $pwd) or die('Could not connect');
@mysql_select_db($dbname,$con) or die('Could not select db');

$crlf = "\n";
if (strstr($_SERVER['HTTP_USER_AGENT'], 'Win')) {
  $crlf = "\r\n";
} else if (strstr($_SERVER['HTTP_USER_AGENT'], 'Mac')) {
  $crlf = "\r";
}

$sql = '# --------------------------------------'.$crlf.
       '# MySQL dump by phpMyDump'.$crlf.
       '# Host: '.$host.$crlf.
       '# Database: '.$dbname.$crlf.
       '# --------------------------------------'.$crlf;

$res = @mysql_list_tables($dbname);
$nt = @mysql_num_rows($res);

for ($a = 0; $a < $nt; $a++) {

  $row = mysql_fetch_row($res);
  $tablename=$row[0];

  $sql .= $crlf.$crlf.
          '# --------------------------------------'.$crlf.
          '# Table structure for table \''.$tablename.'\''.$crlf.
          '# --------------------------------------'.$crlf.$crlf;

  $sql .= 'drop table if exists '.$tablename.';'.$crlf;
  $sql .= 'create table '.$tablename.' ('.$crlf;

  $result=mysql_query('show fields from '.$tablename, $con);

  $row = mysql_fetch_array($result);
  while ($row) {

    $sql .= '  '.$row['Field'];
    $sql .= ' '.$row['Type'];

    if (isset($row['Default']) && $row['Default'] != '') $sql .= ' default \''.$row['Default'].'\'';
    if ($row['Null'] != 'YES') $sql .= ' not null';
    if ($row['Extra'] != '') $sql .= ' '.$row['Extra'];

    $row = mysql_fetch_array($result);
    if ($row) $sql .= ','.$crlf;

  }

  mysql_free_result($result);

  $result = mysql_query('show keys from '.$tablename, $con);

  while ($row = mysql_fetch_array($result)) {

    $keyname  = $row['Key_name'];
    $comment  = (isset($row['Comment'])) ? $row['Comment'] : '';
    $sub_part = (isset($row['Sub_part'])) ? $row['Sub_part'] : '';

    if ($keyname != 'PRIMARY' && $row['Non_unique'] == 0) $keyname = 'UNIQUE|'.$keyname;
    if ($comment == 'FULLTEXT') $keyname = 'FULLTEXT|'.$keyname;
    if (!isset($index[$keyname])) $index[$keyname] = array();
    if ($sub_part > 1) {
      $index[$keyname][] = $row['Column_name'].'('.$sub_part.')';
    } else {
      $index[$keyname][] = $row['Column_name'];
    }

  }

  mysql_free_result($result);
    
  while (list($x, $columns) = @each($index)) {

    $sql .= ','.$crlf;

    if ($x == 'PRIMARY') {
      $sql .= '  primary key (';
    } else if (substr($x, 0, 6) == 'UNIQUE') {
      $sql .= '  unique '.substr($x, 7).' (';
    } else if (substr($x, 0, 8) == 'FULLTEXT') {
      $sql .= '  fulltext '.substr($x, 9).' (';
    } else {
      $sql .= '  key '.$x.' (';
    }

    $sql .= implode($columns, ', ').')';

  }

  $sql .= $crlf.');'.$crlf.$crlf;

  if ($structure_only == false) {

    // here we get table content
    $result = mysql_query('select * from '.$tablename, $con);

    $fields_cnt = mysql_num_fields($result);

    while ($row = mysql_fetch_row($result)) {

      $sql .= 'insert into '.$tablename.' values (';

      for ($j = 0; $j < $fields_cnt; $j++) {

        if ($j) $sql .= ', ';

        if (!isset($row[$j])) {

          $sql .= ' null';

        } else if ($row[$j] == '0' || $row[$j] != '') {

          $type = mysql_field_type($result, $j);
 
          if ($type == 'tinyint' || $type == 'smallint' || $type == 'mediumint' || $type == 'int' || $type == 'bigint' || $type == 'timestamp') {

            $sql .= $row[$j];

          } else {

            $dummy  = '';
            $srcstr = $row[$j];
            for ($xx = 0; $xx < strlen($srcstr); $xx++) {

              $yy = strlen($dummy);
              if ($srcstr[$xx] == '\\')   $dummy .= '\\\\';
              if ($srcstr[$xx] == '\'')   $dummy .= '\\\'';
              if ($srcstr[$xx] == "\x00") $dummy .= '\0';
              if ($srcstr[$xx] == "\x0a") $dummy .= '\n';
              if ($srcstr[$xx] == "\x0d") $dummy .= '\r';
              if ($srcstr[$xx] == "\x1a") $dummy .= '\Z';
              if (strlen($dummy) == $yy)  $dummy .= $srcstr[$xx];

            } // end for ($xx = 0; $xx < strlen($srcstr); $xx++)

            $sql .= '\''.$dummy.'\'';

          } // end if ($type == %numeric%)

        } else {

          $sql .= '\'\'';

        } // end if (!isset($row[$j]))

      } // end for ($j = 0; $j < $fields_cnt; $j++)

      $sql .= ');'.$crlf;

    } // end while ($row = mysql_fetch_row($result))

    mysql_free_result($result);

  }  // end if ($structure_only == false)

} // end for ($a = 0; $a < $nt; $a++)


// Send headers
if ($output == true) {

  header('Content-type: application/sql');
  header('Content-Disposition: attachment; filename='.$dbname.'_'.date("Y-m-d-H-i-s").'.sql');
  header('Pragma: no-cache');
  header('Expires: 0');
  echo $sql;

} else {

  echo "<html><body><pre>";
  echo htmlspecialchars($sql);
  echo "</pre></body></html>";

}

?>