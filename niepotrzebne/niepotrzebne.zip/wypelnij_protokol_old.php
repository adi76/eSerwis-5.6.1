<?php include_once('header_simple.php'); ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title><?php echo "$nazwa_aplikacji"; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<script type="text/javascript" src="js/saveRestoreForm.js"></script>
<title>Untitled Document</title>
<style type="text/css">
<!--
.style8 {font-family: Arial, Helvetica, sans-serif; font-size: 16px; }
.style11 {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-size: 30px;
}
.style20 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.style21 {font-size: 12px}
.style23 {font-family: Arial, Helvetica, sans-serif; font-size: 16px; font-weight: bold; }
.style24 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; }
.style25 {font-family: Arial, Helvetica, sans-serif}
-->
</style>
</head>

<body OnLoad="document.protokol.dzien.focus();">
<form name="protokol" action="wypelnij_protokol_old_do.php" method="GET">

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%" rowspan="3"><div align="right"><img src="img/logo2.gif"></div></td>
    <td colspan="2" align="right" valign="top"><span class="style8">Data <input name="dzien" type=text size="2" maxlength="2" value="<?php echo "$dzien"; ?>"> 
      / <input name="miesiac" type=text size="2" maxlength="2" value="<?php echo "$miesiac"; ?>"> 
      / <input name="rok" type=text size="2" maxlength="4" value="<?php echo "$rok"; ?>"> 
    </span></td>
  </tr>
  <tr>
    <td width="59%" height="70" align="center" valign="middle"><span class="style11">PROTOKӣ</span></td>
    <td width="22%" rowspan="2" align="center" valign="middle">&nbsp;</td>
  </tr>
  <tr>
    <td align="center" valign="middle">&nbsp;</td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="5%" align="right" valign="middle"><input type="checkbox" name="c_1" <?php if ($_GET[c_1]=='on') { echo "checked=checked"; } ?></td>
    <td width="1%" align="right" valign="middle">&nbsp;</td>
    <td width="94%"><span class="style8">Pobranie do naprawy uszkodzonego sprz�tu</span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><input type="checkbox" name="c_2" <?php if ($_GET[c_2]=='on') { echo "checked=checked"; } ?>></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Przekazanie sprz�tu serwisowego </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><input type="checkbox" name="c_3" <?php if ($_GET[c_3]=='on') { echo "checked=checked"; } ?>></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Zwrot naprawionego sprz�tu </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><input type="checkbox" name="c_4" <?php if ($_GET[c_4]=='on') { echo "checked=checked"; } ?>></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Pobranie sprz�tu serwisowego </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><input type="checkbox" name="c_5" <?php if ($_GET[c_5]=='on') { echo "checked=checked"; } ?>></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8"> Przekazanie sprz�tu do naprawy - serwisu </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><input type="checkbox" name="c_6" <?php if ($_GET[c_6]=='on') { echo "checked=checked"; } ?>></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Odbi�r sprz�tu z naprawy - serwisu</span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><input type="checkbox" name="c_7" <?php if ($_GET[c_7]=='on') { echo "checked=checked"; } ?>></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Wymiana cz�ci / remont sprz�tu <span class="style21">(niepotrzebne skre�li�)</span> </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><input type="checkbox" name="c_8" <?php if ($_GET[c_8]=='on') { echo "checked=checked"; } ?>></td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><span class="style8">Przekazanie zam�wionego sprz�tu </span></td>
  </tr>
  <tr>
    <td align="right" valign="middle">&nbsp;</td>
    <td align="right" valign="middle">&nbsp;</td>
    <td><div align="right" class="style20">* zaznacz w�a�ciwe kwadraty </div></td>
  </tr>
</table>

<br>


<table width="100%" border="1" cellspacing="0" cellpadding="5">
  <tr>
    <td width="4%" align="center" valign="middle"><span class="style23">LP</span></td>
    <td colspan="3" align="left"><span class="style23">Dane sprz�tu </span></td>
  </tr>
  <tr>
    <td height="97" align="center" valign="top"><span class="style8">1</span></td>
    <td width="30%" align="left" valign="top"><span class="style8">Nazwa kom�rki - piecz�tka </span></td>
    <td width="33%" align="center">
	
	<?php 
	
		$sql44="SELECT * FROM serwis_komorki WHERE belongs_to='$es_filia' ORDER BY up_nazwa";
		$result44 = mysql_query($sql44, $conn) or die(mysql_error());
		$count_rows = mysql_num_rows($result44);
			
		echo "<select name=up>\n"; 					 				
		echo "<option value=''>Wybierz z listy...";
				
		while ($newArray44 = mysql_fetch_array($result44)) 
		 {
			$temp_id  				= $newArray44['up_id'];
			$temp_nazwa				= $newArray44['up_nazwa'];
			
			echo "<option";
			if ($temp_nazwa==$up) { echo " SELECTED"; }
			echo " value='$temp_nazwa'>$temp_nazwa</option>\n"; 
		
		}
		
		echo "</select>\n"; 
	
	?>
	</td>
    <td width="33%">&nbsp;</td>
  </tr>
  <tr>
    <td align="center"><span class="style8">2</span></td>
    <td align="left"><span class="style8">Nazwa urz�dzenia </span></td>
    <td colspan="2" align="left"><input name="nazwa_urzadzenia" type=text size="60" value="<?php echo "$nazwa_urzadzenia"; ?>"></td>
  </tr>
  <tr>
    <td align="center"><span class="style8">3</span></td>
    <td align="left"><span class="style8">Nr. seryjny urz�dzenia </span></td>
    <td colspan="2" align="left"><input name="sn_urzadzenia" type=text size="40" value="<?php echo "$sn_urzadzenia"; ?>"></td>
  </tr>
  <tr>
    <td align="center"><span class="style8">4</span></td>
    <td align="left"><span class="style8">Nr. inwentarzowy </span></td>
    <td colspan="2" align="left"><input name="ni_urzadzenia" type=text size="40" value="<?php echo "$ni_urzadzenia"; ?>"></td>
  </tr>
  <tr>
    <td height="98" align="center" valign="top"><span class="style8">5</span></td>
    <td align="left" valign="top"><span class="style8">Opis uszkodzenia </span></td>
    <td colspan="2" align="left" valign="top"><textarea name="opis_uszkodzenia" cols=60 rows=5><?php echo "$opis_uszkodzenia"; ?></textarea></td>  </tr>
  <tr>
    <td height="124" align="center" valign="top"><span class="style8">6</span></td>
    <td align="left" valign="top"><span class="style8">Wykonane czynno�ci </span></td>
    <td colspan="2" align="left" valign="top"><textarea name="wykonane_czynnosci" cols=60 rows=5><?php echo "$wykonane_czynnosci"; ?></textarea></td>
  </tr>
  <tr>
    <td height="120" align="center" valign="top"><span class="style8">7</span></td>
    <td align="left" valign="top"><span class="style8">Uwagi</span></td>
    <td colspan="2" align="left" valign="top"><textarea name="uwagi" cols=60 rows=5><?php echo "$uwagi"; ?></textarea></td>
  </tr>
</table>
<br>
<br>
<br>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="250" align="center" valign="bottom"><span class="style25"><?php echo "$es_imie $es_nazwisko"; ?></span></td>
    <td width="100%" colspan="2" align="center"><div align="center"><input class="buttons" type="submit" name="submit" value="Generuj protok�">&nbsp;<input class="buttons" type="reset" name="reset" value="Wyczy�� protok�"></div></td>
    <td width="250">&nbsp;</td>
  </tr>
  <tr>
    <td width="250"><div align="left"><strong>............................................................</strong></div></td>
    <td width="100%" colspan="2" align="center"></td>
    <td width="250"><div align="right"><strong>............................................................</strong></div></td>
  </tr>
  <tr>
    <td width="250" align="center"><div align="center" class="style24">strona przekazuj�ca </div></td>
    <td width="100%" align="center" colspan="2"><div align="center"><input class="buttons" type="button" onClick="window.close()" value="&nbsp;&nbsp;Anuluj przygotowywanie protoko�u&nbsp;"></div></td>
    <td width="250"><div align="center" class="style24">strona odbieraj�ca </div></td>
  </tr>
</table>
   <input type="hidden" name="imieinazwisko" value="<?php echo "$es_imie $es_nazwisko"; ?>">
   <input type="hidden" name="readonly" value="0">
      
</form>
</body>
</html>
