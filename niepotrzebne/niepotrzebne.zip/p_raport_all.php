<?php include_once('header.php'); ?>

<body>

<?php

/*
// MAGAZYN

// ca�y magazyn
$sql = "SELECT magazyn_id FROM serwis_magazyn WHERE belongs_to='$es_filia'";
$result = mysql_query($sql, $conn) or die(mysql_error());
$magazyn_ilosc_cala = mysql_num_rows($result);

// ilo�� dost�pna
$sql = "SELECT magazyn_id FROM serwis_magazyn WHERE magazyn_status='0' and belongs_to='$es_filia'";
$result = mysql_query($sql, $conn) or die(mysql_error());
$magazyn_ilosc_dostepna = mysql_num_rows($result);

//ilosc pobrana
$sql = "SELECT magazyn_id FROM serwis_magazyn WHERE magazyn_status='1' and belongs_to='$es_filia'";
$result = mysql_query($sql, $conn) or die(mysql_error());
$magazyn_ilosc_pobrana = mysql_num_rows($result);

//ilosc zarezerwowana
$sql = "SELECT magazyn_id FROM serwis_magazyn WHERE magazyn_status='2' and belongs_to='$es_filia'";
$result = mysql_query($sql, $conn) or die(mysql_error());
$magazyn_ilosc_zarezerwowana = mysql_num_rows($result);

//ilosc ukryta
$sql = "SELECT magazyn_id FROM serwis_magazyn WHERE magazyn_status='3' and belongs_to='$es_filia'";
$result = mysql_query($sql, $conn) or die(mysql_error());
$magazyn_ilosc_ukryta = mysql_num_rows($result);

// NAPRAWY
// ilosc pobrana od klienta
$sql = "SELECT naprawa_id FROM serwis_naprawa WHERE naprawa_status='-1' and belongs_to='$es_filia'";
$result = mysql_query($sql, $conn) or die(mysql_error());
$naprawy_ilosc_pobrana = mysql_num_rows($result);

// ilosc naprawa w serwisie lok lub w�asna .
$sql = "SELECT naprawa_id FROM serwis_naprawa WHERE ((naprawa_status='0') or (naprawa_status='2')) and belongs_to='$es_filia'";
$result = mysql_query($sql, $conn) or die(mysql_error());
$naprawy_ilosc_serwis_wlasna = mysql_num_rows($result);

// ilosc naprawa w serwisie zewn.
$sql = "SELECT naprawa_id FROM serwis_naprawa WHERE naprawa_status='1' and belongs_to='$es_filia'";
$result = mysql_query($sql, $conn) or die(mysql_error());
$naprawy_ilosc_serwis_zewn = mysql_num_rows($result);

// ilosc naprawy wykonane
$sql = "SELECT naprawa_id FROM serwis_naprawa WHERE naprawa_status='3' and belongs_to='$es_filia'";
$result = mysql_query($sql, $conn) or die(mysql_error());
$naprawy_ilosc_naprawione = mysql_num_rows($result);

*/

// ilosc otwartych zg�osze� awarii
$sql = "SELECT awaria_id FROM serwis_awarie WHERE awaria_status='0' and belongs_to='$es_filia'";
$result = mysql_query($sql, $conn) or die(mysql_error());
$awarie_otwarte_ilosc = mysql_num_rows($result);

// Czynno�ci do wykonania
$username = $es_imie.' '.$es_nazwisko;
$accessLevels = array("9"); 
if(array_search($es_prawa, $accessLevels)>-1)
{
	$sql = "SELECT todo_id FROM serwis_komorka_todo WHERE belongs_to=$es_filia and todo_status=1";
} else 
{
	$sql = "SELECT todo_id FROM serwis_komorka_todo WHERE ((belongs_to=$es_filia) and (todo_status=1) and (todo_przypisane_osobie='$username') or (todo_przypisane_osobie=''))";
}

$result = mysql_query($sql, $conn) or die(mysql_error());
$czynnosci_do_wykonania_ilosc = mysql_num_rows($result);

// Czynno�ci do wykonania dla osoby
$username = $es_imie.' '.$es_nazwisko;
$accessLevels = array("9"); 
if(array_search($es_prawa, $accessLevels)>-1)
{
	$sql = "SELECT todo_id FROM serwis_komorka_todo WHERE belongs_to=$es_filia and todo_status=1";
} else 
{
	$sql = "SELECT todo_id FROM serwis_komorka_todo WHERE ((belongs_to=$es_filia) and (todo_status=1) and (todo_przypisane_osobie='$username'))";
}

$result = mysql_query($sql, $conn) or die(mysql_error());
$czynnosci_do_wykonania_osoba_ilosc = mysql_num_rows($result);

// Ilo�� otwartych zada�
$sql = "SELECT zadanie_id FROM serwis_zadania WHERE zadanie_status=1 and belongs_to='$es_filia'";
$result = mysql_query($sql, $conn) or die(mysql_error());
$zadania_otwarte_ilosc = mysql_num_rows($result);

if (($awarie_otwarte_ilosc>0) || ($czynnosci_do_wykonania_ilosc>0) || ($zadania_otwarte_ilosc>0)) 
{
echo "<br>";
echo "<h4>Informacje zbiorcze z bazy eSerwis</h4>";

echo "<div id=praport align=center>";

echo "<table cellspacing=1 class=titlebar_add align=center width=60%>";

/*
if ($magazyn_ilosc_cala>0) {

	echo "<tr class=titlebar_add_n><th colspan=2><center>Sprz�t serwisowy</center></th></tr>";

	if ($magazyn_ilosc_cala>0) {
	echo "<tr><td class=titlebar align=left>&nbsp;<a title=' Poka� ca�y sprz�t serwisowy ' class=blue_font href=main.php?action=cm>Ca�y sprz�t&nbsp;<img src=img/goto.gif border=0 align=bottom></a></td><td width=60 class=titlebar><center>$magazyn_ilosc_cala szt</center></td></tr>";
	}
	if ($magazyn_ilosc_dostepna>0) {
	echo "<tr><td class=titlebar align=left>&nbsp;<a title=' Poka� dost�pny sprz�t ' class=blue_font href=main.php?action=asm>Ilo�� sprz�tu dost�pnego&nbsp;<img src=img/goto.gif border=0 align=bottom></a></td><td class=titlebar><center>$magazyn_ilosc_dostepna szt</center></td></tr>";
	}
	if ($magazyn_ilosc_pobrana>0) {
	echo "<tr><td class=titlebar align=left>&nbsp;<a title=' Poka� sprz�t pobrany ' class=blue_font href=main.php?action=sw>Ilo�� sprz�tu pobranego&nbsp;<img src=img/goto.gif border=0 align=bottom></a></td><td class=titlebar><center>$magazyn_ilosc_pobrana szt</center></td></tr>";
	}
	if ($magazyn_ilosc_zarezerwowana>0) {
	echo "<tr><td class=titlebar align=left>&nbsp;<a title=' Poka� sprz�t zarezerwowany ' class=blue_font href=main.php?action=prs>Ilo�� sprz�tu zarezerwowanego&nbsp;<img src=img/goto.gif border=0 align=bottom></a></td><td class=titlebar><center>$magazyn_ilosc_zarezerwowana szt</center></td></tr>";
	}

	$accessLevels = array("1","9"); 
	if(array_search($es_prawa, $accessLevels)>-1)
	{ 
	if ($magazyn_ilosc_ukryta>0) {
		echo "<tr><td class=titlebar align=left>&nbsp;<a title=' Poka� ukryty sprz�t ' class=blue_font href=main.php?action=pus>Ilo�� sprz�tu ukrytego&nbsp;<img src=img/goto.gif border=0 align=bottom></a></td><td class=titlebar><center>$magazyn_ilosc_ukryta szt</center></td></tr>";
	}
	}
}

$naprawy_suma = $naprawy_ilosc_pobrana + $naprawy_ilosc_serwis_wlasna + $naprawy_ilosc_serwis_zewn + $naprawy_ilosc_naprawione;

if ($naprawy_suma>0) {

	echo "<tr class=titlebar_add_n><th colspan=2><center>Naprawy</center></th></tr>";
	
	if ($naprawy_ilosc_pobrana>0) {
		echo "<tr><td class=titlebar align=left>&nbsp;<a title=' Poka� uszkodzony sprz�t na stanie ' class=blue_font href=main.php?action=npus>Ilo�� sprz�tu oczekuj�cego na napraw�&nbsp;<img src=img/goto.gif border=0 align=bottom></a></td><td class=titlebar>"; 
		if ($naprawy_ilosc_pobrana>0)  echo "<b>";  
		echo "<center>$naprawy_ilosc_pobrana szt</center>"; 
		if ($naprawy_ilosc_pobrana>0) echo "</b>"; 
		echo "</td></tr>";
	}
	
	if ($naprawy_ilosc_serwis_wlasna>0) {
		echo "<tr><td class=titlebar align=left>&nbsp;<a title=' Poka� uszkodzony sprz�t b�d�cy w naprawie ' class=blue_font href=main.php?action=npswsz>Ilo�� sprz�tu naprawianego lokalnie lub we w�asnym zakresie&nbsp;<img src=img/goto.gif border=0 align=bottom></a></td><td class=titlebar><center>$naprawy_ilosc_serwis_wlasna szt</center></td></tr>";
	}
	
	if ($naprawy_ilosc_serwis_zewn>0) {
		echo "<tr><td class=titlebar align=left>&nbsp;<a title=' Poka� uszkodzony sprz�t b�d�cy w naprawie ' class=blue_font href=main.php?action=npswsz>Ilo�� sprz�tu naprawianego przez serwisy&nbsp;<img src=img/goto.gif border=0 align=bottom></a></td><td class=titlebar><center>$naprawy_ilosc_serwis_zewn szt</center></td></tr>";
	}
	
	if ($naprawy_ilosc_naprawione>0) {
		echo "<tr><td class=titlebar align=left>&nbsp;<a title=' Poka� sprz�t naprawiony ' class=blue_font href=main.php?action=npns>Ilo�� sprz�tu naprawionego&nbsp;<img src=img/goto.gif border=0 align=bottom></td><td class=titlebar>";
		if ($naprawy_ilosc_naprawione>0)  echo "<b>";  
		echo "<center>$naprawy_ilosc_naprawione szt</center>"; 
		if ($naprawy_ilosc_naprawione>0) echo "</b>";
		echo "</td></tr>";
	}
}

echo "<tr class=titlebar_add_n><th colspan=2><center>Magazyn towar�w/us�ug</center></th></tr>";
// ilo�ci poszczeg�lnych typ�w podzespo��w

$sql = "SELECT rola_nazwa FROM serwis_slownik_rola";
$result = mysql_query($sql, $conn) or die(mysql_error());
if (mysql_num_rows($result)!=0) {
$magazyn_suma=0;
	while ($dane = mysql_fetch_array($result)) {
		$rola = $dane['rola_nazwa'];
	
	
		$sql2 = "SELECT pozycja_id FROM serwis_faktura_szcz WHERE ((belongs_to='$es_filia') and (pozycja_status='0') and (pozycja_typ='$rola'))";
		$result2 = mysql_query($sql2, $conn) or die(mysql_error());
		$ilosc = mysql_num_rows($result2);
		
		if ($ilosc>0) {
			echo "<tr><td class=titlebar align=left>&nbsp;$rola</td><td class=titlebar><center>$ilosc szt</center></td></tr>";
			$magazyn_suma=$magazyn_suma+$ilosc;
		}
	}
	if ($magazyn_suma==0) {
		echo "<tr><td class=titlebar colspan=2>&nbsp;Brak towar�w/us�ug do odsprzeda�y</td></tr>";
	}
}

echo "<tr class=titlebar_add_n><th colspan=2><center>Ewidencja sprz�tu</center></th></tr>";
// ilo�ci poszczeg�lnych typ�w sprz�t�w

$sql = "SELECT rola_nazwa FROM serwis_slownik_rola WHERE rola_do_ewidencji=1";
$result = mysql_query($sql, $conn) or die(mysql_error());
if (mysql_num_rows($result)!=0) {
$ew_suma=0;
	while ($dane = mysql_fetch_array($result)) {
		$rola = $dane['rola_nazwa'];
		
		$sql2 = "SELECT ewidencja_id FROM serwis_ewidencja WHERE ((belongs_to='$es_filia') and (ewidencja_typ_nazwa='$rola'))";
		$result2 = mysql_query($sql2, $conn) or die(mysql_error());
		$ilosc = mysql_num_rows($result2);
		
		if ($ilosc>0) {
				echo "<tr><td class=titlebar align=left>&nbsp;<a title=' Poka� ca�y sprz�t w bazie typu $rola ' class=blue_font href=szukaj.php?skrot=1&gdzie=E&szukaj=$rola&submit=submit>$rola&nbsp;<img src=img/goto.gif border=0 align=bottom></a></td><td class=titlebar><center>$ilosc szt</center></td></tr>";
			$ew_suma=$ew_suma+$ilosc;
		}
	}
	if ($ew_suma==0) {
		echo "<tr><td class=titlebar colspan=2>&nbsp;Ewidencja sprz�tu jest pusta</td></tr>";
	}
}
*/

if ($awarie_otwarte_ilosc>0) {
	echo "<tr class=titlebar_add_n><th colspan=2><center>Awarie</center></th></tr>";
	echo "<tr><td class=titlebar align=left>&nbsp;<a title=' Ilo�� otwartych zg�osze� awarii ' class=blue_font href=z_awarie.php>Ilo�� otwartych zg�osze� awarii&nbsp;<img src=img/goto.gif border=0 align=bottom></td><td class=titlebar width=130>";
	if ($awarie_otwarte_ilosc>0)  echo "<b>";  
	echo "<center>$awarie_otwarte_ilosc</center>";
	if ($awarie_otwarte_ilosc>0)  echo "</b>";  
	echo "</td></tr>";
}

if ($czynnosci_do_wykonania_ilosc>0) {

if ($czynnosci_do_wykonania_osoba_ilosc>0) 
{
$username = $es_imie.' '.$es_nazwisko;
$accessLevels = array("9"); 
if(array_search($es_prawa, $accessLevels)>-1)
{
	echo "<tr class=titlebar_add_n><th colspan=2><center>Czynno�ci do wykonania w filii/oddziale</center></th></tr>";
} else
{
	echo "<tr class=titlebar_add_n><th colspan=2><center>$username : czynno�ci do wykonania</center></th></tr>";
}
$username = $es_imie.' '.$es_nazwisko;
$accessLevels = array("9"); 
if(array_search($es_prawa, $accessLevels)>-1)
{
	$sql = "SELECT DISTINCT todo_up_id FROM serwis_komorka_todo WHERE (todo_status=1) and (belongs_to=$es_filia)";
} else 
{
	$sql = "SELECT DISTINCT todo_up_id FROM serwis_komorka_todo WHERE ((todo_status=1) and (belongs_to=$es_filia) and (todo_przypisane_osobie='$username'))";
}

$result = mysql_query($sql, $conn) or die(mysql_error());
while ($dane1 = mysql_fetch_array($result)) {

	$temp_id = $dane1['todo_up_id'];
	$temp_termin = $dane1['todo_termin_koncowy'];

	$username = $es_imie.' '.$es_nazwisko;
	$accessLevels = array("9"); 
	if(array_search($es_prawa, $accessLevels)>-1)
	{
		$sql3 = "SELECT todo_up_id FROM serwis_komorka_todo WHERE (todo_status=1) and (belongs_to=$es_filia) and (todo_up_id=$temp_id)";
	} else 
	{
		$sql3 = "SELECT todo_up_id FROM serwis_komorka_todo WHERE ((todo_status=1) and (belongs_to=$es_filia) and (todo_przypisane_osobie='$username') and (todo_up_id=$temp_id))";
	}	

	$result3 = mysql_query($sql3, $conn) or die(mysql_error());
	$ilosc = mysql_num_rows($result3);
	
	$sql2 = "SELECT up_nazwa FROM serwis_komorki WHERE ((belongs_to='$es_filia') and (up_id='$temp_id')) LIMIT 1";
	$result2 = mysql_query($sql2, $conn) or die(mysql_error());
	
	$dane = mysql_fetch_array($result2);
	
	$up = $dane['up_nazwa'];
	
	if ($ilosc>0) {

		echo "<tr><td class=titlebar align=left>&nbsp;<a title=' Ilo�� czynno�ci do wykonania dla $up = $ilosc ' class=blue_font onclick=\"newWindow1(800,400,'p_komorka_czynnosc.php?id=$temp_id&filtruj=$username')\" href='#'>$up&nbsp;";
		echo "<img src=img/goto.gif border=0 align=bottom >";
	
	$dddd = date("Y-m-d H:i:s");
	$sql4 = "SELECT todo_id FROM serwis_komorka_todo WHERE ((belongs_to=$es_filia) and (todo_up_id=$temp_id) and (todo_status=1) and (todo_termin_koncowy<>'0000-00-00 00:00:00') and (todo_termin_koncowy<'$dddd'))";

	$result4 = mysql_query($sql4, $conn) or die(mysql_error());
	$ilosc_po_terminie = mysql_num_rows($result4);

	if ($ilosc_po_terminie>0) echo "&nbsp; ( dla $ilosc_po_terminie czynno�ci up�yn�� termin wykonania )";
	
	echo "</a>";
	echo "</td><td class=titlebar><center>$ilosc szt</center></td></tr>";
	}

//}
}
}
// === czynno�ci og�lne dla wszystkich

$username = $es_imie.' '.$es_nazwisko;
$accessLevels = array("0"); 
if(array_search($es_prawa, $accessLevels)>-1)
{

echo "<tr class=titlebar_add_n><th colspan=2><center>Czynno�ci do wykonania w filii/oddziale (nie przypisane do osoby)</center></th></tr>";

$sql = "SELECT DISTINCT todo_up_id FROM serwis_komorka_todo WHERE ((todo_status=1) and (belongs_to=$es_filia) and (todo_przypisane_osobie=''))";


$result = mysql_query($sql, $conn) or die(mysql_error());

while ($dane1 = mysql_fetch_array($result)) {

	$temp_id = $dane1['todo_up_id'];
	$temp_termin = $dane1['todo_termin_koncowy'];

	$username = $es_imie.' '.$es_nazwisko;
	$accessLevels = array("9"); 
	if(array_search($es_prawa, $accessLevels)>-1)
	{
		$sql3 = "SELECT todo_up_id FROM serwis_komorka_todo WHERE (todo_status=1) and (belongs_to=$es_filia) and (todo_up_id=$temp_id)";
	} else 
	{
		$sql3 = "SELECT todo_up_id FROM serwis_komorka_todo WHERE ((todo_status=1) and (belongs_to=$es_filia) and (todo_przypisane_osobie='') and (todo_up_id=$temp_id))";
	}

	$result3 = mysql_query($sql3, $conn) or die(mysql_error());
	$ilosc = mysql_num_rows($result3);
	
	$sql2 = "SELECT up_nazwa FROM serwis_komorki WHERE ((belongs_to='$es_filia') and (up_id='$temp_id')) LIMIT 1";
	$result2 = mysql_query($sql2, $conn) or die(mysql_error());
	
	$dane = mysql_fetch_array($result2);
	
	$up = $dane['up_nazwa'];
	
	if ($ilosc>0) {

		echo "<tr><td class=titlebar align=left>&nbsp;<a title=' Ilo�� czynno�ci do wykonania dla $up = $ilosc ' class=blue_font onclick=\"newWindow1(800,400,'p_komorka_czynnosc.php?id=$temp_id')\" href='#'>$up&nbsp;";
		echo "<img src=img/goto.gif border=0 align=bottom >";
	
	$dddd = date("Y-m-d H:i:s");
	$sql4 = "SELECT todo_id FROM serwis_komorka_todo WHERE ((belongs_to=$es_filia) and (todo_up_id=$temp_id) and (todo_status=1) and (todo_termin_koncowy<>'0000-00-00 00:00:00') and (todo_termin_koncowy<'$dddd'))";

	$result4 = mysql_query($sql4, $conn) or die(mysql_error());
	$ilosc_po_terminie = mysql_num_rows($result4);

	if ($ilosc_po_terminie>0) echo "&nbsp; ( dla $ilosc_po_terminie czynno�ci up�yn�� termin wykonania )";
	
	echo "</a>";
	echo "</td><td class=titlebar><center>$ilosc szt</center></td></tr>";
	}

//}
}
}

}

if ($zadania_otwarte_ilosc>0) {

$username = $es_imie.' '.$es_nazwisko;
$accessLevels = array("9"); 
if(array_search($es_prawa, $accessLevels)>-1)
{
	echo "<tr class=titlebar_add_n><th colspan=2><center>Zadania do wykonania w filii/oddziale</center></th></tr>";
} else
{
	echo "<tr class=titlebar_add_n><th colspan=2><center>$username : zadania do wykonania</center></th></tr>";
}

$sql = "SELECT * FROM serwis_zadania WHERE (zadanie_status=1)";

if ($es_m==1) $sql=$sql." and (belongs_to=$es_filia)";

$sql=$sql." ORDER BY zadanie_termin_zakonczenia ASC";

$result = mysql_query($sql, $conn) or die(mysql_error());

while ($dane1 = mysql_fetch_array($result)) {

	$temp_id 		= $dane1['zadanie_id'];
	$temp_opis	 	= $dane1['zadanie_opis'];
	$temp_termin	= $dane1['zadanie_termin_zakonczenia'];
	$temp_priorytet	= $dane1['zadanie_priorytet'];
	$temp_uwagi		= $dane1['zadanie_uwagi'];
	
	$termin = substr($temp_termin,0,10);
	$dzisiaj = Date("Y-m-d");
	
	echo "<tr><td class=titlebar align=left>&nbsp;<a title=' Poka� UP/kom�rki przypisane do zadania $temp_opis ' class=blue_font onclick=\"newWindow_r1(800,600,'p_zadanie_pozycje.php?id=$temp_id')\" href='#'>$temp_opis&nbsp;";
	echo "<img src=img/goto.gif border=0 align=bottom ></a>&nbsp;";
	
	$pozostalo_dni = round( abs(strtotime($dzisiaj)-strtotime($termin)) / 86400, 0 );
	
if ($termin!='0000-00-00') 
{
	if ($dzisiaj<$termin)
	{
		echo "<br>&nbsp;termin zako�czenia zadania up�ywa $termin (za $pozostalo_dni dni)";
	} else 
	{
		
		echo "<br>&nbsp;<font color=red><b>termin wykonania zadania up�yn�� $termin ($pozostalo_dni dni temu)</b></font>";
	}
} else echo "<br>&nbsp;brak okre�lonego terminu zako�czenia zadania";	
	echo "</td>";

	$sql1="SELECT * FROM serwis_zadania_pozycje WHERE (pozycja_zadanie_id=$temp_id)";
	$result1 = mysql_query($sql1, $conn) or die(mysql_error());
	$countall = mysql_num_rows($result1);
	
	$sql2="SELECT * FROM serwis_zadania_pozycje WHERE (pozycja_zadanie_id=$temp_id) and (pozycja_status=9)";
	$result2 = mysql_query($sql2, $conn) or die(mysql_error());
	$countwyk = mysql_num_rows($result2);

	if ($countall>0) { $procent_ = ($countwyk/$countall)*100; } else $procent_=0;
	$procent = round_up($procent_, 2);
	
	echo "<td width=130 class=titlebar align=center>&nbsp;wykonano : <b>$procent%</b></td>";

	
	echo "</tr>";
	
	
	
}

}

}

echo "</table>";
?>

</body>
</html>