<?php include_once('header_begin.php'); ?>

<?php include("js/mysqlbackup.h"); ?>

<script type="text/javascript">
<!--
var checkobj;

function check_all(value) 
{
  if (value=='Zaznacz') { value1=true; } else { value1=false; }
  
  document.backuprestore.backup1.checked=value1;
  document.backuprestore.backup2.checked=value1;
  document.backuprestore.backup3.checked=value1;
  document.backuprestore.backup4.checked=value1;
  document.backuprestore.backup5.checked=value1;
  
  if (value=='Zaznacz') { document.backuprestore.backup_allmodules.value='Odznacz'; } 
  	else
  		{ document.backuprestore.backup_allmodules.value='Zaznacz'; }
  
}

function check_all1(value) 
{
  if (value=='Zaznacz') { value1=true; } else { value1=false; }
  
  document.backuprestore.backup6.checked=value1;
  document.backuprestore.backup7.checked=value1;
  document.backuprestore.backup8.checked=value1;
  document.backuprestore.backup9.checked=value1;
  document.backuprestore.backup10.checked=value1;
  document.backuprestore.backup11.checked=value1;
  document.backuprestore.backup12.checked=value1;
  document.backuprestore.backup13.checked=value1;
  document.backuprestore.backup14.checked=value1;
  document.backuprestore.backup15.checked=value1;
  
  if (value=='Zaznacz') { document.backuprestore.backup_alltables.value='Odznacz'; } 
  	else
  		{ document.backuprestore.backup_alltables.value='Zaznacz'; }
  
}

</script>
</head>

<body>

<?php

if ($submitbackup) { 

echo "Rozpoczyna wykonywanie operacji : $typoperacji";

if ($backup1=="on") {
	echo "Magazyn";
	$backupfile = 'backup\serwis_'.date("Y-m-d-H-i-s").'.sql';
    mysqlbackup("localhost","serwis","root","postlodz",$backupfile, false);	

}
if ($backup2=="on") {
	echo "Naprawy";
}
if ($backup3=="on") {
	echo "Sprzeda�";
}
if ($backup4=="on") {
	echo "Ewidencja sprz�tu";
}
if ($backup5=="on") {
	echo "Awarie ��czy";
}
if ($backup6=="on") {
	echo "Pracownicy";
}
if ($backup7=="on") {
	echo "Urz�dy / Kom�rki";
}
if ($backup8=="on") {
	echo "Firmy serwisowe";
}
if ($backup9=="on") {
	echo "Firmy kurierskie";
}
if ($backup10=="on") {
	echo "Umowy";
}
if ($backup11=="on") {
	echo "Dostawcy";
}
if ($backup12=="on") {
	echo "Piony";
}
if ($backup13=="on") {
	echo "S�ownik oprogramowania";
}
if ($backup14=="on") {
	echo "S�ownik typu sprz�tu";
}
if ($backup15=="on") {
	echo "S�ownik konfiguracji komputer�w";
}




// backup/restore


} else { 

//wyb�r co mamy robi�

echo "<h4><center>Backup / Restore";
echo "</center></h4>";

echo "<form name=backuprestore action=$PHP_SELF method=POST target=_blank>";

echo "<p align=center>Typ opracji : ";

echo "<select name=typoperacji>";
echo "<option value='backup'>Backup</option>";
echo "<option value='restore'>Restore</option>";
echo "</select>";

echo "</p>";

echo "<table cellspacing=1 class=titlebar_add align=center width=400>";
echo "<tr class=titlebar_add_n>";
echo "<td align=center width=30>LP</td><td width=280>&nbsp;Nazwa modu�u</td>";
echo "<td align=center>Wybrane</td>"; 
echo "</tr>";

echo "<tr class=parzyste>";
	echo "<td align=center>1</td>";
	echo "<td>&nbsp;Magazyn</td>";
	echo "<td align=center>&nbsp;<input type=checkbox name=backup1></td>";
echo "</tr>";

echo "<tr class=parzyste>";
	echo "<td align=center>2</td>";
	echo "<td>&nbsp;Naprawy</td>";
	echo "<td align=center>&nbsp;<input type=checkbox name=backup2></td>";
echo "</tr>";

echo "<tr class=parzyste>";
	echo "<td align=center>3</td>";
	echo "<td>&nbsp;Sprzeda�</td>";
	echo "<td align=center>&nbsp;<input type=checkbox name=backup3></td>";
echo "</tr>";

echo "<tr class=parzyste>";
	echo "<td align=center>4</td>";
	echo "<td>&nbsp;Ewidencja sprz�tu</td>";
	echo "<td align=center>&nbsp;<input type=checkbox name=backup4></td>";
echo "</tr>";

echo "<tr class=parzyste>";
	echo "<td align=center>5</td>";
	echo "<td>&nbsp;Awarie ��czy</td>";
	echo "<td align=center>&nbsp;<input type=checkbox name=backup5></td>";
echo "</tr>";

echo "<tr class=parzyste>";
	echo "<td colspan=2 align=right><b>Wszystkie modu�y&nbsp;</b></td>";
	echo "<td align=center>&nbsp;<input class=buttons type=button name=backup_allmodules value='Zaznacz' onclick=check_all(this.value);></td>";
echo "</tr>";

echo "</table>";
echo "<br>";

echo "<table cellspacing=1 class=titlebar_add align=center width=400>";
echo "<tr class=titlebar_add_n>";
echo "<td align=center width=30>LP</td><td width=280>&nbsp;Nazwa tabeli</td>";
echo "<td align=center>Wybrane</td>"; 
echo "</tr>";

echo "<tr class=parzyste>";
	echo "<td align=center>1</td>";
	echo "<td>&nbsp;Pracownicy</td>";
	echo "<td align=center>&nbsp;<input type=checkbox name=backup6></td>";
echo "</tr>";

echo "<tr class=parzyste>";
	echo "<td align=center>2</td>";
	echo "<td>&nbsp;Urz�dy / Kom�rki</td>";
	echo "<td align=center>&nbsp;<input type=checkbox name=backup7></td>";
echo "</tr>";

echo "<tr class=parzyste>";
	echo "<td align=center>3</td>";
	echo "<td>&nbsp;Firmy serwisowe</td>";
	echo "<td align=center>&nbsp;<input type=checkbox name=backup8></td>";
echo "</tr>";

echo "<tr class=parzyste>";
	echo "<td align=center>4</td>";
	echo "<td>&nbsp;Firmy kurierskie</td>";
	echo "<td align=center>&nbsp;<input type=checkbox name=backup9></td>";
echo "</tr>";

echo "<tr class=parzyste>";
	echo "<td align=center>5</td>";
	echo "<td>&nbsp;Umowy</td>";
	echo "<td align=center>&nbsp;<input type=checkbox name=backup10></td>";
echo "</tr>";

echo "<tr class=parzyste>";
	echo "<td align=center>6</td>";
	echo "<td>&nbsp;Dostawcy</td>";
	echo "<td align=center>&nbsp;<input type=checkbox name=backup11></td>";
echo "</tr>";

echo "<tr class=parzyste>";
	echo "<td align=center>7</td>";
	echo "<td>&nbsp;Piony</td>";
	echo "<td align=center>&nbsp;<input type=checkbox name=backup12></td>";
echo "</tr>";

echo "<tr class=parzyste>";
	echo "<td align=center>8</td>";
	echo "<td>&nbsp;S�ownik oprogramowania</td>";
	echo "<td align=center>&nbsp;<input type=checkbox name=backup13></td>";
echo "</tr>";

echo "<tr class=parzyste>";
	echo "<td align=center>9</td>";
	echo "<td>&nbsp;S�ownik typu sprz�tu</td>";
	echo "<td align=center>&nbsp;<input type=checkbox name=backup14></td>";
echo "</tr>";

echo "<tr class=parzyste>";
	echo "<td align=center>10</td>";
	echo "<td>&nbsp;S�ownik konfiguracji komputer�w</td>";
	echo "<td align=center>&nbsp;<input type=checkbox name=backup15></td>";
echo "</tr>";

echo "<tr class=parzyste>";
	echo "<td colspan=2 align=right><b>Wszystkie tabele&nbsp;</b></td>";
	echo "<td align=center>&nbsp;<input class=buttons type=button name=backup_alltables value='Zaznacz' onclick=check_all1(this.value);></td>";
echo "</tr>";

echo "</table>";

echo "<p align=center><input class=buttons type=submit name=submitbackup value=Rozpocznij></center>";

echo "<br><p align=right><input class=startpage type=button onClick=\"window.location.href='$linkdostronyglownej'\" value='Wr�� do strony g��wnej'>&nbsp;&nbsp;&nbsp;&nbsp;</p>";

}


?>

</form>
</body>
</html>

</body>
</html>