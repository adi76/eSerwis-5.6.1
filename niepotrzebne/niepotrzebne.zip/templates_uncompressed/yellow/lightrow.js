//<![CDATA[
	var clicked = '';
	//var currentRowId = '';
	function rowOver(which, what) {
			//alert(which);
			var changed = document.getElementById(which);
			//alert(changed);
			if (which != clicked) {
					if (what == 1)
							changed.style.backgroundColor = '#FFB76F';	// kolor pod�wietlenia
					else{
							if(which%2)
									changed.style.backgroundColor = '#F3EBA1'; // nieparzyste
							else
									changed.style.backgroundColor = '#F8F3C6'; // parzyste
					}
			}
	}
	
	function resetRow(which) {
			var changed = document.getElementById(which);
			if(which%2)
					changed.style.backgroundColor = '#F3EBA1';	// nieparzyste
			else
					changed.style.backgroundColor = '#F8F3C6';	// parzyste
	
	}

	function changeSelect(which) {
			var changed = document.getElementById(which);
			changed.style.backgroundColor = '#FFD700';	// element wybrany
			changed.onMouseOver = '';
			changed.onMouseOut = '';
	
	}

	function selectRow(which) { //,rowIndex
			if (clicked != '') {
			//alert('1');
					resetRow(clicked);
					clicked = which;
					changeSelect(which);
			} else if (clicked == '') {
			//alert('2');
					clicked = which;
					changeSelect(which);
			}
					//currentRowId = rowIndex;
	
	}
	
	function deSelectRow(which) {
			resetRow(which);
			clicked = '';
	
	}
	
//]]>
