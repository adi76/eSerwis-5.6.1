//<![CDATA[
	var clicked = '';
	//var currentRowId = '';
	function rowOver(which, what) {
			//alert(which);
			var changed = document.getElementById(which);
			//alert(changed);
			if (which != clicked) {
					if (what == 1)
							changed.style.backgroundColor = '#90EE90';	// kolor pod�wietlenia
					else{
							if(which%2)
									changed.style.backgroundColor = '#CAE98B'; // nieparzyste
							else
									changed.style.backgroundColor = '#D4EAA8'; // parzyste
					}
			}
	}
	
	function resetRow(which) {
			var changed = document.getElementById(which);
			if(which%2)
					changed.style.backgroundColor = '#CAE98B';	// nieparzyste
			else
					changed.style.backgroundColor = '#D4EAA8';	// parzyste
	
	}

	function changeSelect(which) {
			var changed = document.getElementById(which);
			changed.style.backgroundColor = '#24AC25';	// element wybrany
			changed.onMouseOver = '';
			changed.onMouseOut = '';
	
	}

	function selectRow(which) { //,rowIndex
			if (clicked != '') {
			//alert('1');
					resetRow(clicked);
					clicked = which;
					changeSelect(which);
			} else if (clicked == '') {
			//alert('2');
					clicked = which;
					changeSelect(which);
			}
					//currentRowId = rowIndex;
	
	}
	
	function deSelectRow(which) {
			resetRow(which);
			clicked = '';
	
	}
	
//]]>
