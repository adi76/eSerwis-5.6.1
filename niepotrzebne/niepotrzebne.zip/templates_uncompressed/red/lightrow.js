//<![CDATA[
	var clicked = '';
	//var currentRowId = '';
	function rowOver(which, what) {
			//alert(which);
			var changed = document.getElementById(which);
			//alert(changed);
			if (which != clicked) {
					if (what == 1)
							changed.style.backgroundColor = '#F2CF64';	// kolor pod�wietlenia
					else{
							if(which%2)
									changed.style.backgroundColor = '#D4835C'; // nieparzyste
							else
									changed.style.backgroundColor = '#D99A7B'; // parzyste
					}
			}
	}
	
	function resetRow(which) {
			var changed = document.getElementById(which);
			if(which%2)
					changed.style.backgroundColor = '#D4835C';	// nieparzyste
			else
					changed.style.backgroundColor = '#D99A7B';	// parzyste
	
	}

	function changeSelect(which) {
			var changed = document.getElementById(which);
			changed.style.backgroundColor = '#F1C02E';	// element wybrany
			changed.onMouseOver = '';
			changed.onMouseOut = '';
	
	}

	function selectRow(which) { //,rowIndex
			if (clicked != '') {
			//alert('1');
					resetRow(clicked);
					clicked = which;
					changeSelect(which);
			} else if (clicked == '') {
			//alert('2');
					clicked = which;
					changeSelect(which);
			}
					//currentRowId = rowIndex;
	
	}
	
	function deSelectRow(which) {
			resetRow(which);
			clicked = '';
	
	}
	
//]]>
