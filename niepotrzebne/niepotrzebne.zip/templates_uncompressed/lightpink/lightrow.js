//<![CDATA[
	var clicked = '';
	//var currentRowId = '';
	function rowOver(which, what) {
			//alert(which);
			var changed = document.getElementById(which);
			//alert(changed);
			if (which != clicked) {
					if (what == 1)
							changed.style.backgroundColor = '#FFBD7B';	// kolor pod�wietlenia
					else{
							if(which%2)
									changed.style.backgroundColor = '#FFCF9F'; // nieparzyste
							else
									changed.style.backgroundColor = '#FFE7CE'; // parzyste
					}
			}
	}
	
	function resetRow(which) {
			var changed = document.getElementById(which);
			if(which%2)
					changed.style.backgroundColor = '#FFCF9F';	// nieparzyste
			else
					changed.style.backgroundColor = '#FFE7CE';	// parzyste
	
	}

	function changeSelect(which) {
			var changed = document.getElementById(which);
			changed.style.backgroundColor = '#FF8D1A';	// element wybrany
			changed.onMouseOver = '';
			changed.onMouseOut = '';
	
	}

	function selectRow(which) { //,rowIndex
			if (clicked != '') {
			//alert('1');
					resetRow(clicked);
					clicked = which;
					changeSelect(which);
			} else if (clicked == '') {
			//alert('2');
					clicked = which;
					changeSelect(which);
			}
					//currentRowId = rowIndex;
	
	}
	
	function deSelectRow(which) {
			resetRow(which);
			clicked = '';
	
	}
	
//]]>
