<?php include_once('header.php'); ?>

<?php

	$sql = "SELECT * FROM serwis_ewidencja WHERE (ewidencja_typ_nazwa<>'Drukarka') and (ewidencja_drukarka_opis<>'')";
    $result = mysql_query($sql, $conn) or die(mysql_error());
	while ($dane = mysql_fetch_array($result)) {

								  $eid 		= $dane['ewidencja_id'];
								  $etyp_id	= $dane['ewidencja_typ'];
								  $etyp_n	= $dane['ewidencja_typ_nazwa'];
								  $eup_id	= $dane['ewidencja_up_id'];
								  $euser	= $dane['ewidencja_uzytkownik'];									  
								  $enrpok	= $dane['ewidencja_nr_pokoju'];
								  $enizest	= $dane['ewidencja_zestaw_ni'];
								  $eknazwa	= $dane['ewidencja_komputer_nazwa'];
								  $ekopis	= $dane['ewidencja_komputer_opis'];
								  $eksn		= $dane['ewidencja_komputer_sn'];
								  $ekip		= $dane['ewidencja_komputer_ip'];
								  $eke		= $dane['ewidencja_komputer_endpoint'];
								  $emo		= $dane['ewidencja_monitor_opis'];
								  $emsn		= $dane['ewidencja_monitor_sn'];
								  $edo		= $dane['ewidencja_drukarka_opis'];
								  $edsn		= $dane['ewidencja_drukarka_sn'];
								  $edni		= $dane['ewidencja_drukarka_ni'];
								  $eu		= $dane['ewidencja_uwagi'];
								  $es		= $dane['ewidencja_status'];
								  $eo_id	= $dane['ewidencja_oprogramowanie'];
								  $emoduser = $dane['ewidencja_modyfikacja_user'];
								  $emoddata	= $dane['ewidencja_modyfikacja_date'];
								  $ekonf	= $dane['ewidencja_konfiguracja'];
								  $ebt		= $dane['belongs_to'];
								  
								  $k__procesor 	= $dane['k_procesor'];
								  $k__pamiec	= $dane['k_pamiec'];
								  $k__dysk		= $dane['k_dysk'];
								  $egwarancja= $dane['ewidencja_gwarancja_do'];		
								  
								  $egwarancjakto= $dane['ewidencja_gwarancja_kto'];		
								  $drukarkapow	= $dane['ewidencja_drukarka_powiaz_z'];
		
	$sql55="SELECT up_nazwa FROM serwis_komorki WHERE (up_id=$eup_id)";
	$result55 = mysql_query($sql55, $conn) or die(mysql_error());
		
	while ($newArray55 = mysql_fetch_array($result55)) 
	{
		$lok_up_nazwa				= $newArray55['up_nazwa'];		
	}
	
	
		echo "$eid | $etyp_n | $eup_id | $lok_up_nazwa | $euser | $enrpok | $edo | $edsn | $edni | $drukarkapow&nbsp;-";

	$sql_up = "UPDATE serwis_ewidencja SET ewidencja_drukarka_opis='',ewidencja_drukarka_sn='', ewidencja_drukarka_ni='',ewidencja_drukarka_powiaz_z='0', ewidencja_modyfikacja_user='Maciej Adrjanowicz' WHERE (ewidencja_id=$eid)";
	if (mysql_query($sql_up, $conn)) {
		echo "<font class=blue_font>";
		echo "OK";
		echo "</font>";
		echo "&nbsp";
	} else 
		{
			echo "<font class=red_font>";
			echo "ERROR";
			echo "</font>";
			echo "&nbsp";		
		}
	
	$sql_add = "INSERT INTO serwis_ewidencja values ('', 3,'Drukarka',$eup_id,'$lok_up_nazwa','','$enrpok','','','','','','','','','$edo','$edsn','$edni','',$ebt,1,0,'2007-11-08 18:00:00','Maciej Adrjanowicz','','','','','',0,$eid)";
	
	if (mysql_query($sql_add, $conn)) {
		echo "<font class=blue_font>";
		echo "OK";
		echo "</font>";
		echo "&nbsp";
	} else 
		{
			echo "<font class=red_font>";
			echo "ERROR";
			echo "</font>";
			echo "&nbsp";		
		}

	echo "<br>";
	
	}

?>
