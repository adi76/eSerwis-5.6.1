<?php include_once('header_begin.php'); ?>

	<SCRIPT>

	function validateForm() {
		if (document.ruch.search1.value=="") { alert('Nie wpisano �adnego znaku'); document.ruch.search1.focus(); return false; }		
	}
	
	</SCRIPT>
</head>
<body>

<?php 
if ($submit) { 
$search=$_GET[search1];

$sql_a = "SELECT * FROM serwis_magazyn WHERE belongs_to='$es_filia' and (
	magazyn_nazwa LIKE '%$search%' or 
	magazyn_model LIKE '%$search%' or 
	magazyn_sn LIKE '%$search%' or 
	magazyn_ni LIKE '%$search%')";
	
$result_a = mysql_query($sql_a, $conn) or die(mysql_error());
$count_rows=0;
echo "$count_rows";

while ($dane3 = mysql_fetch_array($result_a)) 
	{
		$count_rows+=1;
	}

if ($count_rows==0) {

  echo "<h2><center>Nie znaleziono pozycji spe�niaj�cych podane przez Ciebie kryteria</center></h2>";
echo "<p align=right>";
echo "<input class=buttons type=button onClick=\"window.history.go(-1);\" value='Nowe szukanie'>&nbsp;";
echo "<input class=startpage type=button onClick=\"window.location.href='$linkdostronyglownej'\" value='Wr�� do strony g��wnej'>&nbsp;&nbsp;&nbsp;&nbsp;</p>";	  
  
} else {							

	echo "<h4><center>Wyniki wyszukiwania ci�gu znak�w<font class=blue_font></h4><h5>$search</font>";
	
	echo "</center></h5>";

echo "<table cellspacing=1 align=center class=titlebar_add width=98%>";

echo "<tr class=titlebar_add_n>";
echo "<td><center>LP</center></td>";
echo "<td>&nbsp;Nazwa</td>";
echo "<td>&nbsp;Model</td>";
echo "<td>&nbsp;Numer seryjny</td>";
echo "<td>&nbsp;Numer inwentarzowy</td>";
echo "<td><center>Uwagi</center></td>";
echo "<td aling=center><center>Status</center></td>";
//echo "<td>Opcje</td>";

echo "</tr>";

$sql_a = "SELECT * FROM serwis_magazyn WHERE belongs_to='$es_filia' and (
magazyn_nazwa LIKE '%$search%' or 
magazyn_model LIKE '%$search%' or 
magazyn_sn LIKE '%$search%' or 
magazyn_ni LIKE '%$search%')";


$result_a = mysql_query($sql_a, $conn) or die(mysql_error());

$i=0;

while ($dane3 = mysql_fetch_array($result_a)) {		
	
	
  $mid 		= $dane3['magazyn_id'];
  $mnazwa 	= $dane3['magazyn_nazwa'];
  $mmodel	= $dane3['magazyn_model'];
  $msn	 	= $dane3['magazyn_sn'];
  $mni		= $dane3['magazyn_ni'];
  $muwagi	= $dane3['magazyn_uwagi_sa'];
  $mstatus	= $dane3['magazyn_status'];
  
    
 	if ($i % 2 != 0 ) echo "<tr id=$i class=nieparzyste onmouseover=rowOver('$i',1); this.style.cursor=arrow onmouseout=rowOver('$i',0) onclick=selectRow('$i') ondblclick=deSelectRow('$i')>";
	if ($i % 2 == 0 ) echo "<tr id=$i class=parzyste onmouseover=rowOver('$i',1); this.style.cursor=arrow onmouseout=rowOver('$i',0) onclick=selectRow('$i') ondblclick=deSelectRow('$i')>";

$i+=1;

echo "<td width=20 align=center>$i</td>";						

echo "<td>&nbsp;$mnazwa</td>";
echo "<td>&nbsp;$mmodel</td>";
echo "<td>&nbsp;$msn</td>";
echo "<td>&nbsp;$mni</td>";

if ($muwagi=='1') {
  echo "<td width=40 align=center><input type=image src=img/comment.gif title=' Czytaj uwagi ' onclick=\"newWindow(450,360,'p_magazyn_uwagi.php?id=$mid')\">&nbsp;<input type=image src=img/edit_comment.gif title=' Edytuj uwagi ' onclick=\"newWindow(480,270,'e_magazyn_p_magazyn_uwagi.php?id=$mid')\"></td>";
} else echo "<td>&nbsp;</td>";

if ($mstatus=='0') echo "<td width=90 align=center><a class=opt_g>na stanie</a></td>";
if ($mstatus=='1') echo "<td width=90 align=center><a class=opt_r>pobrano</a></td>";
if ($mstatus=='2') echo "<td width=90 align=center><a class=opt_b>rezerwacja</a></td>";
if ($mstatus=='3') echo "<td width=90 align=center><a class=opt_w>ukryty</a></td>";
	}
echo "</tr></table>";

echo "<p align=right>";
echo "<input class=buttons type=button onClick=\"window.history.go(-1);\" value='Wybierz inny sprz�t'>&nbsp;";
echo "<input class=startpage type=button onClick=\"window.location.href='$linkdostronyglownej'\" value='Wr�� do strony g��wnej'>&nbsp;&nbsp;&nbsp;&nbsp;</p>";

}

} else { ?>

<?php

	echo "<br><h4><center>Szukaj sprz�tu na magazynie</center></h4><br>";
	echo "<form name=ruch action=ms.php method=GET onsubmit='return validateForm();'>";
	
	echo "<table cellspacing=1 align=center class=titlebar_add width=200";
	echo "<tr class=titlebar_add><td>&nbsp;</td></tr>";

	echo "<tr class=titlebar_add>";
	echo "<td align=center colspan=2>";
	echo "<b>Znajd� ci�g znak�w<br><br></b>";
	echo "</td>";
	echo "</tr>";
	
	echo "<tr class=titlebar_add>";
	echo "<td colspan=2 align=center>&nbsp;<input class=wymagane size=30 type=text name=search1>&nbsp;</td>";
	echo "</tr>";		
	
	
	echo "<tr class=titlebar_add>";
	echo "<td align=center colspan=2>";
    echo "<br><input class=buttons type=submit name=submit value='Szukaj'><br>&nbsp;<br></td>";
	echo "</tr>";	
	
	
	echo "</table>";
	echo "</form>";	
?>
<?php } ?>
</body>
</html>