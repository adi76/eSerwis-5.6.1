<?php include_once('header.php'); ?>
<body>
<?php include_once('body_start.php'); ?>
<?php

$sql="SELECT * FROM serwis_zadania WHERE (";

if ($es_m!=1) {
	$sql=$sql."(belongs_to='$es_filia') and ";
}

if ($s=='nowe') 	{ $sql=$sql."(zadanie_status=-1)) ORDER BY zadanie_data_utworzenia DESC"; }
if ($s=='otwarte')	{ $sql=$sql."(zadanie_status=1) or (zadanie_status=0)) ORDER BY zadanie_data_utworzenia DESC"; }
if ($s=='zakonczone') { $sql=$sql."(zadanie_status=9)) ORDER BY zadanie_data_utworzenia DESC"; }
 
$result = mysql_query($sql, $conn) or die(mysql_error());
$count_rows = mysql_num_rows($result);

// paging
// ============================================================================================================
$totalrows = mysql_num_rows($result);
if(empty($page)){ $page = 1; }

if ($showall==0) {
  $rps=$rowpersite;
} else $rps=10000;

$limitvalue = $page * $rps - ($rps);
$sql=$sql." LIMIT $limitvalue, $rps";
$result = mysql_query($sql, $conn) or die(mysql_error());
// ============================================================================================================
// koniec - paging

if ($count_rows!=0) {

if ($s=='nowe') 	{ echo "<h4>Przegl�danie przygotowywanych zada�</h4>"; }
if ($s=='otwarte')	{ echo "<h4>Przegl�danie zada� do wykonania</h4>"; }
if ($s=='zakonczone')	{ echo "<h4>Przegl�danie zako�czonych zada�</h4>"; }

echo "<div align=center>";

if ($showall==0) {
echo "<a class=nav_normal href=z_zadania_nowe.php?showall=1&paget=$page>Poka� wszystko na jednej stronie</a>";
} else {
echo "<a class=nav_normal href=z_zadania_nowe.php?showall=0&page=$paget>Dziel na strony</a>";	
}

echo "</div>";
echo "<table cellspacing=1 class=titlebar_add align=center width=98%>";
echo "<tr class=titlebar_add_n>";
echo "<th width=30><center>LP</center></th><th>&nbsp;Opis zadania&nbsp;<br>&nbsp;Ilo�� UP/kom�rek kt�rym zadanie zosta�o przypisane&nbsp;</th><th width=120>&nbsp;Data utworzenia&nbsp;<br>&nbsp;Utworzone przez</th><th width=120>&nbsp;Termin zako�czenia&nbsp;</th>";

if ($s!='zakonczone')
{
	echo "<th width=120><center>&nbsp;Status&nbsp;</center></th>";
} else
	{
		echo "<th width=120>&nbsp;Data zamkni�cia&nbsp;<br>&nbsp;Zamkni�te przez&nbsp;</th>";
	}
	
echo "<th ><center>Uwagi</center></th><th><center>&nbsp;Opcje&nbsp;</center></th>";

echo "</tr>";

$i = 0;
$j = $page*$rowpersite-$rowpersite+1;
	
while ($newArray = mysql_fetch_array($result)) {
	$temp_id  			= $newArray['zadanie_id'];
	$temp_opis			= $newArray['zadanie_opis'];
	$temp_termin_zak	= $newArray['zadanie_termin_zakonczenia'];
	$temp_data_zak		= $newArray['zadanie_data_zakonczenia'];
	$temp_osoba_zak		= $newArray['zadanie_zakonczone_przez'];
	$temp_status		= $newArray['zadanie_status'];
	$temp_data_utw		= $newArray['zadanie_data_utworzenia'];
	$temp_osoba_utw		= $newArray['zadanie_utworzone_przez'];
	$temp_priorytet		= $newArray['zadanie_priorytet'];
	$temp_uwagi			= $newArray['zadanie_uwagi'];
	
 	if ($i % 2 != 0 ) echo "<tr id=$i class=nieparzyste onmouseover=rowOver('$i',1); this.style.cursor=arrow onmouseout=rowOver('$i',0) onclick=selectRow('$i') ondblclick=deSelectRow('$i')>";
	if ($i % 2 == 0 ) echo "<tr id=$i class=parzyste onmouseover=rowOver('$i',1); this.style.cursor=arrow onmouseout=rowOver('$i',0) onclick=selectRow('$i') ondblclick=deSelectRow('$i')>";	
	
// wyliczenie ilo�ci pozycji pod danym zadaniem

	$sql1="SELECT * FROM serwis_zadania_pozycje WHERE (pozycja_zadanie_id=$temp_id)";

	$result1 = mysql_query($sql1, $conn) or die(mysql_error());
	$countall = mysql_num_rows($result1);
	
	$sql2="SELECT * FROM serwis_zadania_pozycje WHERE (pozycja_zadanie_id=$temp_id) and (pozycja_status=9)";
	
	$result2 = mysql_query($sql2, $conn) or die(mysql_error());
	$countwyk = mysql_num_rows($result2);

	if ($countall>0) { $procent_ = ($countwyk/$countall)*100; } else $procent_=0;
	$procent = round_up($procent_, 2);
	
// koniec wyliczenia ilo�ci pozycji pod danym zadaniem	
	
	echo "<td width=30 align=center>$j</td>";
	echo "<td>&nbsp;$temp_opis&nbsp;<br>&nbsp;$countall</td>";
	
	if ($temp_data_utw=='0000-00-00 00:00:00') $temp_data_utw='&nbsp;';
	if ($temp_termin_zak=='0000-00-00 00:00:00') $temp_termin_zak='nieokre�lony';

	if ($temp_osoba_zak=='') $temp_osoba_zak='&nbsp;';
	
	echo "<td>&nbsp;$temp_data_utw&nbsp;<br>&nbsp;$temp_osoba_utw&nbsp;</td>";

	if ($temp_termin_zak!='nieokre�lony') { $termin = substr($temp_termin_zak,0,10); } else $termin=$temp_termin_zak;
	echo "<td><center>&nbsp;<b>$termin</b>&nbsp;</center></td>";

if ($s!='zakonczone')
{	
	if ($temp_status==-1) 	$status='w przygotowaniu';
	if ($temp_status==0) 	{ $status='nowe'; }
	if ($temp_status==1)
	{
		$status='wykonywane'; 
	}
	if ($temp_status==9) 	{ $status='zako�czone'; }
	
	echo "<td><center>&nbsp;<b>$status</b>&nbsp;<br>";
	if ($temp_status==1) {
		echo "($countwyk/$countall) <b>$procent%</b>";
	}
	echo "</center></td>";
} else
	{
		echo "<td>&nbsp;$temp_data_zak&nbsp;<br>&nbsp;$temp_osoba_zak&nbsp;</td>";
	}
	
	$j+=1;
	echo "<td width=50 align=center>";
	if ($temp_uwagi!='') {
	echo "<a title=' Czytaj uwagi '><input type=image src=img/comment.gif onclick=\"newWindow(480,265,'p_zadania_uwagi.php?id=$temp_id&nr=$temp_numer')\"></a>&nbsp;<a title=' Edytuj uwagi '><input type=image src=img/edit_comment.gif onclick=\"newWindow(480,255,'e_zadania_uwagi.php?id=$temp_id')\"></a>";
	} else echo "<a title=' Dodaj uwagi '><input type=image src=img/add_comment.gif onclick=\"newWindow(480,255,'e_zadania_uwagi.php?id=$temp_id')\"></a>";

	echo "</td>";
	
	echo "</center></td>";
	
	echo "<td width=110 align=center>&nbsp;";
	
	if (($countall>0) && ($temp_status==-1)) 
	{
		echo "<a title=' Zmie� status zadania $temp_opis na OTWARTE '><input type=image src=img/ok.gif onclick=\"newWindow(400,115,'z_zadanie_status.php?id=$temp_id&s=1')\"></a>&nbsp;";	
	}

	if (($countall==$countwyk) && ($temp_status!=9) && ($countall!=0))
	{
	
		$sql1="SELECT filia_leader FROM serwis_filie WHERE filia_id=$es_filia";
		$result1 = mysql_query($sql1, $conn) or die(mysql_error());
		$newArray1 = mysql_fetch_array($result1);
		$kierownik = ($newArray1['filia_leader']==$es_nr);
		
		$imieinazwisko = $es_imie . ' ' . $es_nazwisko;
	
		if (($kierownik) || ($temp_osoba_utw==$imieinazwisko)) {
			echo "<a title=' Zmie� status zadania $temp_opis na ZAKO�CZONE '><input type=image src=img/ok.gif onclick=\"newWindow(400,115,'z_zadanie_status.php?id=$temp_id&s=9')\"></a>&nbsp;";	
		}
	}
	
	if ($temp_status==-1)
	{
		echo "<a title=' Popraw zadanie : $temp_opis '><input type=image src=img/edit.gif onclick=\"newWindow(600,275,'e_zadanie.php?id=$temp_id')\"></a>&nbsp;";	
	
	echo "<a title=' Usu� zadanie $temp_opis '><input type=image src=img/delete.gif 
onclick=\"newWindow(400,115,'u_zadanie.php?id=$temp_id')\"></a>";

	echo "&nbsp;&nbsp;";
	
	echo "<a title=' Dodaj kom�rki/UP do zadania $temp_opis '><input type=image src=img/add_pos.gif onclick=\"newWindow_r(800,600,'d_zadanie_pozycje.php?id=$temp_id')\"></a>&nbsp;";

	}

	if ($countall>0)
	{
		echo "<a title=' Poka� kom�rki/UP przypisane do zadania $temp_opis '><input type=image src=img/search.gif  onclick=\"newWindow_r1(800,600,'p_zadanie_pozycje.php?id=$temp_id')\"></a>&nbsp;";
	}
	
	echo "</td>";
	$i+=1;
}

echo "</table>";

// paging_end
include_once('paging_end.php');
// paging_end

echo "<div class=showr>";

if ($s=='nowe') 
{
	echo "<input type=button class=buttons href=# onclick=\"newWindow(600,275,'d_zadanie.php')\" value='Dodaj nowe zadanie'>";
}

echo "<input class=startpage type=button onClick=\"window.location.href='$linkdostronyglownej'\" value='Wr�� do strony g��wnej'></div>";

} else {
	echo "<h2>Brak otwartych zada� w bazie</h2>";
	echo "<div clas=showr>";
	if ($s=='nowe') 
	{	
		echo "<input type=button class=buttons href=# onclick=\"newWindow(600,275,'d_zadanie.php')\" value='Dodaj nowe zadanie'>";	
	}
	echo "<input class=startpage type=button onClick=\"window.location.href='$linkdostronyglownej'\" value='Wr�� do strony g��wnej'></div>";
}

?>
<?php include('body_stop.php'); ?>
</body>
</html>