<?php include_once('header.php'); ?>

<body>

<?php 
if (($type) && ($id)) {

if ($type=='p') { $sql1 = "SELECT przesuniecie_uwagi FROM serwis_ewidencja_przesuniecia WHERE przesuniecie_id='$id'"; }
if ($type=='r') { $sql1 = "SELECT remont_uwagi FROM serwis_ewidencja_remonty WHERE remont_id='$id'"; }
if ($type=='u') { $sql1 = "SELECT usuniecie_uwagi FROM serwis_ewidencja_usuniecia WHERE usuniecie_id='$id'"; }

$result1 = mysql_query($sql1, $conn) or die(mysql_error());

if (mysql_num_rows($result1)!=0) {
   
   $dane = mysql_fetch_array($result1);
 
if ($type=='p') { $uwagi = $dane['przesuniecie_uwagi']; }
if ($type=='r') { $uwagi = $dane['remont_uwagi']; }
if ($type=='u') { $uwagi = $dane['usuniecie_uwagi']; }
   
    echo "<h4><center>Uwagi</center></h4>";
	echo "<table cellspacing=1 align=center width=95%>";
	echo "<tr><td><font size=2>$uwagi</td></tr></table>";
   
} else echo "brak";

	echo "<br><br><p align=right><input class=buttons type=button onClick=window.close() value='Zamknij'>&nbsp;&nbsp;&nbsp;&nbsp;</p>";

}

?>

</body>
</html>