<?php include_once('header.php'); ?>
<body>
<?php 
	
$sql = "SELECT * FROM serwis_ewidencja";
$result = mysql_query($sql, $conn) or die(mysql_error());

while ($dane = mysql_fetch_array($result)) {

	$eid = $dane['ewidencja_id'];
	$etyp_id	= $dane['ewidencja_typ'];
	$eup_id= $dane['ewidencja_up_id'];
	$euser= $dane['ewidencja_uzytkownik'];
	$enrpok= $dane['ewidencja_nr_pokoju'];
	$enizest	= $dane['ewidencja_zestaw_ni'];
	$eknazwa	= $dane['ewidencja_komputer_nazwa'];
	$ekopis= $dane['ewidencja_komputer_opis'];
	$eksn= $dane['ewidencja_komputer_sn'];
	$ekip= $dane['ewidencja_komputer_ip'];
	$eke= $dane['ewidencja_komputer_endpoint'];
	$emo= $dane['ewidencja_monitor_opis'];
	$emsn= $dane['ewidencja_monitor_sn'];
	$edo= $dane['ewidencja_drukarka_opis'];
	$edsn= $dane['ewidencja_drukarka_sn'];
	$edni= $dane['ewidencja_drukarka_ni'];
	$eu	= $dane['ewidencja_uwagi'];
	$es	= $dane['ewidencja_status'];
	$eo_id= $dane['ewidencja_oprogramowanie'];
	$emoduser 	= $dane['ewidencja_modyfikacja_user'];
	$emoddata	= $dane['ewidencja_modyfikacja_date'];
	


$sql44="SELECT * FROM serwis_slownik_rola WHERE (rola_id=$etyp_id)";
$result44 = mysql_query($sql44, $conn) or die(mysql_error());

while ($newArray44 = mysql_fetch_array($result44)) 
 {
	$rola_typ_nazwa= $newArray44['rola_nazwa'];
}


$sql55="SELECT * FROM serwis_komorki WHERE (up_id=$eup_id)";
$result55 = mysql_query($sql55, $conn) or die(mysql_error());

while ($newArray55 = mysql_fetch_array($result55)) 
 {
	$lok_up_nazwa= $newArray55['up_nazwa'];
}

$sql_t = "UPDATE serwis_ewidencja SET ewidencja_typ_nazwa='$rola_typ_nazwa',  ewidencja_up_nazwa='$lok_up_nazwa' WHERE (ewidencja_id='$eid')";

mysql_query($sql_t, $conn);
	
	}


	?><script> info('Pomy�lnie zapisano zmiany do bazy'); opener.location.reload(true); self.close(); </script>
	
</body>
</html>