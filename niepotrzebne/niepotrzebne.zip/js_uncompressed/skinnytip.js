/////////////////////////////////////////////////////////////////////
//SkinnyTip 1.0 - Elliott Brueggeman - Mar 2, 2007
//JavaScript Popup Tooltip Library 
//Project Homepage: http://www.ebrueggeman.com/skinnytip
//Documentation available on project homepage
////////////////////////////////////////////////////////////////////
//Rights: Free for personal use and corporate use if sites
//include link to project homepage on all pages (including dynamic content)
//that use the SkinnyTip tooltips library
//////////////////////////////////////////////////////////////////////


//Call mouse capture handler function on page load
captureMouse();

//CUSTOM VARS - Initialized below
var v_divname;
var v_text;
var v_title;
var v_xoffset;
var v_yoffset;
var v_backcolor;
var v_bordercolor;
var v_textcolor;
var v_titletextcolor;
var v_width;
var v_border;
var v_cellpad;
var v_textfont;
var v_textsize;
var v_titletextsize;

//SYSTEM VARIABLES
var v_xcoordinate = 0;
var v_ycoordinate = 0;
var v_visible = 0;
var v_havemouse=0;
var v_layer = null;

function tooltip(displaytext, title, commands)
{
	//Reset variables for this tool tip
	init();
	
	//Title and Text
	v_title=title;
	v_text=displaytext;
	
	//Parse commands if any
	parseCommands(commands);
	
	
	if (v_layer)
	{ 
		v_layer=getLayer(v_divname); 
	}
	
	if(!(v_layer=createDivContainer()))
	{ 
		return false;
	}

	mainMethod();
}

function init()
{
	
	v_divname='tiplayer';
	v_text="podpowied�";
	v_title="Pomoc";
	
	//UI Variables
	v_xoffset=15;
	v_yoffset=15;
	v_backcolor="#A7ACBA";
	v_bordercolor="#A7ACBA";
	v_textcolor="#000000";
	v_titletextcolor="#A7ACBA";
	v_width=300;
	v_border=2;
	v_cellpad=1;
	v_textfont="Verdana,Arial,Helvetica";
	v_textsize=1;
	v_titletextsize=1;
	
	//SYSTEM VARIABLES
	v_visible = 0;
	// LAYER
	v_layer = null;
}

function parseCommands(commands)
{
	if(commands!=null) 
	{
		var comArray = commands.split(',');
		for (var i = 0; i< comArray.length; i++)
		{
			args=comArray[i].split(':');
			eval('v_'+args[0]+'="'+args[1]+'"');
		}
	}
}

// Clears popups if appropriate
function hideTip()
{
	if (v_visible == 1) 
	{
		if(v_layer!=null)
		{
			v_layer.style.visibility = 'hidden';
			v_visible = 0
		}
	}
	return true;
}

function mainMethod() {
	var html;	
	v_visible = 0;
	
	html = makeHTML(v_text, v_title);	
	createPopup(html);
	//if we have mouse coordinates, position layer and make visible
	if(v_havemouse==1);
	{	
		positionLayer();
		
		v_layer.style.visibility = 'visible';
		v_visible=1;
	}
	
}
function makeHTML(text, title) {

	var titlehtml='';
	var backcolor = "bgcolor=\""+v_backcolor+"\"" ;
	var bordercolor = "bgcolor=\""+v_bordercolor+"\"" ;
	
	//If there is a title, form title html
	if(title!=null&&title.length>0)
	{
		titlehtml='<tr><td><font face="' + v_textfont + '" color="' + v_titletextcolor + '" size="' + v_titletextsize
		+'">'+title+'</font></td></tr>';
	}
	
	//Assemble html with variables
	var txt = '<table id="tipTable" width="'+v_width+ '" border="0" cellpadding="'+v_border+'" cellspacing="0" ' + 
	bordercolor+' >'+ titlehtml +'<tr><td><table width="100%" border="0" '+ 'cellspacing="'+v_cellpad+'" '+ 
	backcolor+'><tr><td valign="TOP" style="'+v_cellpad+'">'+
	fontWrapperOpen()+text+fontWrapperClose()+'</td></tr></table></td></tr></table>';
	return txt;
}

//Positions popup according to mouse input
function positionLayer() {
	
	var placeX;
	var placeY;
	
	//get final placement
	placeX=horizontalPlacement();
	placeY = verticalPlacement();
	
	//Move the object
	v_layer.style.left = placeX;
	v_layer.style.top = placeY;
}

//called when the mouse moves
//sets mouse related variables
function mouseMoveHandler(e) {
	
	//var e = (e) ? e : event;
	
	if(!e)
	{
		e=event;
	}
	if (e.clientX) //if there is an x pos property
	{
	 	//GET MOUSE LOCATION
		v_xcoordinate = e.clientX+self.document.body.scrollLeft;
		v_ycoordinate = e.clientY+self.document.body.scrollTop;	
		v_havemouse=1;
	}
	if (v_visible == 1)
	{ 
		positionLayer();	
	}
	
}

//Set mouse handler
function captureMouse() {
	document.onmousemove = mouseMoveHandler;
}

//Creates the popup
function createPopup(input) {

	var popupwidth=v_width;
	var text;
	var zindex;
	
	text='';
	text =  createBackLayer(popupwidth,zindex++);
	text += '<div style="position: absolute; top: 0; left: 0; width: '+ popupwidth+'px; z-index: ' + zindex + ';">' + input + '</div>';
	
	if (typeof v_layer.innerHTML != 'undefined') {
		v_layer.innerHTML = text;
	} 
	
	//After writing html measure height of backlayer to set height of iframe
	var backlayer=self.document.getElementById("backdrop");
	var tiptable=self.document.getElementById("tipTable");
	backlayer.height=tiptable.offsetHeight;
}

//Back layer prevents forms from showing through popups
function createBackLayer(width, Z)
{
	//Create backdrop with 0 height
	return '<iframe id="backdrop" frameborder="0" scrolling="no" width="' + width + '" height="0" style="z-index: ' + Z + '; filter: Beta(Style=0,Opacity=0);"><p></iframe>';
}

// Wraps strings in Layer Generation Functions with the correct tags
function fontWrapperOpen() 
{
	return ('<font face="'+v_textfont+'" color="'+v_textcolor+'" size="'+v_textsize+'">');
}
function fontWrapperClose()
{
	return '</font>';
}

//get horizontal box placement
function horizontalPlacement() {
	placeX = v_xcoordinate+v_xoffset;
	return placeX;
}

//get vertical box placement
function verticalPlacement() {
	return v_ycoordinate+v_yoffset;
}

// create the div container for popup content if it doesn't exist
function createDivContainer() {
	var divContainer = self.document.getElementById(v_divname);
	return divContainer;
}