function submitonce () {
	for (i=0; i<document.forms.length; i++) {
		for (b=0; b<document.forms[i].length; b++) {
			var tempobj = document.forms[i].elements[b]
		 
			if(tempobj.type && (tempobj.type.toLowerCase()=="submit" || tempobj.type.toLowerCase()=="reset"))
				tempobj.disabled = true
		}
	}
	
	return true;
} 

function slownik_filie() {

	l = document.add.lista.length;
	
	var x1 = document.add.dnf.value;
	var x = x1.toUpperCase(); 
	document.add.submit.style.display='';
	document.status.src='img/ok.gif';
	document.status.title=' podana nazwa filii jest unikalna w bazie ';
	
	for (var i=0; i<l; i++) {
	
		var y1 = document.add.lista.options[i].text;
		var y = y1.toUpperCase();
		
		if (x==y) 
		{
			document.add.submit.style.display='none';
			document.status.src='img/duplikat.gif';
			document.status.title=' w bazie istnieje ju� filia o takiej nazwie ';
			break;
			
		}
	}
}	

function slownik_filiee() {

	l = document.addpf.listaf.length;
	
	var x1 = document.addpf.pfake.value;
	var x = x1.toUpperCase(); 
	document.addpfsubmit.style.display='';
	document.status.src='img/ok.gif';
	document.status.title=' podany numer podfaktury jest unikalny w bazie ';
	
	for (var i=0; i<l; i++) {
	
		var y1 = document.addpf.listaf.options[i].text;
		var y = y1.toUpperCase();
		
		if (x==y) 
		{
			document.addpf.submit.style.display='none';
			document.status.src='img/duplikat.gif';
			document.status.title=' w bazie istnieje ju� podfaktura o takim numerze ';
			break;
			
		}
	}
}
