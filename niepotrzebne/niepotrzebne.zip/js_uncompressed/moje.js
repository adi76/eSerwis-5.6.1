function refreshParent() 
{
	window.opener.location.href = window.opener.location.href;
	if (window.opener.progressWindow)
	{
		window.opener.progressWindow.close()
	}
	window.close();
}

function info(s) {
	alert(s);	
}

function newWindow2(x, y, adres)
{
	if (window.screen) {
		var ah = screen.availHeight - 30;
		var aw = screen.availWidth - 10;
		
		var xx=(aw-x) / 2;
		xx=Math.round(xx);
		var yy=(ah-y) / 2;
		yy=Math.round(yy);
	}
	
	var opcje="width="+x+", innerWidth="+x+", height="+y+", innerHeight="+y+", top="+yy+", screenX="+xx+", screenY="+yy+", left="+xx;
	neww2=window.open(adres,'eSerwis2',opcje);
}

function newWindow1(x, y, adres)
{
	if (window.screen) {
		var ah = screen.availHeight - 30;
		var aw = screen.availWidth - 10;
		
		var xx=(aw-x) / 2;
		xx=Math.round(xx);
		var yy=(ah-y) / 2;
		yy=Math.round(yy);
	}
	
	var opcje="width="+x+", innerWidth="+x+", height="+y+", innerHeight="+y+", top="+yy+", screenX="+xx+", screenY="+yy+", left="+xx;
	neww1=window.open(adres,'eSerwis1',opcje);
}

function newWindow(x, y, adres)
{
	if (window.screen) {
		var ah = screen.availHeight - 30;
		var aw = screen.availWidth - 10;
		
		var xx=(aw-x) / 2;
		xx=Math.round(xx);
		var yy=(ah-y) / 2;
		yy=Math.round(yy);
	}
	
	var opcje="width="+x+", innerWidth="+x+", height="+y+", innerHeight="+y+", top="+yy+", screenX="+xx+", screenY="+yy+", left="+xx;
	
	neww=window.open(adres,'eSerwis',opcje);
}

function newWindow_r(x, y, adres)
{
	if (window.screen) {
		var ah = screen.availHeight - 30;
		var aw = screen.availWidth - 10;
		
		var xx=(aw-x) / 2;
		xx=Math.round(xx);
		var yy=(ah-y) / 2;
		yy=Math.round(yy);
	}
	
	var opcje="scrollbars=yes, width="+x+", innerWidth="+x+", height="+y+", innerHeight="+y+", top="+yy+", screenX="+xx+", screenY="+yy+", left="+xx;
	
	neww=window.open(adres,'eSerwis',opcje);
}

function newWindow_r1(x, y, adres)
{
	if (window.screen) {
		var ah = screen.availHeight - 30;
		var aw = screen.availWidth - 10;
		
		var xx=(aw-x) / 2;
		xx=Math.round(xx);
		var yy=(ah-y) / 2;
		yy=Math.round(yy);
	}
	
	var opcje="scrollbars=yes, width="+x+", innerWidth="+x+", height="+y+", innerHeight="+y+", top="+yy+", screenX="+xx+", screenY="+yy+", left="+xx;;
	neww2=window.open(adres,'eSerwis',opcje);
}
	
function pokazrap() 
{
	document.getElementById('rap').style.display=(document.getElementById('wlacz').checked) ? '' : 'none';
}
	  
function wlacz_slownik() 
{
	document.addewid.sk.style.display='';
	document.addewid.konf_proc.style.display='none';
	document.addewid.konf_ram.style.display='none';
	document.addewid.konf_hdd.style.display='none';
}
	  
function wlacz_manual() 
{
	document.addewid.sk.style.display='none';
	document.addewid.konf_proc.style.display='';
	document.addewid.konf_ram.style.display='';
	document.addewid.konf_hdd.style.display='';
}
	  
function clearForm(AForm)
{
	AForm.elements[3].selectedIndex = 0;			
	AForm.elements[4].value = '';
	AForm.elements[5].value = '';

	AForm.elements[6].value = '';
	AForm.elements[7].value = '';
	AForm.elements[8].selectedIndex = 0;			
	AForm.elements[9].value = '';
	AForm.elements[10].value = '';
	AForm.elements[11].value = '';
	AForm.elements[12].checked = false;
	AForm.elements[13].checked = true;
	AForm.elements[14].selectedIndex = 0;	
	
	AForm.elements[15].value = '';
	AForm.elements[16].value = '';
	AForm.elements[17].value = '';
	AForm.elements[18].value = '';

	AForm.elements[19].value = '';
	AForm.elements[20].value = '';

	AForm.elements[21].value = '';
	AForm.elements[22].value = '';
	AForm.elements[23].value = '';
	AForm.elements[24].value = '';
	AForm.elements[25].value = '';
	
	return true;
}
	
function ewid(w) 
{
	document.getElementById('lokalizacja1').style.display=(w!=0) ? '' : 'none';
	document.getElementById('lokalizacja2').style.display=(w!=0) ? '' : 'none';
	document.getElementById('lokalizacja3').style.display=(w!=0) ? '' : 'none';
	document.getElementById('lokalizacja4').style.display=(w!=0) ? '' : 'none';
	document.getElementById('lokalizacja5').style.display=(w!=0) ? '' : 'none';
	document.getElementById('lokalizacja6').style.display=(w!=0) ? '' : 'none';

	document.getElementById('lokalizacja7').style.display=(w!=0) ? '' : 'none';
	document.getElementById('lokalizacja8').style.display=(w!=0) ? '' : 'none';
	document.getElementById('lokalizacja9').style.display=(w!=0) ? '' : 'none';
	document.getElementById('lokalizacja10').style.display=(w!=0) ? '' : 'none';
	document.getElementById('lokalizacja11').style.display=(w!=0) ? '' : 'none';
	document.getElementById('lokalizacja12').style.display=(w!=0) ? '' : 'none';
	document.getElementById('lokalizacja13').style.display=(w!=0) ? '' : 'none';
	document.getElementById('lokalizacja14').style.display=(w!=0) ? '' : 'none';
	
	// W=1 KOMPUTER, W=2 SERWER, W=18 NOTEBOOK
	document.getElementById('zestaw1').style.display=((w==1) || (w==2) || (w==18)) ? '' : 'none';
	document.getElementById('zestaw2').style.display=((w==1) || (w==2) || (w==18)) ? '' : 'none';
	document.getElementById('zestaw3').style.display=((w==1) || (w==2) || (w==18)) ? '' : 'none';
	document.getElementById('zestaw4').style.display=((w==1) || (w==2) || (w==18)) ? '' : 'none';
	document.getElementById('zestaw5').style.display=((w==1) || (w==2) || (w==18)) ? '' : 'none';
	document.getElementById('zestaw6').style.display=((w==1) || (w==2) || (w==18)) ? '' : 'none';
	document.getElementById('zestaw7').style.display=((w==1) || (w==2) || (w==18)) ? '' : 'none';
	document.getElementById('zestaw8').style.display=((w==1) || (w==2) || (w==18)) ? '' : 'none';
	document.getElementById('zestaw9').style.display=((w==1) || (w==2) || (w==18)) ? '' : 'none';
	document.getElementById('zestaw10').style.display=((w==1) || (w==2) || (w==18)) ? '' : 'none';
	document.getElementById('zestaw11').style.display=((w==1) || (w==2) || (w==18)) ? '' : 'none';
	document.getElementById('zestaw12').style.display=((w==1) || (w==2) || (w==18)) ? '' : 'none';
	document.getElementById('zestaw13').style.display=((w==1) || (w==2)) ? '' : 'none';
	document.getElementById('zestaw14').style.display=((w==1) || (w==2)) ? '' : 'none';
	document.getElementById('zestaw15').style.display=((w==1) || (w==2)) ? '' : 'none';

	if ((w==1) || (w==2) || (w==18)) {
//	wlacz_slownik();
	document.addewid.sk.style.display='';
	document.addewid.konf_proc.style.display='none';
	document.addewid.konf_ram.style.display='none';
	document.addewid.konf_hdd.style.display='none';
	} else 
	{
		document.getElementById('wpiszsam').style.display='none';
		document.getElementById('slownik').style.display='none';
	}
		
	//  W=3 DRUKARKA
	document.getElementById('druk1').style.display=(w==3) ? '' : 'none';
	document.getElementById('druk2').style.display=(w==3) ? '' : 'none';
	document.getElementById('druk3').style.display=(w==3) ? '' : 'none';
	document.getElementById('druk4').style.display=(w==3) ? '' : 'none';
	document.getElementById('druk5').style.display=(w==3) ? '' : 'none';
	document.getElementById('druk6').style.display=(w==3) ? '' : 'none';
}

function clearForm(AForm) 
{
	AForm.elements[10].selectedIndex = 0;			
}

function potwierdz() 
{
	if (confirm("Czy chcesz przypisa� nowo dodan� drukark� do komputera ?")) {
		return true;
	}
	else
		return false;
}

function slownik_drukarek() 
{
	l = document.add.lista.length;
	
	var x1 = document.add.druk.value;
	var x = x1.toUpperCase(); 
	document.add.submit.style.display='';
	document.status.src='img/ok.gif';
	document.status.title=' podana nazwa drukarki jest unikalna w s�owniku ';
	
	for (var i=0; i<l; i++) {
	
		var y1 = document.add.lista.options[i].text;
		var y = y1.toUpperCase();
		
		if (x==y) 
		{
			document.add.submit.style.display='none';
			document.status.src='img/duplikat.gif';
			document.status.title=' w s�owniku istnieje ju� drukarka o takiej nazwie ';
			break;
			
		}
	}
}

function slownik_serwisow() {

	l = document.add.lista.length;
	
	var x1 = document.add.serwisowa.value;
	var x = x1.toUpperCase(); 
	document.add.submit.style.display='';
	document.status.src='img/ok.gif';
	document.status.title=' podana nazwa firmy serwisowej jest unikalna w s�owniku ';
	
	for (var i=0; i<l; i++) {
	
		var y1 = document.add.lista.options[i].text;
		var y = y1.toUpperCase();
		
		if (x==y) 
		{
			document.add.submit.style.display='none';
			document.status.src='img/duplikat.gif';
			document.status.title=' w s�owniku istnieje ju� firma serwisowa o takiej nazwie ';
			break;
			
		}
	}
}	

function slownik_es() {

	l = document.ed.lista.length;
	
	var x1 = document.ed.es.value;
	var x = x1.toUpperCase(); 
	document.ed.submit.style.display='';
	document.status.src='img/ok.gif';
	document.status.title=' podana nazwa firmy serwisowej jest unikalna w s�owniku ';
	
	for (var i=0; i<l; i++) {
	
		var y1 = document.ed.lista.options[i].text;
		var y = y1.toUpperCase();
		
		if (x==y) 
		{
			document.ed.submit.style.display='none';
			document.status.src='img/duplikat.gif';
			document.status.title=' w s�owniku istnieje ju� firma serwisowa o takiej nazwie ';
			break;
			
		}
	}
}	

function slownik_kurierow() {

	l = document.add.lista.length;
	
	var x1 = document.add.kurier.value;
	var x = x1.toUpperCase(); 
	document.add.submit.style.display='';
	document.status.src='img/ok.gif';
	document.status.title=' podana nazwa firmy kurierska jest unikalna w s�owniku ';
	
	for (var i=0; i<l; i++) {
	
		var y1 = document.add.lista.options[i].text;
		var y = y1.toUpperCase();
		
		if (x==y) 
		{
			document.add.submit.style.display='none';
			document.status.src='img/duplikat.gif';
			document.status.title=' w s�owniku istnieje ju� firma kurierska o takiej nazwie ';
			break;
			
		}
	}
}	

function slownik_ek() {

	l = document.ed.lista.length;
	
	var x1 = document.ed.ek.value;
	var x = x1.toUpperCase(); 
	document.ed.submit.style.display='';
	document.status.src='img/ok.gif';
	document.status.title=' podana nazwa firmy kurierskiej jest unikalna w s�owniku ';
	
	for (var i=0; i<l; i++) {
	
		var y1 = document.ed.lista.options[i].text;
		var y = y1.toUpperCase();
		
		if (x==y) 
		{
			document.ed.submit.style.display='none';
			document.status.src='img/duplikat.gif';
			document.status.title=' w s�owniku istnieje ju� firma kurierska o takiej nazwie ';
			break;
			
		}
	}
}	

function slownik_dostawcow() {

	l = document.add.lista.length;
	
	var x1 = document.add.dostawca.value;
	var x = x1.toUpperCase(); 
	document.add.submit.style.display='';
	document.status.src='img/ok.gif';
	document.status.title=' podana nazwa dostawcy jest unikalna w s�owniku ';
	
	for (var i=0; i<l; i++) {
	
		var y1 = document.add.lista.options[i].text;
		var y = y1.toUpperCase();
		
		if (x==y) 
		{
			document.add.submit.style.display='none';
			document.status.src='img/duplikat.gif';
			document.status.title=' w s�owniku istnieje ju� dostawca o takiej nazwie ';
			break;
			
		}
	}
}	

function slownik_monitorow() {

	l = document.add.lista.length;
	
	var x1 = document.add.monitor.value;
	var x = x1.toUpperCase(); 
	document.add.submit.style.display='';
	document.status.src='img/ok.gif';
	document.status.title=' podana nazwa monitora jest unikalna w s�owniku ';
	
	for (var i=0; i<l; i++) {
	
		var y1 = document.add.lista.options[i].text;
		var y = y1.toUpperCase();
		
		if (x==y) 
		{
			document.add.submit.style.display='none';
			document.status.src='img/duplikat.gif';
			document.status.title=' w s�owniku istnieje ju� monitor o takiej nazwie ';
			break;
			
		}
	}
}	

function slownik_opr() {

	l = document.add.lista.length;
	
	var x1 = document.add.opr.value;
	var x = x1.toUpperCase(); 
	document.add.submit.style.display='';
	document.status.src='img/ok.gif';
	document.status.title=' podana nazwa monitora jest unikalna w s�owniku ';
	
	for (var i=0; i<l; i++) {
	
		var y1 = document.add.lista.options[i].text;
		var y = y1.toUpperCase();
		
		if (x==y) 
		{
			document.add.submit.style.display='none';
			document.status.src='img/duplikat.gif';
			document.status.title=' w s�owniku istnieje ju� monitor o takiej nazwie ';
			break;
			
		}
	}
}	

function slownik_pion() {

	l = document.add.lista.length;
	
	var x1 = document.add.pion.value;
	var x = x1.toUpperCase(); 
	document.add.submit.style.display='';
	document.status.src='img/ok.gif';
	document.status.title=' podana nazwa pionu jest unikalna w s�owniku ';
	
	for (var i=0; i<l-1; i++) {
	
		var y1 = document.add.lista.options[i].text;
		var y = y1.toUpperCase();
		
		if (x==y) 
		{
			document.add.submit.style.display='none';
			document.status.src='img/duplikat.gif';
			document.status.title=' w s�owniku istnieje ju� pion o takiej nazwie ';
			break;
			
		}
	}
}	

function slownik_faktury() {

	l = document.addf.listaf.length;
	
	var x1 = document.addf.faktura_add.value;
	var x = x1.toUpperCase(); 
	document.addf.submit.style.display='';
	document.status.src='img/ok.gif';
	document.status.title=' podana numer faktury jest unikalny w bazie ';
	
	for (var i=0; i<l; i++) {
	
		var y1 = document.addf.listaf.options[i].text;
		var y = y1.toUpperCase();
		
		if (x==y) 
		{
			document.addf.submit.style.display='none';
			document.status.src='img/duplikat.gif';
			document.status.title=' w bazie istnieje ju� faktura o takim numerze ';
			break;
			
		}
	}
}	

function slownik_fakturae() {

	l = document.ef.listaf.length;
	
	var x1 = document.ef.fake.value;
	var x = x1.toUpperCase(); 
	document.ef.submit.style.display='';
	document.status.src='img/ok.gif';
	document.status.title=' podany numer faktury jest unikalny w bazie ';
	
	for (var i=0; i<l; i++) {
	
		var y1 = document.ef.listaf.options[i].text;
		var y = y1.toUpperCase();
		
		if (x==y) 
		{
			document.ef.submit.style.display='none';
			document.status.src='img/duplikat.gif';
			document.status.title=' w bazie istnieje ju� faktura o takim numerze ';
			break;
			
		}
	}
}
	
function slownik_loginow() {

	l = document.add.lista.length;
	
	var x1 = document.add.user.value;
	var x = x1.toUpperCase(); 
	document.add.submit.style.display='';
	document.status.src='img/ok.gif';
	document.status.title=' podany login jest unikalny ';
	
	for (var i=0; i<l; i++) {
	
		var y1 = document.add.lista.options[i].text;
		var y = y1.toUpperCase();
		
		if (x==y) 
		{
			document.add.submit.style.display='none';
			document.status.src='img/duplikat.gif';
			document.status.title=' podany login jest ju� u�ywany ';
			break;
			
		}
	}
}	

function slownik_loginowe() {

	l = document.ed.lista.length;
	
	var x1 = document.ed.user.value;
	var x = x1.toUpperCase(); 
	document.ed.submit.style.display='';
	document.status.src='img/ok.gif';
	document.status.title=' podany login jest unikalny ';
	
	for (var i=0; i<l; i++) {
	
		var y1 = document.ed.lista.options[i].text;
		var y = y1.toUpperCase();
		
		if (x==y) 
		{
			document.ed.submit.style.display='none';
			document.status.src='img/duplikat.gif';
			document.status.title=' podany login jest ju� u�ywany ';
			break;
			
		}
	}
}	

function slownik_upa() {

	l = document.addu.lista.length;
	
	var x1 = document.addu.up.value;
	var x = x1.toUpperCase(); 
	document.addu.submit.style.display='';
	document.status.src='img/ok.gif';
	document.status.title=' podana nazwa UP/kom�rki jest unikalna w s�owniku ';
	
	for (var i=0; i<l-1; i++) {
	
		var y1 = document.addu.lista.options[i].text;
		var y = y1.toUpperCase();
		
		if (x==y) 
		{
			document.addu.submit.style.display='none';
			document.status.src='img/duplikat.gif';
			document.status.title=' w s�owniku istnieje ju� UP/kom�rka o takiej nazwie ';
			break;
			
		}
	}
}

function slownik_upe() {

	l = document.edu.lista.length;
	
	var x1 = document.edu.upe.value;
	var x = x1.toUpperCase(); 
	document.edu.submit.style.display='';
	document.status.src='img/ok.gif';
	document.status.title=' podana nazwa UP/kom�rki jest unikalna w s�owniku ';
	
	for (var i=0; i<l-1; i++) {
	
		var y1 = document.edu.lista.options[i].text;
		var y = y1.toUpperCase();
		
		if (x==y) 
		{
			document.edu.submit.style.display='none';
			document.status.src='img/duplikat.gif';
			document.status.title=' w s�owniku istnieje ju� UP/kom�rka o takiej nazwie ';
			break;
			
		}
	}
}

function slownik_pfaktury() {

	l = document.addpf.listaf.length;
	
	var x1 = document.addpf.pfaktura_add.value;
	var x = x1.toUpperCase(); 
	document.addpf.submit.style.display='';
	document.status.src='img/ok.gif';
	document.status.title=' podana numer podfaktury jest unikalny w bazie ';
	
	for (var i=0; i<l; i++) {
	
		var y1 = document.addpf.listaf.options[i].text;
		var y = y1.toUpperCase();
		
		if (x==y) 
		{
			document.addpf.submit.style.display='none';
			document.status.src='img/duplikat.gif';
			document.status.title=' w bazie istnieje ju� podfaktura o takim numerze ';
			break;
			
		}
	}
}	

function slownik_pfakturae() {

	l = document.addpf.listaf.length;
	
	var x1 = document.addpf.pfake.value;
	var x = x1.toUpperCase(); 
	document.addpfsubmit.style.display='';
	document.status.src='img/ok.gif';
	document.status.title=' podany numer podfaktury jest unikalny w bazie ';
	
	for (var i=0; i<l; i++) {
	
		var y1 = document.addpf.listaf.options[i].text;
		var y = y1.toUpperCase();
		
		if (x==y) 
		{
			document.addpf.submit.style.display='none';
			document.status.src='img/duplikat.gif';
			document.status.title=' w bazie istnieje ju� podfaktura o takim numerze ';
			break;
			
		}
	}
}

function selectAll(x) {
	for(var i=0,l=x.form.length; i<l; i++)
	if(x.form[i].type == 'checkbox' && x.form[i].name != 'sAll')
	x.form[i].checked=x.form[i].checked?false:true
}
	
function selectAll1(x) {
	for(var i=0,l=x.form.length; i<l; i++)
	if(x.form[i].type == 'checkbox')
	x.form[i].checked=true
}

function slownik_umow() {

	l = document.add.lista.length;
	
	var x1 = document.add.umowa.value;
	var x = x1.toUpperCase(); 
	document.add.submit.style.display='';
	document.status.src='img/ok.gif';
	document.status.title=' podany numer umowy jest unikalny ';
	
	for (var i=0; i<l; i++) {
	
		var y1 = document.add.lista.options[i].text;
		var y = y1.toUpperCase();
		
		if (x==y) 
		{
			document.add.submit.style.display='none';
			document.status.src='img/duplikat.gif';
			document.status.title=' podany numer umowy jest ju� w bazie ';
			break;
			
		}
	}
}	

function slownik_typowsp() {

	l = document.add.lista.length;
	
	var x1 = document.add.typsp.value;
	var x = x1.toUpperCase(); 
	document.add.submit.style.display='';
	document.status.src='img/ok.gif';
	document.status.title=' podany typ sprz�tu jest unikalny w s�owniku ';
	
	for (var i=0; i<l-1; i++) {
	
		var y1 = document.add.lista.options[i].text;
		var y = y1.toUpperCase();
		
		if (x==y) 
		{
			document.add.submit.style.display='none';
			document.status.src='img/duplikat.gif';
			document.status.title=' w s�owniku istnieje ju� typ sprz�tu o takiej nazwie ';
			break;
			
		}
	}
}

/***********************************************
* Disable "Enter" key in Form script- By Nurul Fadilah(nurul@REMOVETHISvolmedia.com)
* This notice must stay intact for use
* Visit http://www.dynamicdrive.com/ for full source code
***********************************************/
                
function handleEnter (field, event) 
{
	var keyCode = event.keyCode ? event.keyCode : event.which ? event.which : event.charCode;
	if (keyCode == 13) {
	var i;
	for (i = 0; i < field.form.elements.length; i++)
		if (field == field.form.elements[i])
			break;
		i = (i + 1) % field.form.elements.length;
		field.form.elements[i].focus();
		return false;
	} 
	else
	return true;
}